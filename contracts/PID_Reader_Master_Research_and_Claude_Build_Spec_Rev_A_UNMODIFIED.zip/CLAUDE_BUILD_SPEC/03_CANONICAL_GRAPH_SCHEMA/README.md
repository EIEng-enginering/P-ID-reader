# Canonical graph v1 — specification-only artefacts

The schemas in this folder are **original proposals**, separate from frozen Worksheet R1. `graph.schema.json` validates structure; the **semantic validator must additionally check foreign keys** (port.owner_node_id, edge port IDs, uniqueness of IDs, hypothesis group members, mutually exclusive cardinality, legal state transitions, no accepted edge without a named review, all provenance SHA matches). The example is deliberately hypothetical and remains unreviewed.

DEXPI mapping CSV provides **candidate mappings**, not proof that arbitrary canonical attributes can be serialized as DEXPI 2.0.1; WP-10 must check exact class/property names against the pinned official model. Do not treat the table as a normative XSD or emit fabricated fields. Python `pyDEXPI` is AGPL, excluded from default proprietary runtime. See RQ-01/02, REF-01–07.

IDs shown use placeholder deterministic values for synthetic illustration. An implementation must compute IDs from canonical source keys. `evidence_sidecar.json` is a separate local disclosure of unresolved hypotheses and provenance. Never assert these are plant-verified.

**GraphML/JSON-LD/CSV/XLSX design mapping:** `other_export_field_mapping.csv` enumerates 22 candidate fields and the review/provenance policy. It is an independently authored mapping contract, not a validated external interchange standard. Excel exports must escape formula-looking input; JSON-LD uses an original namespace rather than asserting ISO 15926 equivalence. See `07_EXPORT_SPECS/EXPORT_CONTRACTS.md`.
