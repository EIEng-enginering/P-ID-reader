# ALG-10 — Flow Arrows

**State:** OPINION / proposed algorithm, not executed in the current codebase. **Related research:** RQ-31; compare `01_RESEARCH_REPORT`. No independent accuracy claim.

## Purpose and I/O

**Purpose:** Detect directional arrows without confusing callout leaders.

**Inputs:** filled arrowheads, pipe paths, OCR FROM/TO, primitive tangents.

**Outputs:** edge direction proposals with evidence and unknown default. Every output SHALL carry immutable source SHA-256, page, source geometry IDs and original normalised bounding polygon, producer/version, alternatives and score kind. All interpretations begin `PROPOSED_UNVERIFIED`.

## Procedure

1. Validate inputs against source SHA, coordinate transforms and resource limits. Preserve original drawing primitives before filtering.
2. Build bounded spatial indices and input-object candidate sets, pruning clearly unrelated elements before expensive matching.
3. **Domain procedure:** Match triangle tip tangent to line within angular tolerance; require line-style consistency and location not within callout/notes region.
4. Return all plausible alternatives with raw evidence; do not invent missing field values and do not accept graph connectivity from unclear linework.
5. Sort by reproducible feature scores then stable source IDs; serialise with canonical JSON and a separate analysis version.
6. Annotate `UNKNOWN`, `AMBIGUOUS` or `UNREADABLE` wherever preconditions do not hold. Store effective source revision and reviewer outcome independently.

## Proposed parameters (tune only on development gold)

`tip_line_dist=2pt; max_angle=20deg; arrow_length_ratio=0.3..2.5`.

Default rationale: conservative CPU-first behaviour prioritising safety from false connectivity; these numbers are initial experiment settings, not engineering standards and not measured optimal values. Expose them through versioned configuration and record selected values in provenance. Define safe bounds and reject invalid config.

## Complexity and resource envelope

O((H+S)logS). Processing is tile-bounded and cancellable. Raise a typed `RESOURCE_LIMIT` with coverage area on exceeding budgets; never silently omit a region. Cache intermediate immutable artefacts by source SHA + algorithm/model version + config SHA.

## Failure modes / refusal policy

Arrowheads may indicate annotation rather than process flow. All unresolved outcomes must be visible in summary coverage. Do not flatten ambiguous results into a single accepted plant fact.

## Test-first fixtures and expected results

| Case | Synthetic input / setup | Expected result |
|---|---|---|
| P1 | arrow along process pipe | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P2 |  vertical flow arrow | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P3 |  across tile seam | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P4 |  inlet arrow | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P5 |  explicit FLOW TO annotation | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| N1 | leader arrow to note not flow | No confident false positive, or explicit typed ambiguity/refusal |
| N2 |  pennant flag not same-page direction | No confident false positive, or explicit typed ambiguity/refusal |
| N3 |  no arrow UNKNOWN | No confident false positive, or explicit typed ambiguity/refusal |
| N4 |  contradictory arrows unresolved | No confident false positive, or explicit typed ambiguity/refusal |
| N5 |  tiny filled dot not arrow | No confident false positive, or explicit typed ambiguity/refusal |

Run provenance, canonicalisation, cancellation and source-hash mismatch tests as additional invariants. Validate on at least five fresh independent real examples if cleared. Maintain benchmark counts as `NOT_RUN` until actually executed.

### Pseudocode skeleton

```python
def analyse(source, evidence, params, cancel):
    validate_source_hash_and_coordinate_frame(source, evidence)
    candidates = spatially_prune(evidence, params)
    proposals = []
    for region in sorted(candidates, key=stable_region_id):
        cancel.check()
        observed = compute_observed_features(region, params)
        if sufficient_evidence(observed, params):
            proposals += rank_hypotheses_with_source_links(observed)
        else:
            proposals += [typed_unknown(region, reason='INSUFFICIENT_EVIDENCE')]
    return immutable_versioned_analysis(proposals, source, params)
```

`compute_observed_features`, `sufficient_evidence` and `rank_hypotheses_with_source_links` are **to be implemented** with the domain procedure above, not placeholder proof of completion.
