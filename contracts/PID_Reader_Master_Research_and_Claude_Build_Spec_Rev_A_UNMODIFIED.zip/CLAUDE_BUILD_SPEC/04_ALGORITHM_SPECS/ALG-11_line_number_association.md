# ALG-11 — Line Number Association

**State:** OPINION / proposed algorithm, not executed in the current codebase. **Related research:** RQ-05,RQ-32; compare `01_RESEARCH_REPORT`. No independent accuracy claim.

## Purpose and I/O

**Purpose:** Attach line IDs and nominal sizes to correct path segments.

**Inputs:** parsed text, candidate pipe paths, leaders, spec break geometry.

**Outputs:** line-assignment hypotheses with stop points. Every output SHALL carry immutable source SHA-256, page, source geometry IDs and original normalised bounding polygon, producer/version, alternatives and score kind. All interpretations begin `PROPOSED_UNVERIFIED`.

## Procedure

1. Validate inputs against source SHA, coordinate transforms and resource limits. Preserve original drawing primitives before filtering.
2. Build bounded spatial indices and input-object candidate sets, pruning clearly unrelated elements before expensive matching.
3. **Domain procedure:** Rank perpendicular distance, parallel alignment, leader attachment and local path continuity; propagate only until explicit identity change, reducer or unresolved junction.
4. Return all plausible alternatives with raw evidence; do not invent missing field values and do not accept graph connectivity from unclear linework.
5. Sort by reproducible feature scores then stable source IDs; serialise with canonical JSON and a separate analysis version.
6. Annotate `UNKNOWN`, `AMBIGUOUS` or `UNREADABLE` wherever preconditions do not hold. Store effective source revision and reviewer outcome independently.

## Proposed parameters (tune only on development gold)

`label_offset_max=35pt; angle_max=20deg; stop_at_ambiguous=True; propagation_max_segments=250`.

Default rationale: conservative CPU-first behaviour prioritising safety from false connectivity; these numbers are initial experiment settings, not engineering standards and not measured optimal values. Expose them through versioned configuration and record selected values in provenance. Define safe bounds and reject invalid config.

## Complexity and resource envelope

O((L+S)logS). Processing is tile-bounded and cancellable. Raise a typed `RESOURCE_LIMIT` with coverage area on exceeding budgets; never silently omit a region. Cache intermediate immutable artefacts by source SHA + algorithm/model version + config SHA.

## Failure modes / refusal policy

Two parallel pipes and overlapping line labels cause mixup. All unresolved outcomes must be visible in summary coverage. Do not flatten ambiguous results into a single accepted plant fact.

## Test-first fixtures and expected results

| Case | Synthetic input / setup | Expected result |
|---|---|---|
| P1 | NPS 20 on horizontal pipe | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P2 |  DN 100 vertical line | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P3 |  leader-tipped line number | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P4 |  stable across split segment | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P5 |  explicit spec-break stopping | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| N1 | annotation number not line tag | No confident false positive, or explicit typed ambiguity/refusal |
| N2 |  same tag duplicate conflict | No confident false positive, or explicit typed ambiguity/refusal |
| N3 |  reducer stops inherited size | No confident false positive, or explicit typed ambiguity/refusal |
| N4 |  tee with unresolved branch stops | No confident false positive, or explicit typed ambiguity/refusal |
| N5 |  note text close but unassociated | No confident false positive, or explicit typed ambiguity/refusal |

Run provenance, canonicalisation, cancellation and source-hash mismatch tests as additional invariants. Validate on at least five fresh independent real examples if cleared. Maintain benchmark counts as `NOT_RUN` until actually executed.

### Pseudocode skeleton

```python
def analyse(source, evidence, params, cancel):
    validate_source_hash_and_coordinate_frame(source, evidence)
    candidates = spatially_prune(evidence, params)
    proposals = []
    for region in sorted(candidates, key=stable_region_id):
        cancel.check()
        observed = compute_observed_features(region, params)
        if sufficient_evidence(observed, params):
            proposals += rank_hypotheses_with_source_links(observed)
        else:
            proposals += [typed_unknown(region, reason='INSUFFICIENT_EVIDENCE')]
    return immutable_versioned_analysis(proposals, source, params)
```

`compute_observed_features`, `sufficient_evidence` and `rank_hypotheses_with_source_links` are **to be implemented** with the domain procedure above, not placeholder proof of completion.
