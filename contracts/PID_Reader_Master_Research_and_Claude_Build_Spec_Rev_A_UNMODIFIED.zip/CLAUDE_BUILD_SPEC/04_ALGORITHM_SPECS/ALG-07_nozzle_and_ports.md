# ALG-07 — Nozzle And Ports

**State:** OPINION / proposed algorithm, not executed in the current codebase. **Related research:** RQ-12,RQ-23,RQ-33; compare `01_RESEARCH_REPORT`. No independent accuracy claim.

## Purpose and I/O

**Purpose:** Find geometric terminals on equipment and inline symbols.

**Inputs:** reviewable symbol boundary, stroke endpoints, optional nearby port labels.

**Outputs:** typed candidate ports and endpoint-to-port associations. Every output SHALL carry immutable source SHA-256, page, source geometry IDs and original normalised bounding polygon, producer/version, alternatives and score kind. All interpretations begin `PROPOSED_UNVERIFIED`.

## Procedure

1. Validate inputs against source SHA, coordinate transforms and resource limits. Preserve original drawing primitives before filtering.
2. Build bounded spatial indices and input-object candidate sets, pruning clearly unrelated elements before expensive matching.
3. **Domain procedure:** Intersect terminated strokes with outline boundary band; compute outward tangent; group duplicates at same physical stub; use labels `N1`, `INLET`, etc as optional evidence.
4. Return all plausible alternatives with raw evidence; do not invent missing field values and do not accept graph connectivity from unclear linework.
5. Sort by reproducible feature scores then stable source IDs; serialise with canonical JSON and a separate analysis version.
6. Annotate `UNKNOWN`, `AMBIGUOUS` or `UNREADABLE` wherever preconditions do not hold. Store effective source revision and reviewer outcome independently.

## Proposed parameters (tune only on development gold)

`boundary_band=max(1pt,0.015xobject_size); angle_tolerance=25deg; group_eps=1.5pt`.

Default rationale: conservative CPU-first behaviour prioritising safety from false connectivity; these numbers are initial experiment settings, not engineering standards and not measured optimal values. Expose them through versioned configuration and record selected values in provenance. Define safe bounds and reject invalid config.

## Complexity and resource envelope

O((E+S)logS). Processing is tile-bounded and cancellable. Raise a typed `RESOURCE_LIMIT` with coverage area on exceeding budgets; never silently omit a region. Cache intermediate immutable artefacts by source SHA + algorithm/model version + config SHA.

## Failure modes / refusal policy

Crossing a vessel outline not always connected, interleaved skids blur port. All unresolved outcomes must be visible in summary coverage. Do not flatten ambiguous results into a single accepted plant fact.

## Test-first fixtures and expected results

| Case | Synthetic input / setup | Expected result |
|---|---|---|
| P1 | pump suction/discharge ports | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P2 |  vessel side nozzle | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P3 |  two-port valve | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P4 |  tagged N1 nozzle | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P5 |  reducer inlet/outlet | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| N1 | stroke through box not automatically port | No confident false positive, or explicit typed ambiguity/refusal |
| N2 |  note leader not process port | No confident false positive, or explicit typed ambiguity/refusal |
| N3 |  unclosed shape UNKNOWN | No confident false positive, or explicit typed ambiguity/refusal |
| N4 |  overlapping equipment ports ambiguous | No confident false positive, or explicit typed ambiguity/refusal |
| N5 |  dangling label not port | No confident false positive, or explicit typed ambiguity/refusal |

Run provenance, canonicalisation, cancellation and source-hash mismatch tests as additional invariants. Validate on at least five fresh independent real examples if cleared. Maintain benchmark counts as `NOT_RUN` until actually executed.

### Pseudocode skeleton

```python
def analyse(source, evidence, params, cancel):
    validate_source_hash_and_coordinate_frame(source, evidence)
    candidates = spatially_prune(evidence, params)
    proposals = []
    for region in sorted(candidates, key=stable_region_id):
        cancel.check()
        observed = compute_observed_features(region, params)
        if sufficient_evidence(observed, params):
            proposals += rank_hypotheses_with_source_links(observed)
        else:
            proposals += [typed_unknown(region, reason='INSUFFICIENT_EVIDENCE')]
    return immutable_versioned_analysis(proposals, source, params)
```

`compute_observed_features`, `sufficient_evidence` and `rank_hypotheses_with_source_links` are **to be implemented** with the domain procedure above, not placeholder proof of completion.
