# ALG-06 — Equipment Classification

**State:** OPINION / proposed algorithm, not executed in the current codebase. **Related research:** RQ-23; compare `01_RESEARCH_REPORT`. No independent accuracy claim.

## Purpose and I/O

**Purpose:** Infer vessels, pumps, heat exchangers, manifolds and skids from composition.

**Inputs:** outline components, nozzles, text blocks, layout context.

**Outputs:** equipment class hypotheses plus composite bounding regions. Every output SHALL carry immutable source SHA-256, page, source geometry IDs and original normalised bounding polygon, producer/version, alternatives and score kind. All interpretations begin `PROPOSED_UNVERIFIED`.

## Procedure

1. Validate inputs against source SHA, coordinate transforms and resource limits. Preserve original drawing primitives before filtering.
2. Build bounded spatial indices and input-object candidate sets, pruning clearly unrelated elements before expensive matching.
3. **Domain procedure:** Generate class cues from body aspect, heads, inner internals, ports, tag prefix and label; combine independent evidence; do not assume a generic building block is a vessel.
4. Return all plausible alternatives with raw evidence; do not invent missing field values and do not accept graph connectivity from unclear linework.
5. Sort by reproducible feature scores then stable source IDs; serialise with canonical JSON and a separate analysis version.
6. Annotate `UNKNOWN`, `AMBIGUOUS` or `UNREADABLE` wherever preconditions do not hold. Store effective source revision and reviewer outcome independently.

## Proposed parameters (tune only on development gold)

`evidence_families_min=2; package_dash_fraction=0.65; large_block_aspect=1..8`.

Default rationale: conservative CPU-first behaviour prioritising safety from false connectivity; these numbers are initial experiment settings, not engineering standards and not measured optimal values. Expose them through versioned configuration and record selected values in provenance. Define safe bounds and reject invalid config.

## Complexity and resource envelope

O(ElogE) with indexed shapes. Processing is tile-bounded and cancellable. Raise a typed `RESOURCE_LIMIT` with coverage area on exceeding budgets; never silently omit a region. Cache intermediate immutable artefacts by source SHA + algorithm/model version + config SHA.

## Failure modes / refusal policy

Buildings/notes resemble equipment; labels can mean area not equipment. All unresolved outcomes must be visible in summary coverage. Do not flatten ambiguous results into a single accepted plant fact.

## Test-first fixtures and expected results

| Case | Synthetic input / setup | Expected result |
|---|---|---|
| P1 | horizontal vessel with heads | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P2 |  rectangular HEATER block | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P3 |  pump with nozzle/tag | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P4 |  heat exchanger with paired channels | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P5 |  dashed skid boundary | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| N1 | title-block box not process equipment | No confident false positive, or explicit typed ambiguity/refusal |
| N2 |  NOTE with P-101 not pump | No confident false positive, or explicit typed ambiguity/refusal |
| N3 |  actuator circle not vessel | No confident false positive, or explicit typed ambiguity/refusal |
| N4 |  one bare rectangle UNKNOWN | No confident false positive, or explicit typed ambiguity/refusal |
| N5 |  area enclosure not hydraulic unit | No confident false positive, or explicit typed ambiguity/refusal |

Run provenance, canonicalisation, cancellation and source-hash mismatch tests as additional invariants. Validate on at least five fresh independent real examples if cleared. Maintain benchmark counts as `NOT_RUN` until actually executed.

### Pseudocode skeleton

```python
def analyse(source, evidence, params, cancel):
    validate_source_hash_and_coordinate_frame(source, evidence)
    candidates = spatially_prune(evidence, params)
    proposals = []
    for region in sorted(candidates, key=stable_region_id):
        cancel.check()
        observed = compute_observed_features(region, params)
        if sufficient_evidence(observed, params):
            proposals += rank_hypotheses_with_source_links(observed)
        else:
            proposals += [typed_unknown(region, reason='INSUFFICIENT_EVIDENCE')]
    return immutable_versioned_analysis(proposals, source, params)
```

`compute_observed_features`, `sufficient_evidence` and `rank_hypotheses_with_source_links` are **to be implemented** with the domain procedure above, not placeholder proof of completion.
