# ALG-01 — Vector Normalisation

**State:** OPINION / proposed algorithm, not executed in the current codebase. **Related research:** RQ-10,RQ-27; compare `01_RESEARCH_REPORT`. No independent accuracy claim.

## Purpose and I/O

**Purpose:** Convert all PDF and CAD geometry into source-preserving planar primitives.

**Inputs:** PDF page content streams, graphics-state transform, page transform.

**Outputs:** line/arc/bezier/fill primitive records with original path IDs. Every output SHALL carry immutable source SHA-256, page, source geometry IDs and original normalised bounding polygon, producer/version, alternatives and score kind. All interpretations begin `PROPOSED_UNVERIFIED`.

## Procedure

1. Validate inputs against source SHA, coordinate transforms and resource limits. Preserve original drawing primitives before filtering.
2. Build bounded spatial indices and input-object candidate sets, pruning clearly unrelated elements before expensive matching.
3. **Domain procedure:** Expand nested transformations with bounded stack; keep original cubic curves and conservative chord approximations; preserve fill rule, winding, dash and clipping; collapse exact duplicate strokes only for graph view.
4. Return all plausible alternatives with raw evidence; do not invent missing field values and do not accept graph connectivity from unclear linework.
5. Sort by reproducible feature scores then stable source IDs; serialise with canonical JSON and a separate analysis version.
6. Annotate `UNKNOWN`, `AMBIGUOUS` or `UNREADABLE` wherever preconditions do not hold. Store effective source revision and reviewer outcome independently.

## Proposed parameters (tune only on development gold)

`chord_sagitta_max=0.3pt; duplicate_eps=0.05pt; max_path_depth=24`.

Default rationale: conservative CPU-first behaviour prioritising safety from false connectivity; these numbers are initial experiment settings, not engineering standards and not measured optimal values. Expose them through versioned configuration and record selected values in provenance. Define safe bounds and reject invalid config.

## Complexity and resource envelope

O(P+S) geometry generation then indexed queries. Processing is tile-bounded and cancellable. Raise a typed `RESOURCE_LIMIT` with coverage area on exceeding budgets; never silently omit a region. Cache intermediate immutable artefacts by source SHA + algorithm/model version + config SHA.

## Failure modes / refusal policy

Raster XObjects and unsupported shadings produce UNKNOWN not phantom lines. All unresolved outcomes must be visible in summary coverage. Do not flatten ambiguous results into a single accepted plant fact.

## Test-first fixtures and expected results

| Case | Synthetic input / setup | Expected result |
|---|---|---|
| P1 | straight segment preserved | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P2 |  filled triangle reconstructed | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P3 |  cubic arc retained | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P4 |  rectangle component indexed | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P5 |  90deg rotated primitive mapped | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| N1 | hidden clipped shape ignored | No confident false positive, or explicit typed ambiguity/refusal |
| N2 |  recursive XObject blocked | No confident false positive, or explicit typed ambiguity/refusal |
| N3 |  nearly coincident label stroke not collapsed | No confident false positive, or explicit typed ambiguity/refusal |
| N4 |  bad affine matrix rejected | No confident false positive, or explicit typed ambiguity/refusal |
| N5 |  fill with missing boundary remains unclassified | No confident false positive, or explicit typed ambiguity/refusal |

Run provenance, canonicalisation, cancellation and source-hash mismatch tests as additional invariants. Validate on at least five fresh independent real examples if cleared. Maintain benchmark counts as `NOT_RUN` until actually executed.

### Pseudocode skeleton

```python
def analyse(source, evidence, params, cancel):
    validate_source_hash_and_coordinate_frame(source, evidence)
    candidates = spatially_prune(evidence, params)
    proposals = []
    for region in sorted(candidates, key=stable_region_id):
        cancel.check()
        observed = compute_observed_features(region, params)
        if sufficient_evidence(observed, params):
            proposals += rank_hypotheses_with_source_links(observed)
        else:
            proposals += [typed_unknown(region, reason='INSUFFICIENT_EVIDENCE')]
    return immutable_versioned_analysis(proposals, source, params)
```

`compute_observed_features`, `sufficient_evidence` and `rank_hypotheses_with_source_links` are **to be implemented** with the domain procedure above, not placeholder proof of completion.
