# ALG-04 — Tag Decoding And Stacked Bubbles

**State:** OPINION / proposed algorithm, not executed in the current codebase. **Related research:** RQ-05,RQ-15,RQ-16; compare `01_RESEARCH_REPORT`. No independent accuracy claim.

## Purpose and I/O

**Purpose:** Recover engineering tags from stacked and split OCR while retaining raw alternatives.

**Inputs:** OCR word boxes, circle candidates, grammar profiles, native tokens.

**Outputs:** tag hypotheses with loop key and source token IDs. Every output SHALL carry immutable source SHA-256, page, source geometry IDs and original normalised bounding polygon, producer/version, alternatives and score kind. All interpretations begin `PROPOSED_UNVERIFIED`.

## Procedure

1. Validate inputs against source SHA, coordinate transforms and resource limits. Preserve original drawing primitives before filtering.
2. Build bounded spatial indices and input-object candidate sets, pruning clearly unrelated elements before expensive matching.
3. **Domain procedure:** Sort reading order by fitted text baseline; group tokens contained by bubble; parse finite grammar; dynamic-program N-best joins and weighted confusion variants; only approved profile strips leading 0.
4. Return all plausible alternatives with raw evidence; do not invent missing field values and do not accept graph connectivity from unclear linework.
5. Sort by reproducible feature scores then stable source IDs; serialise with canonical JSON and a separate analysis version.
6. Annotate `UNKNOWN`, `AMBIGUOUS` or `UNREADABLE` wherever preconditions do not hold. Store effective source revision and reviewer outcome independently.

## Proposed parameters (tune only on development gold)

`top_k=3; max_edit_cost=2.0; containment_margin=0.08diameter; grammar_priority=0.25 heuristic`.

Default rationale: conservative CPU-first behaviour prioritising safety from false connectivity; these numbers are initial experiment settings, not engineering standards and not measured optimal values. Expose them through versioned configuration and record selected values in provenance. Define safe bounds and reject invalid config.

## Complexity and resource envelope

O(T*G*K) bounded by candidates. Processing is tile-bounded and cancellable. Raise a typed `RESOURCE_LIMIT` with coverage area on exceeding budgets; never silently omit a region. Cache intermediate immutable artefacts by source SHA + algorithm/model version + config SHA.

## Failure modes / refusal policy

0/O and 1/I ambiguity, two bubbles overlapping, false valid tag. All unresolved outcomes must be visible in summary coverage. Do not flatten ambiguous results into a single accepted plant fact.

## Test-first fixtures and expected results

| Case | Synthetic input / setup | Expected result |
|---|---|---|
| P1 | PIT over 101 | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P2 |  0 ZSC 201 variant | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P3 |  PCV-102 single line | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P4 |  6-P-1501-A1A line string | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P5 |  PG without suffix stays PG | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| N1 | PIT plus distant 101 not combined | No confident false positive, or explicit typed ambiguity/refusal |
| N2 |  NOTE 101 not parsed as PT | No confident false positive, or explicit typed ambiguity/refusal |
| N3 |  stray 0 not silently removed | No confident false positive, or explicit typed ambiguity/refusal |
| N4 |  0/O alternatives retained | No confident false positive, or explicit typed ambiguity/refusal |
| N5 |  unsafe regex rejected | No confident false positive, or explicit typed ambiguity/refusal |

Run provenance, canonicalisation, cancellation and source-hash mismatch tests as additional invariants. Validate on at least five fresh independent real examples if cleared. Maintain benchmark counts as `NOT_RUN` until actually executed.

### Pseudocode skeleton

```python
def analyse(source, evidence, params, cancel):
    validate_source_hash_and_coordinate_frame(source, evidence)
    candidates = spatially_prune(evidence, params)
    proposals = []
    for region in sorted(candidates, key=stable_region_id):
        cancel.check()
        observed = compute_observed_features(region, params)
        if sufficient_evidence(observed, params):
            proposals += rank_hypotheses_with_source_links(observed)
        else:
            proposals += [typed_unknown(region, reason='INSUFFICIENT_EVIDENCE')]
    return immutable_versioned_analysis(proposals, source, params)
```

`compute_observed_features`, `sufficient_evidence` and `rank_hypotheses_with_source_links` are **to be implemented** with the domain procedure above, not placeholder proof of completion.
