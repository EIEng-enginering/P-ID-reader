# ALG-03 — Text Regions And Ocr

**State:** OPINION / proposed algorithm, not executed in the current codebase. **Related research:** RQ-11,RQ-13,RQ-14; compare `01_RESEARCH_REPORT`. No independent accuracy claim.

## Purpose and I/O

**Purpose:** Find all informative text locations and reread small outlined text locally.

**Inputs:** native text polygons, glyph clusters, rendered tile cache.

**Outputs:** oriented text ROIs, OCR N-best tokens, crop transform. Every output SHALL carry immutable source SHA-256, page, source geometry IDs and original normalised bounding polygon, producer/version, alternatives and score kind. All interpretations begin `PROPOSED_UNVERIFIED`.

## Procedure

1. Validate inputs against source SHA, coordinate transforms and resource limits. Preserve original drawing primitives before filtering.
2. Build bounded spatial indices and input-object candidate sets, pruning clearly unrelated elements before expensive matching.
3. **Domain procedure:** Merge overlapping glyph baselines into ROIs; include table cells and bubble interiors; render ROI with local rotation to minimum 30 px x-height; run Tesseract first; optional offline model compares rank; keep raw candidates.
4. Return all plausible alternatives with raw evidence; do not invent missing field values and do not accept graph connectivity from unclear linework.
5. Sort by reproducible feature scores then stable source IDs; serialise with canonical JSON and a separate analysis version.
6. Annotate `UNKNOWN`, `AMBIGUOUS` or `UNREADABLE` wherever preconditions do not hold. Store effective source revision and reviewer outcome independently.

## Proposed parameters (tune only on development gold)

`xheight_target=30px; crop_padding=0.35xheight; rotations=0,90,180,270 plus local ±15deg; roi_budget=500 per page`.

Default rationale: conservative CPU-first behaviour prioritising safety from false connectivity; these numbers are initial experiment settings, not engineering standards and not measured optimal values. Expose them through versioned configuration and record selected values in provenance. Define safe bounds and reject invalid config.

## Complexity and resource envelope

O(R*C) crops where C OCR cost; resource limited. Processing is tile-bounded and cancellable. Raise a typed `RESOURCE_LIMIT` with coverage area on exceeding budgets; never silently omit a region. Cache intermediate immutable artefacts by source SHA + algorithm/model version + config SHA.

## Failure modes / refusal policy

OCR misreads tiny fractions or runs out of crop budget; flag coverage. All unresolved outcomes must be visible in summary coverage. Do not flatten ambiguous results into a single accepted plant fact.

## Test-first fixtures and expected results

| Case | Synthetic input / setup | Expected result |
|---|---|---|
| P1 | PIT above 101 crop | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P2 |  vertical NPS 20 | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P3 |  outlined line 200-2 | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P4 |  station data numeric cell | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P5 |  rotated title text | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| N1 | CAD stroke with no readable letters UNKNOWN | No confident false positive, or explicit typed ambiguity/refusal |
| N2 |  schematic wire not OCR region | No confident false positive, or explicit typed ambiguity/refusal |
| N3 |  reversed page not all words reversed | No confident false positive, or explicit typed ambiguity/refusal |
| N4 |  model download denied | No confident false positive, or explicit typed ambiguity/refusal |
| N5 |  unlicensed model disabled | No confident false positive, or explicit typed ambiguity/refusal |

Run provenance, canonicalisation, cancellation and source-hash mismatch tests as additional invariants. Validate on at least five fresh independent real examples if cleared. Maintain benchmark counts as `NOT_RUN` until actually executed.

### Pseudocode skeleton

```python
def analyse(source, evidence, params, cancel):
    validate_source_hash_and_coordinate_frame(source, evidence)
    candidates = spatially_prune(evidence, params)
    proposals = []
    for region in sorted(candidates, key=stable_region_id):
        cancel.check()
        observed = compute_observed_features(region, params)
        if sufficient_evidence(observed, params):
            proposals += rank_hypotheses_with_source_links(observed)
        else:
            proposals += [typed_unknown(region, reason='INSUFFICIENT_EVIDENCE')]
    return immutable_versioned_analysis(proposals, source, params)
```

`compute_observed_features`, `sufficient_evidence` and `rank_hypotheses_with_source_links` are **to be implemented** with the domain procedure above, not placeholder proof of completion.
