# ALG-19 — Graph Export And Dexpi

**State:** OPINION / proposed algorithm, not executed in the current codebase. **Related research:** RQ-01,RQ-02,RQ-03; compare `01_RESEARCH_REPORT`. No independent accuracy claim.

## Purpose and I/O

**Purpose:** Export honest engineering data without importing legal/semantic liabilities.

**Inputs:** reviewed graph, export config, DEXPI XSD.

**Outputs:** CSV/XLSX/JSON/GraphML/SVG/experimental DEXPI XML + sidecar. Every output SHALL carry immutable source SHA-256, page, source geometry IDs and original normalised bounding polygon, producer/version, alternatives and score kind. All interpretations begin `PROPOSED_UNVERIFIED`.

## Procedure

1. Validate inputs against source SHA, coordinate transforms and resource limits. Preserve original drawing primitives before filtering.
2. Build bounded spatial indices and input-object candidate sets, pruning clearly unrelated elements before expensive matching.
3. **Domain procedure:** Map allowed graph types to exact DEXPI 2.0.1 classes; omit unsupported fields; validate schema, unit types, ID refs; roundtrip local canonical subset.
4. Return all plausible alternatives with raw evidence; do not invent missing field values and do not accept graph connectivity from unclear linework.
5. Sort by reproducible feature scores then stable source IDs; serialise with canonical JSON and a separate analysis version.
6. Annotate `UNKNOWN`, `AMBIGUOUS` or `UNREADABLE` wherever preconditions do not hold. Store effective source revision and reviewer outcome independently.

## Proposed parameters (tune only on development gold)

`dexpi_version=2.0.1; allow_unreviewed_export=False; sidecar_required=True; schema_check_required=True`.

Default rationale: conservative CPU-first behaviour prioritising safety from false connectivity; these numbers are initial experiment settings, not engineering standards and not measured optimal values. Expose them through versioned configuration and record selected values in provenance. Define safe bounds and reject invalid config.

## Complexity and resource envelope

O(V+E+export). Processing is tile-bounded and cancellable. Raise a typed `RESOURCE_LIMIT` with coverage area on exceeding budgets; never silently omit a region. Cache intermediate immutable artefacts by source SHA + algorithm/model version + config SHA.

## Failure modes / refusal policy

Wrong types or absent info may be mistaken for plant assertion. All unresolved outcomes must be visible in summary coverage. Do not flatten ambiguous results into a single accepted plant fact.

## Test-first fixtures and expected results

| Case | Synthetic input / setup | Expected result |
|---|---|---|
| P1 | piping segment number | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P2 |  valve class | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P3 |  port identity | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P4 |  sidecar reference | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| P5 |  roundtrip pump/pipe graph | Appropriate source-backed hypothesis emitted; no unreviewed acceptance |
| N1 | SIL field omitted | No confident false positive, or explicit typed ambiguity/refusal |
| N2 |  inferred line unreviewed excluded | No confident false positive, or explicit typed ambiguity/refusal |
| N3 |  invalid ID fails | No confident false positive, or explicit typed ambiguity/refusal |
| N4 |  missing XSD blocks conformance | No confident false positive, or explicit typed ambiguity/refusal |
| N5 |  formula injected CSV escaped | No confident false positive, or explicit typed ambiguity/refusal |

Run provenance, canonicalisation, cancellation and source-hash mismatch tests as additional invariants. Validate on at least five fresh independent real examples if cleared. Maintain benchmark counts as `NOT_RUN` until actually executed.

### Pseudocode skeleton

```python
def analyse(source, evidence, params, cancel):
    validate_source_hash_and_coordinate_frame(source, evidence)
    candidates = spatially_prune(evidence, params)
    proposals = []
    for region in sorted(candidates, key=stable_region_id):
        cancel.check()
        observed = compute_observed_features(region, params)
        if sufficient_evidence(observed, params):
            proposals += rank_hypotheses_with_source_links(observed)
        else:
            proposals += [typed_unknown(region, reason='INSUFFICIENT_EVIDENCE')]
    return immutable_versioned_analysis(proposals, source, params)
```

`compute_observed_features`, `sufficient_evidence` and `rank_hypotheses_with_source_links` are **to be implemented** with the domain procedure above, not placeholder proof of completion.
