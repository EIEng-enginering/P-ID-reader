# 08 — Independent benchmark and evaluation programme

## Status and starting evidence

The user-supplied pack describes 120 synthetic drawings (90 dev, 30 internal reserve) but **no independent industrial gold standard**. The cited 1582/1582 synthetic tags and zero scanned-valve recovery are **reported developer regression results**, not independently replicated here. Forty-six of 47 sampled public sheets were read, one worker terminated abnormally, and 12 of 46 geometry analyses exceeded the 4,000-stroke cap. Do not confuse throughput with accuracy.

## Acquisition and rights

1. Catalogue the locally referenced 608 public sheets, retaining owner/operator, URL, permitted access, copyright, training/export/republication rights and facility/style label. Public access does **not** imply redistribution or training rights.
2. Select a 20–30-sheet pilot (5 native text, 5 outlined, 5 raster, 5 dense and additional mixed/rotated), only from authorised data.
3. Expand to **at least 120 independent labelled drawings**, including **at least 30 untouched final** sheets. Use split by drawing family, facility, site and revision, not random crops; no near-duplicate leakage.
4. Independent human labels for equipment, valves, instrument functions, tags, all relevant line IDs, line segments, junctions, flow arrows, off-page links, tables and metadata. Each item stores source hash, page, polygon, label, reviewer, confidence, adjudication and omitted/illegible state.
5. Adjudicate disagreement by a second engineer. Measure inter-annotator agreement; use double annotation for safety-relevant graph edges and 20% of all random sheets, *proposed minimum to validate*. Reviewers who label final test sheets must not consult AI preannotations; final set remains sealed.

## Primary metrics and definitions

- Tag **exact match** = exact canonical string after documented presentation-only normalisation; preserve raw OCR separately.
- Symbol detection TP at polygon/box IoU≥0.5 AND correct class. Class precision TP/(TP+FP), recall TP/(TP+FN); separately report UNKNOWN/abstained coverage.
- **Silent-miss rate** = count of ground-truth entities not included in proposed output *and not flagged by a missing-coverage warning*, divided by number of ground-truth entities. This must be measured explicitly.
- **Graph edge precision/recall** = accepted/recommended connectivity compared to independently annotated graph; distinguish unresolved abstentions from incorrect positive edges. A false 'connected' edge is more dangerous than an explicit unknown.
- Off-page exact-pair match, line ID segment association, loop membership accuracy, title field exact match and data-table cell agreement separately.
- Per-sheet quality percent = correctly transcribed applicable labelled entities/edges (define class weights before test). **Never** hide large differences behind an aggregate.
- 95% bootstrap confidence intervals resampling drawings (not individual objects) with 2,000 resamples. Report estimate, CI, n drawings and n ground-truth events per class/style.
- Runtime: median/P90/max wall time, RSS peak, CPU time, threads, disk cache and fallback incidence on 4-core 16GB Windows 11 CPU.

## Provisional acceptance thresholds (OPINION — calibrate after pilot)

| Stage | Proposed threshold | Conditions / non-claim |
|---|---|---|
| MCR review-assisted register | ≥95% precision for *displayed high-confidence* tags and ≥80% tag recall on the explicitly supported pilot style(s) | Candidate gates, not actual performance; report uncovered styles |
| OCR improvements | Demonstrable gain over WIN-R01 baseline with no increased false confident tags | Compare same independently annotated drawings, paired per sheet |
| Raster valves | Non-zero detected valves on scanned synthetic regression and improvement on independently labelled real scans | Does not imply accepted industrial valve recall |
| Graph review aid | ≥99% precision for edges labelled 'connected on drawing' *without requiring human intervention* in a sufficiently populated held-out sample | For insufficient data, require review-only; all plain X unresolved |
| DEXPI 2.0.1 | 100% XSD/schema validation on released supported subset; all unsupported fields omitted | Semantic and roundtrip gates also required, no data-based plant guarantee |
| Windows | 100% mandatory installer, database restore, host regression and licence gates PASS | Independent industrial accuracy remains separate gate |

These are **proposed product gates**, not published industry thresholds or achieved figures. If the data do not support a CI or threshold, say `NOT_RUN`, `BLOCKED` or `INSUFFICIENT_SAMPLE`; do not lower standards quietly.

## Assessment protocol

1. Freeze software commit, models/hashes, grammar/profile, benchmark labels and evaluation script before final test.
2. Run every sheet in an offline environment without internet. Record every exception and skipped region.
3. Compute per-class TP/FP/FN, misleading confidence, missed regions, graph edge truth and reviewer minutes.
4. Compute CIs and stratify by vector-text, outlined, scanned, dense and mixed; report 30-final-sheet limits clearly.
5. Show confusion matrices and top 20 catastrophic examples with exact source boxes and failure reasons; do not publish copyrighted images without permission.
6. Independent engineer signs engineering reading limitations and permitted use; safety credit is never implied.

## Anti-bias safeguards

The 30 held-out sheets must not be used in prompt tuning, choosing recognition thresholds, evaluating optional pretrained models, selecting OCR engines, generating synthetic lookalikes, or manual corrective library construction. Data-custodian controls access. Use synthetic fixtures only for algorithm regression. Calibration (isotonic/Platt) uses development data; UI percentages are forbidden for uncalibrated heuristics.

## Reporting template per release

`release/version`, `git_commit`, `model_hashes`, `rights_manifest`, `gold_version`, `train_dev_test_split_sha256`, `per_class_precision_recall`, `silent_miss_rate`, `graph_false_positive_edges`, `unresolved_rate`, `CPU_runtime`, `reviewer_minutes`, `confidence_intervals`, `known_coverage_gaps`, `independent_approver`, `PASS_FAIL_BLOCKED_NOT_RUN`.
