# Reference register — researched through 7 November 2026

Evidence labels: **VERIFIED** means the named claim or document was checked at the listed URL, *not* that a model has been validated on this P&ID corpus. **UNVERIFIED** flags a prospective claim. All external sources were accessed on **2026-11-07**. Do not redistribute source documents or model weights without checking their own licence terms.

| ID | Source / publisher | Version / date | Verification | URL | Scope and limitation |
|---|---|---|---|---|---|
| REF-01 | DEXPI Specification 2.0.1 — DEXPI Initiative | 2026-09-30 | VERIFIED | https://dexpi.org/specification/2.0.1/html/index.html | CC BY 4.0 specification; not equivalent to licence for third-party data/graphics |
| REF-02 | DEXPI Specifications download page — DEXPI Initiative | 2026 | VERIFIED | https://dexpi.org/specifications/ | 2.0.1 replaces 2.0 |
| REF-03 | DEXPI XML schema and exchange format — DEXPI Initiative | 2026 | VERIFIED | https://dexpi.org/specification/2.0.1/html/basics/metamodel_and_exchange_format.html | Model root and XML schema; obtain pinned XSD/test assets during WP-10 |
| REF-04 | PipingNetworkSegment class — DEXPI Initiative | 2026 | VERIFIED | https://dexpi.org/specification/2.0.1/html/models/Plant/Piping/PipingNetworkSegment.html | SegmentNumber, FluidCode, NominalDiameterRepresentation, PipingClassCode and typed associations |
| REF-05 | Instrumentation package — DEXPI Initiative | 2026 | VERIFIED | https://dexpi.org/specification/2.0.1/html/models/Plant/Instrumentation/package-index.html | Function classes; does not imply plant safety verification |
| REF-06 | pyDEXPI 2.1.0 release — PyPI / pyDEXPI authors | 2026-11-01 | VERIFIED | https://pypi.org/project/pyDEXPI/2.1.0/ | Implements DEXPI 2.0.1, AGPL-3.0; exclude from proprietary runtime absent legal approval |
| REF-07 | pyDEXPI licensing — Process Intelligence Research | 2026 | VERIFIED | https://github.com/process-intelligence-research/pyDEXPI/blob/master/LICENSE | AGPL-3.0 code; do not copy source into permissive exporter |
| REF-08 | ISA5.1 committee scope / recent editions — International Society of Automation | 2024-2026 | VERIFIED | https://www.isa.org/standards-and-publications/isa-standards/isa-standards-committees/isa5-1 | ANSI/ISA-5.1-2024, TR5.1.02 and .03 |
| REF-09 | ISA-5.1 product IP and AI-use notice — International Society of Automation | 2026 | VERIFIED | https://www.isa.org/products/ansi-isa-5-1-2024-instrumentation-and-control-symb | Explicit ISA-IP AI tool use restrictions; do not copy protected text/symbols |
| REF-10 | Shapely STRtree API — Shapely contributors | 2026 | VERIFIED | https://shapely.readthedocs.io/en/stable/manual.html | Query-only immutable spatial index; query candidates then evaluate predicates |
| REF-11 | Tesseract OCR — Tesseract contributors | 2026 | VERIFIED | https://tesseract-ocr.github.io/tessdoc/ | Apache-2.0 OCR engine; tessdata/redistribution separately verify |
| REF-12 | PaddleOCR code and licensing — PaddlePaddle | 2026 | VERIFIED | https://github.com/PaddlePaddle/PaddleOCR | Apache-2.0 code; particular model artefacts/platform wheel need verification |
| REF-13 | ONNX Runtime Windows and install — Microsoft / ONNX Runtime | 2026 | VERIFIED | https://onnxruntime.ai/docs/get-started/with-windows.html | CPU baseline; WinML preferred for new Windows integration; DirectML sustained engineering |
| REF-14 | OpenCV code licence — OpenCV Foundation | 2026 | VERIFIED | https://opencv.org/license/ | Apache-2.0 for versions >=4.5.0 |
| REF-15 | PySide6 deployment — Qt Company | 2026 | VERIFIED | https://doc.qt.io/qtforpython-6/deployment/index.html | pyside6-deploy; full Windows packaging remains NOT_RUN |
| REF-16 | Qt licensing — Qt Company | 2026 | VERIFIED | https://doc.qt.io/qt-6.12/licensing.html | LGPLv3 or commercial route; legal review for proprietary distribution |
| REF-17 | pikepdf library licence — pikepdf contributors | 2026 | VERIFIED | https://github.com/pikepdf/pikepdf | MPL-2.0 for pikepdf; notices and changed-file obligations |
| REF-18 | ezdxf manual — ezdxf contributors | 2026-10-16 | VERIFIED | https://ezdxf.readthedocs.io/en/stable/ | MIT; DXF support, not native DWG/DGN |
| REF-19 | CVAT Community documentation — CVAT | 2026 | VERIFIED | https://docs.cvat.ai/docs/getting_started/overview/ | MIT-licensed core and self-hosted option; deployment dependencies check |
| REF-20 | Ultralytics licensing — Ultralytics | 2026 | VERIFIED | https://www.ultralytics.com/license | AGPL-3.0 or commercial licence; exclude absent approval |
| REF-21 | From Engineering Diagrams to Graphs — IEEE DSAA / arXiv authors | 2025 | VERIFIED | https://doi.org/10.48550/arXiv.2411.13929 | Graph-level P&ID research; reported results are dataset-specific; dataset licence needs audit |
| REF-22 | ISA-5 standards catalogue — International Society of Automation | 2026 | VERIFIED | https://www.isa.org/standards-and-publications/isa-standards/isa-5-standard | ISA-TR5.1.04-2026; do not ingest copyrighted standard in AI tooling |
| REF-23 | DEXPI PipingNetworkSystem class — DEXPI Initiative | 2026 | VERIFIED | https://dexpi.org/specification/2.0.1/html/models/Plant/Piping/PipingNetworkSystem.html | Segments composition and piping network semantics |
| REF-24 | pypdf/pdfplumber benchmarks — py-pdf maintainers | 2026 | VERIFIED | https://github.com/py-pdf/benchmarks | Library licence matrix; locally verify pinned builds |
| REF-25 | DEXPI specification GitLab releases — DEXPI Initiative | 2026-09-30 | VERIFIED | https://gitlab.com/dexpi/Specification/-/tags | 2.0.1 release tag |
| REF-26 | Label Studio Community comparison — HumanSignal | 2026 | VERIFIED | https://labelstud.io/guide/label_studio_compare | Local annotation options; enterprise roles not assumed in community edition |

## Source-class boundaries

- `INTERNAL-EVID-01`: supplied research pack `03_EVIDENCE_AND_FAILURE_ANALYSIS.md`; evidence is **author-reported developer measurements**, not independent test results.
- `INTERNAL-EVID-02`: supplied `02_CURRENT_SYSTEM_DETAILED.md` and `evidence/WIN_R01_STATUS.md`; design baseline and reported feature availability, **not retested in this specification package**.
- `INTERNAL-DEC-01`: user's approved Q1–Q5 Option A and all compatible IDEA-01…IDEA-45; no new approval necessary for reversible coding, but legal permissions and external acceptance are still required.
- Standards documentation: public DEXPI specification is CC BY 4.0 per REF-01; this does not license ISA graphics, proprietary PDFs, third-party software or models.
- This research pack contains no licensed original ISO/ISA/PIP symbol drawings and must not recreate restricted graphics or ingest ISA standards into AI tools (REF-09).
