# Digital exports and DEXPI 2.0.1 validation

**State:** proposed contracts and example data, not implemented DEXPI export. **Default policy:** only explicit `REVIEWED_DRAWING` values may appear in a final reviewed engineering register; proposed items can be exported in a separately labelled draft report.

## Register minimum columns

| Output | Minimum columns |
|---|---|
| Equipment list | drawing_id, drawing_revision, equipment_tag, proposed_class, source_page, bbox, evidence_ids, review_state, uncertainty, source_sha256 |
| Valve list | tag, proposed_subtype, actuator_candidate, upstream_port, downstream_port, reviewer, source_sha256, review_state |
| Instrument index | instrument_tag, variable, function, loop_number, bubble_class, source_bbox, connected_signal_candidate, review_state |
| Line list | raw_line_number, parsed_diameter_text, service, sequence, spec_class, candidate_path_ids, breaks, review_state |
| Loop sheet | loop_key, member tags, evidence_of_signal_edges, missing_roles, unresolved_alternatives, no_safety_credit |
| Nozzle schedule | equipment_tag, nozzle_label, port_candidate, line_ref, confidence_kind, source_bbox, review_state |
| Notes/HOLDS | note_id, raw_text, drawing_number, region_bbox, linked_objects, review_state |
| Sheet index | drawing_number, revision, date_text, title, source_sha256, titleblock_evidence, review_state |
| Revision changes | old_source_sha, new_source_sha, changed_label, change_type, ambiguity_reason, reviewer |

CSV/Excel escaping: if a string starts with `= + - @` or contains leading control characters, prefix a literal apostrophe for spreadsheet-compatible exports and log the escaping policy. Use ZIP-safe entries and no macros. Files must embed a report manifest with source hashes, algorithm versions and omitted regions. Unknowns remain visibly unknown.

## Graph adapters

- Canonical JSON v1 is lossless, deterministic and source-linked; no node or port omission. Validate JSON Schema and semantic references.
- GraphML uses stable node/edge IDs and attribute keys; store provenance JSON in typed attributes/sidecar; no implicit direction when `UNKNOWN`.
- JSON-LD carries a custom, versioned ontology in an original namespace; do **not** claim equivalence to ISO 15926 or OPC UA unless that adapter is separately validated.
- SVG semantic overlay uses IDs as `data-*` attributes with escaped user text; annotated PDF must never overlay source and claim it is updated as-built.

## DEXPI 2.0.1

1. Pin the actual DEXPI Specification 2.0.1 XML Schema and reference cases from REF-01/03/25; record SHA-256 and attribution. Do not guess class/property names.
2. Maintain a field-level mapping register in `03_CANONICAL_GRAPH_SCHEMA/dexpi_2_0_1_field_mapping.csv`. It is a **candidate design**; WP-10 confirms each mapping against the pinned official 2.0.1 model.
3. Represent only reviewed drawing evidence where the DEXPI class and association are justified. Leave manufacturer, maintenance, live process state and SIL/IPL unspecified. Do not populate `ProcessSafetyFunction` just because a protective-looking instrument tag exists.
4. Provide `sidecar.evidence.json` with the exact canonical graph SHA, exported object IDs, source boxes, unresolved alternatives and reviewer identities. Sidecar is not a substitute for normative DEXPI validation.
5. Validate XSD, ID/IDREF, typing, required class associations, units, graphical representations, and import-export roundtrip on supported subset. Produce a machine-readable failure report.
6. **Licence gate:** official DEXPI 2.0.1 specification CC BY 4.0 with attribution; `pyDEXPI 2.1.0` is AGPL-3.0. Do not import pyDEXPI into a proprietary runtime without legal approval. A clean-room original adapter against public specification is preferred.

### When to claim DEXPI conformance

Only after a pinned 2.0.1 implementation emits files validated against official schema + reference semantic checks and independently tested roundtrip. Until then label `experimental DEXPI-oriented mapping`, not `conformant DEXPI file`.

### Worked S023 examples (from user's supplied visually checked case, not independent gold)

- Proposed instrument tags: `ZSC-201`, `ZSO-201`, `FMV-201`, `PSHH-201`, `PIT-101`, `PY-102`, `ZT-102`, `PIT-100`, `PIC-102`, `PCV-102`; retain OCR shapes and `0` leading digit as raw source. Does not by itself prove a control loop.
- Proposed line labels `NPS 20`, `NPS 30`, `NPS 16`, `NPS 1 1/2`: emit as raw nominal-size text; attach to pipes only after path-evidence association.
- Proposed continuation `LINE 200-2`: off-page link stays `UNRESOLVED` until target drawing/line and revision are identified.
- Labelled `HEATER 36000 BTU`, `PRESSURE REDUCTION MANIFOLD`, `PLC` and `SCADA` regions become separate block/annotation hypotheses; don't invent the equipment's datasheet.
- `STATION DATA`, revision C, set-point clouds, HOLD and references are structured *document observations*, not as-built values.
