# 02 — Target architecture (Rev A)

**Status:** design proposal. All rich classes are standalone `graph_schema_version=1`; Worksheet R1 schema, deterministic ID rules and canonical hashing remain byte-for-byte frozen.

## Modules and stages

| Stage | Proposed module | Inputs | Immutable output | Cache key |
|---|---|---|---|---|
| 0 | `security/sandbox.py` | arbitrary PDF bytes | `SourceDocument`, SHA-256, typed failure | PDF digest + limits version |
| 1 | `formats/page_probe.py` | source | PDF page transforms, fonts, OCG/XObject, native text coverage | source hash + probe version |
| 2 | `vision/regions.py` | vector+raster preview | text/symbol/table/note ROIs incl. angle | page hash + ROI engine |
| 3 | `vision/ocr_dispatch.py` | ROI image, permitted engine | N-best text/token candidates w/ exact polygon | source+crop+engine/model/params hash |
| 4 | `geometry/primitives.py` | pdf drawing ops | lines, arcs, polycurves, fills, raster strokes | source+geometry version |
| 5 | `geometry/tiler.py` | primitives, text mask | per-tile indices and stitched segments | primitive hash + tiling config |
| 6 | `recognition/symbols.py` | region+geometry+catalog | symbol class alternatives, ports, matching evidence | catalog hash + model hash |
| 7 | `recognition/page_fields.py` | text+layout+geometry | title block/revision/table/legend/notes | text hash + page template |
| 8 | `engineering/relationships.py` | symbols/text/line mesh | candidate lines, junction alternatives, directed edges | all dependencies + algo version |
| 9 | `engineering/graph_v1.py` | observed candidates | revision-frozen evidence graph + alternatives | dependency manifest + review snapshot |
| 10 | `engineering/review.py` | graph hypotheses | named decisions, re-analysis impacts | append-only, audit hash chain |
| 11 | `export/` | reviewed graph | XLSX/CSV/JSON/SVG/DEXPI adapter | graph hash + exporter version |
| legacy | `api.py`/`worker.py` | frozen R1 request | **unchanged** R1 JSON only | unchanged canonical rules |

Do not require PySide6 in headless stages. Use a typed `PageTransform` with 3×3 homogeneous affine matrices: PDF media/crop/render pixel/normalised coordinates, inversion tested at all four rotations; reject noninvertible matrices. Distinguish display coordinates from source coordinates. Every observation stores `pdf_sha256`, `page_index`, `bbox_normalized`, `coordinate_frame_id`, `source_refs`, `producer`, `producer_version`, `config_sha256` and `review_state`.

## Suggested Python interfaces

```python
from dataclasses import dataclass
from typing import Protocol, Mapping, Sequence

@dataclass(frozen=True)
class AnalysisConfig:
    version: str
    offline: bool = True
    ocr_engines: tuple[str, ...] = ('tesseract',)
    max_pdf_bytes: int = 16 * 1024 * 1024   # frozen R1 limit; do not relax
    max_pdf_pages: int = 500                  # frozen R1 limit
    crop_target_xheight_px: int = 30         # proposed, tune
    tile_size_px: int = 1536                 # proposed, tune
    tile_overlap_px: int = 128              # proposed, tune
    max_workers: int = 2                    # proposed for 4-core laptop

class Detector(Protocol):
    def model_card(self) -> Mapping: ...
    def analyse(self, page_evidence: Mapping, cfg: AnalysisConfig) -> Sequence[Mapping]: ...


def analyse_document(pdf_bytes: bytes, cfg: AnalysisConfig, cancel=None) -> Mapping: ...
def merge_graph(observations: Sequence[Mapping], decisions: Sequence[Mapping]) -> Mapping: ...
def export_graph(graph: Mapping, fmt: str, *, include_proposed: bool = False) -> bytes: ...
```

Actual frozen `read_pid(pdf_bytes, params, cancel=None)` and worker must remain unmodified except separately reviewed bug fixes that preserve R1 behaviour. All future host enrichments use new APIs/sidecars; do not insert new required fields or expanded types in R1 output.

## Detector plug-in admission

Each plug-in declares `id`, semantic version, model SHA-256 (if applicable), code licence SPDX, model licence URL, complete dependency SBOM, tested Windows/Python/CPU status, local file-only mode, declared output types, calibration status, and limits. Reject if licence is `UNKNOWN`, `AGPL`, `GPL`, `NONCOMMERCIAL` or network required under a proprietary default build. Treat PySide6 LGPL as a separately reviewed platform exception, *not* blanket copyleft approval. Pin lockfile hashes, forbid auto-download at run time, and accept models only from a signed/hashed install manifest.

## Identity, versioning and audit

- Observation identity: `sha256(canonical_json([source_digest,page,producer_version,quantized_bbox,primitive_ids,type]))`; quantisation 1e-6 normalized; no floats `NaN`, `Infinity`.
- Engineering entity identity is separate from observations. An entity may have alternatives across drawings/revisions; never equate identical tag strings automatically.
- Raw OCR, geometry and model proposals are immutable; user correction creates a new reviewed interpretation referencing originals.
- Every review decision requires reviewer ID, timestamp, rationale, selected proposal IDs, drawing hash, previous audit hash. Use SQLite transaction commit and pre-migration backup.
- Explicit state enumeration: `PROPOSED_UNVERIFIED`, `REVIEWED_DRAWING`, `REJECTED`, `SUPERSEDED`. `REVIEWED_DRAWING` does **not** mean as-built verified.
- Confidence: `score_kind=HEURISTIC` or `CALIBRATED`, with calibration dataset + version; do not label heuristics as probabilities.
- Edges: `CONNECTS_ON_DRAWING`, `SIGNAL_LINE_CANDIDATE`, `OFFPAGE_MATCH_CANDIDATE`, `NO_CONNECTION`, `UNKNOWN` with reviewer decision; flow direction may be `UNKNOWN`.

## Sandboxing and resource controls

Worker restricts RAM/CPU/runtime, oversized compressed streams, excessive image dimensions and object recursion; fail closed. Windows Job Objects allow resource controls but are **not a sufficient security sandbox alone**. Research AppContainer/low-integrity execution separately as a gated experiment. Never deserialize arbitrary pickle or spawn shell commands derived from PDFs. Isolated OCR model processes receive only local staged crops, and cannot call external URLs. Source files and analysis stores remain outside sync high-write paths. Zero network telemetry by default.

## Cache invalidation and incremental updates

Cache manifest JSON includes source hash, page crop/rotation transform hash, detector versions and hashes, per-region checksum, OCR model, template library version and review snapshot. Re-evaluate only downstream dependent artifacts after a symbol library change; never rewrite prior review history. Prior page snapshots remain queryable. Use a content-addressed cache directory with atomic writes + garbage collection; bound disk budget by project and keep original PDFs indefinitely unless owner instructs.

## Graph construction and semantics

Use typed nodes with explicit ports, not a graph where all touching endpoints connect. For every candidate crossing create **either** `CONNECTS_ON_DRAWING` / `NO_CONNECTION` alternatives or `UNKNOWN` until visual evidence supports a choice. Suppress direct physical connectivity across uncertain crossings in standard graph traversal. Line number propagation only across edges accepted or strongly evidenced by explicit uninterrupted linework; tee or spec breaks stop propagation by default. Link off-page connectors via drawing+line reference plus reviewer acceptance, never string match alone.

## Export assurance

CSV must formula-escape untrusted initial `= + - @` and control characters; JSON canonical; SVG XML-escape text; HTML encode strings, avoid executing untrusted PDF content. GraphML and JSON-LD exports are secondary; DEXPI 2.0.1 XML is **experimental** until XSD, semantic checks and lossless subset round-trip pass. Save provenance/alternatives in a separate sidecar rather than inventing DEXPI fields.

## Performance gates (proposed, not measured)

4–8 CPU cores and 16GB RAM; default render tiles 1536 px with 128 px overlap; at most two OCR/model tasks concurrently to prevent oversubscription; 256 MiB per tile cache target; max decoded raster 12 million pixels per page in frozen R1 pipeline (new standalone may use safely tiled streaming under a separate bound). A typical sheet target <120 s and dense sheet target <600 s at defined quality settings are **goals**, not product claims. Report wall time, peak RSS, peak threads and fallback modes on actual Windows laptops.
