# Finite tag and line grammars

The grammar catalogue is deliberately *declarative*; it must not evaluate arbitrary user-defined regex or Python code. Token parser implementation must enforce `max_chars`, `max_segments`, per-token types, alphanumeric choices, and unit/size parser bounds. `NPS 1 1/2` and `DN 100` are distinct unit forms; no conversion inferred without explicit settings. `PG`/`IF` can be generic unnumbered labels rather than uniquely identified instruments. `0 PIT 101` only normalises under a separately approved company style setting. String occurrence alone never proves plant item class.

The included examples are **expected tests**, not parser results. Any new company grammar is versioned and reviewed before activation. Save all raw OCR candidates, not just the best grammar match. See RQ-05, 15–17 and ALG-04/11.
