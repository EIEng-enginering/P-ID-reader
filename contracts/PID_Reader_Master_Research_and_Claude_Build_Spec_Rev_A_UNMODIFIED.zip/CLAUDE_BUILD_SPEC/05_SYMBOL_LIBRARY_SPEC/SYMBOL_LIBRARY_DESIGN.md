# Original symbol library: design and legal constraints

**Status:** experimental independently described generic geometric prototypes, not standards-certified drawings or copies of ISA/ISO/PIP symbol sheets. No model training is necessary. See `original_starter_templates.json` for 20 original parameterised prototypes with coordinates, candidate ports, negative confounders, transforms and tolerances. These are **not operational recognition results**; Claude must implement matching and test the templates.

## Matching/teaching method

1. Parse the original polygon/arc/rect/line primitives; transform under allowed scale/rotation/mirror.
2. Create fill-aware vector descriptor plus optional local binary-mask descriptor. Independently check line context and source evidence.
3. Include non-symbol rejection: ordinary X crossing, title box, note cloud, arrowhead and text glyph candidates. A graphic subtype requires distinct evidence; a matched circle alone is not a pump or actuator.
4. Use project-authorised legend sheets to propose symbol exemplars. A reviewer boxes glyph+caption and confirms mapping to a **new project library version**. Preserve raw source, keep reviewer identity and provenance. Existing audits are immutable.
5. Few-shot teaching uses descriptor matching; it does not change model weights. Every newly found symbol remains `PROPOSED_UNVERIFIED`.
6. If commercial standards graphics are the source, ensure organisation has explicit rights for this processing and reuse. ISA's product page restricts use in AI tools and derivative art; never copy restricted graphics as templates. Model or font download disabled at runtime.

## Review acceptance tests

For every template create 5 positive synthetic transforms, 5 hard negatives, plus at least 5 independently cleared real instances. Report top-1 class accuracy, abstention, confusion matrix and matching runtime. These remain `NOT_RUN` until executed.
