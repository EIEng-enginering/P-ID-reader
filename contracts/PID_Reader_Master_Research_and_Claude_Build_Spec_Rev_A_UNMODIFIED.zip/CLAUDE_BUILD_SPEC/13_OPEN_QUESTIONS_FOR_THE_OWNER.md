# 13 — Genuine external dependencies (not routine development approvals)

The user already approved all five Option A decisions and every compatible improvement idea. Claude should **not** re-ask those design decisions or routine coding choices. The following dependencies may still require human authority because code cannot create legal access or engineering ground truth.

| External dependency | Default if unavailable | Options and trade-offs | Responsible party |
|---|---|---|---|
| Rights to use labelled company drawings for independent benchmark | Use lawful original synthetic + authorised public documentation; report industrial gate BLOCKED | Legal clearance to use representative real drawings locally materially improves validity | Data owner/legal |
| Independent annotation review resources | Design tooling now, mark unperformed accuracy NOT_RUN | Assign second engineer or independent team; cannot be replaced with same model's labels | Engineering quality owner |
| Proprietary Qt distribution | Develop with PySide6 locally, keep external distribution pending | Comply LGPLv3 obligations or acquire Qt commercial licence | Legal / management |
| AGPL pyDEXPI or Ultralytics | Exclude from proprietary runtime | Optional explicit AGPL compliance or paid alternative; original DEXPI adapter preferred | Legal / management |
| Protected ISA/ISO/PIP symbol art | Never copy; use independent original templates | Obtain permissions for any restricted standard material before AI ingestion | Legal / IP owner |
| Host Worksheet source/integration rights | Freeze R1 contract and mark host integration NOT_RUN | Provide authorised matching host checkout and QA environment to run G4–G7 | Host owner |
| Third-party pretrained model redistribution | Use local permitted Tesseract or cleared ONNX only | Separate code and weights licences reviewed, or keep model optional | Legal / ML engineer |
| Publishing public drawing examples in deliverables | Exclude images by default | Permission/attribution audit before distribution | Data owner |

Do not claim these dependencies were approved by the user's blanket technical authorization.
