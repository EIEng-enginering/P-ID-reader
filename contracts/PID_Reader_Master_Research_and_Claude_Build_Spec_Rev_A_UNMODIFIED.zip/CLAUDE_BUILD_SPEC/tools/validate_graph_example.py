#!/usr/bin/env python3
"""Validate original *specification examples*, not the industrial reader's runtime correctness."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    import jsonschema
    sd=ROOT/'03_CANONICAL_GRAPH_SCHEMA'
    schema=json.loads((sd/'graph.schema.json').read_text())
    example=json.loads((sd/'synthetic_graph_example.json').read_text())
    jsonschema.Draft202012Validator.check_schema(schema)
    jsonschema.validate(example,schema)
    nid={n['id'] for n in example['nodes']}
    pid={p['id'] for p in example['ports']}
    eid={e['id'] for e in example['edges']}
    assert len(nid)==len(example['nodes']) and len(pid)==len(example['ports']) and len(eid)==len(example['edges'])
    assert all(p['owner_node_id'] in nid for p in example['ports'])
    assert all(e['from_port_id'] in pid and e['to_port_id'] in pid for e in example['edges'])
    assert all(e['review_state'] != 'REVIEWED_DRAWING' for e in example['edges']), 'sample must remain proposed'
    print('PASS: standalone canonical graph schema and synthetic example')
if __name__=='__main__': main()
