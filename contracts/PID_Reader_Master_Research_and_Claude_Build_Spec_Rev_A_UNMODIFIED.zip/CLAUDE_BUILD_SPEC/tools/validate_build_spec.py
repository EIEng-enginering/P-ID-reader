#!/usr/bin/env python3
"""Self-check the research artefacts only; does NOT validate a working P&ID reader."""
from pathlib import Path
import collections
import csv
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]


def csv_rows(name):
    with (ROOT / name).open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def check():
    failures=[]
    def assert_that(test, message):
        if not test: failures.append(message)

    required=[
        '00_INDEX_AND_EXECUTIVE_SUMMARY.md',
        '00_CLAUDE_CODE_MASTER_PROMPT.md',
        '02_ARCHITECTURE_SPEC.md',
        '03_CANONICAL_GRAPH_SCHEMA/graph.schema.json',
        '03_CANONICAL_GRAPH_SCHEMA/dexpi_2_0_1_field_mapping.csv',
        '03_CANONICAL_GRAPH_SCHEMA/other_export_field_mapping.csv',
        '04_ALGORITHM_SPECS',
        '05_SYMBOL_LIBRARY_SPEC/original_starter_templates.json',
        '06_TAG_AND_LINE_GRAMMARS/grammars.json',
        '07_EXPORT_SPECS/EXPORT_CONTRACTS.md',
        '08_BENCHMARK_AND_EVALUATION_PLAN.md',
        '09_DATASETS_MODELS_LIBRARIES_REGISTER.csv',
        '10_REQUIREMENTS.csv',
        '11_WORK_PACKAGES',
        '12_RISK_REGISTER.md',
        '13_OPEN_QUESTIONS_FOR_THE_OWNER.md',
        '14_GLOSSARY_AND_REFERENCES.md',
        'IMPROVEMENT_IDEA_TRACEABILITY.csv',
        'examples/S023_WORKED_ENGINEERING_CONTRACT.md',
        'tools/validate_graph_example.py',
    ]
    for fname in required:
        assert_that((ROOT/fname).exists(),f'missing {fname}')

    groups=sorted((ROOT/'01_RESEARCH_REPORT').glob('[A-I]_*.md'))
    found=[]
    for f in groups:
        ids=re.findall(r'^##\s+(RQ-\d{2})\b',f.read_text(encoding='utf-8'),flags=re.M)
        found+=ids
    assert_that(len(groups)==9,f'expected 9 research sections, found {len(groups)}')
    assert_that(collections.Counter(found)==collections.Counter(f'RQ-{n:02d}' for n in range(1,61)),f'RQ coverage duplicates/missing: {collections.Counter(found)}')
    trace=json.loads((ROOT/'01_RESEARCH_REPORT/RQ_TRACEABILITY.json').read_text(encoding='utf-8'))
    assert_that(len(trace)==60,'RQ traceability != 60')
    assert_that(set(trace)==set(found),'RQ traceability ID mismatch')

    algorithms=sorted((ROOT/'04_ALGORITHM_SPECS').glob('ALG-*.md'))
    assert_that(len(algorithms)==20,f'expected 20 algorithm specs, got {len(algorithms)}')
    for n,alg in enumerate(algorithms,1):
        txt=alg.read_text(encoding='utf-8')
        assert_that(bool(re.search(r'^## Test-first fixtures',txt,re.M)),f'missing fixtures in {alg.name}')
        for typ in ('P','N'):
            found_examples=re.findall(r'^\|\s*'+typ+r'\d+\s*\|',txt,re.M)
            assert_that(len(found_examples)>=5,f'{alg.name}: <5 {typ} cases')
        assert_that('Proposed parameters' in txt or 'Proposed parameter' in txt, f'{alg.name}: no parameter list')
        assert_that('Pseudocode' in txt,f'{alg.name}: no pseudocode')

    wps=sorted((ROOT/'11_WORK_PACKAGES').glob('WP-*.md'))
    assert_that(len(wps)==12,f'expected 12 work packages, got {len(wps)}')
    for f in wps:
        content=f.read_text(encoding='utf-8')
        assert_that('Claude Code build prompt' in content, f'no Claude prompt in {f.name}')
        assert_that('Measurable acceptance gate' in content, f'no acceptance gate in {f.name}')
        assert_that('PLANNED' in content, f'WP status not PLANNED: {f.name}')

    req=csv_rows('10_REQUIREMENTS.csv')
    reqids=[row['id'] for row in req]
    assert_that(len(req)>=180,f'expected >=180 requirements, got {len(req)}')
    assert_that(len(reqids)==len(set(reqids)),'requirement ID collision')
    assert_that(set(f'RQ-{i:02d}' for i in range(1,61)).issubset({row['source'] for row in req}), 'not all RQ used in requirements')
    for row in req:
        assert_that(row['statement'].startswith('The reader shall') or ' shall ' in row['statement'],f'non-shall statement: {row["id"]}')
        assert_that(row['priority'] in ('MUST','SHOULD','COULD'),f'bad priority: {row["id"]}')
        assert_that((ROOT/'11_WORK_PACKAGES'/(row['work_package']+'.md')).exists(),f'bad WP link: {row["id"]}')
        assert_that(bool(row['verification_method']),f'no verification method: {row["id"]}')

    ideas=csv_rows('IMPROVEMENT_IDEA_TRACEABILITY.csv')
    ideaids=[row['idea'] for row in ideas]
    assert_that(len(ideas)==45 and len(set(ideaids))==45, 'must account for all 45 ideas')
    for row in ideas:
        assert_that(bool(row['decision']) and bool(row['implementation_gate']),f'missing recommendation decision {row["idea"]}')
        assert_that((ROOT/'11_WORK_PACKAGES'/(row['work_package']+'.md')).exists(),f'bad WP link {row["idea"]}')

    library=json.loads((ROOT/'05_SYMBOL_LIBRARY_SPEC/original_starter_templates.json').read_text(encoding='utf-8'))
    templates=library['templates']
    assert_that(len(templates)>=20,f'expected >=20 independent templates got {len(templates)}')
    assert_that(len(set(t['id'] for t in templates))==len(templates),'duplicate template IDs')
    for tmpl in templates:
        assert_that(tmpl.get('primitives') and isinstance(tmpl.get('ports'),list),f'invalid template {tmpl["id"]}')

    grammar=json.loads((ROOT/'06_TAG_AND_LINE_GRAMMARS/grammars.json').read_text(encoding='utf-8'))
    profiles={p['id'] for p in grammar['profiles']}
    assert_that(len(profiles)>=4,'not enough grammar profiles')
    examples=csv_rows('06_TAG_AND_LINE_GRAMMARS/grammar_examples.csv')
    assert_that(len(examples)>=30,'not enough grammar test examples')
    assert_that(all(row['profile'] in profiles for row in examples),'grammar sample references unknown profile')

    libs=csv_rows('09_DATASETS_MODELS_LIBRARIES_REGISTER.csv')
    assert_that(len(libs)>=40,'library investigation short')
    for row in libs:
        assert_that(bool(row['licence_status']) and bool(row['decision']),f'library licensing/decision missing {row["name"]}')
    assert_that(len(csv_rows('03_CANONICAL_GRAPH_SCHEMA/dexpi_2_0_1_field_mapping.csv'))>=10,'DEXPI mapping too short')
    assert_that(len(csv_rows('03_CANONICAL_GRAPH_SCHEMA/other_export_field_mapping.csv'))>=20,'interchange mapping too short')

    for f in ROOT.rglob('*.json'):
        try: json.loads(f.read_text(encoding='utf-8'))
        except Exception as exc: failures.append(f'invalid JSON {f}: {exc}')
    for f in ROOT.rglob('*.csv'):
        try:
            with f.open(newline='', encoding='utf-8') as stream:
                rows=list(csv.reader(stream))
            if rows and any(len(row)!=len(rows[0]) for row in rows):
                failures.append(f'CSV uneven columns: {f}')
        except Exception as exc: failures.append(f'invalid CSV {f}: {exc}')

    try:
        import jsonschema
        schemas=ROOT/'03_CANONICAL_GRAPH_SCHEMA'
        for f in schemas.glob('*.schema.json'):
            jsonschema.Draft202012Validator.check_schema(json.loads(f.read_text(encoding='utf-8')))
        graph_schema=json.loads((schemas/'graph.schema.json').read_text(encoding='utf-8'))
        graph=json.loads((schemas/'synthetic_graph_example.json').read_text(encoding='utf-8'))
        jsonschema.validate(graph,graph_schema)
        ids=[v['id'] for k in ('nodes','ports','edges','hypotheses') for v in graph[k]]
        assert_that(len(ids)==len(set(ids)),'synthetic graph duplicate IDs')
        nodes={n['id'] for n in graph['nodes']}
        ports={p['id'] for p in graph['ports']}
        assert_that(all(p['owner_node_id'] in nodes for p in graph['ports']), 'graph port owner missing')
        assert_that(all(e['from_port_id'] in ports and e['to_port_id'] in ports for e in graph['edges']), 'graph edge port missing')
    except Exception as exc: failures.append('graph schema check failed: '+str(exc))

    if failures:
        for failure in failures: print('FAIL:',failure)
        print('FAILED:',len(failures),'specification checks')
        return 1
    print('PASS: 60/60 research questions across 9 groups')
    print('PASS: 45/45 improvement ideas traced')
    print(f'PASS: {len(algorithms)} algorithm designs with >=5 positive and >=5 negative cases each')
    print(f'PASS: {len(req)} unique requirements; {len(wps)} work packages with Claude prompts')
    print(f'PASS: {len(templates)} original symbol templates, {len(examples)} tag samples, {len(libs)} library/model records')
    print('PASS: JSON/CSV parse; graph schemas, example and foreign keys')
    print('PASS: required deliverable files and crossreferences')
    print('NOTE: these tests validate research specification structure, NOT industrial software execution or accuracy')
    return 0

if __name__=='__main__':sys.exit(check())
