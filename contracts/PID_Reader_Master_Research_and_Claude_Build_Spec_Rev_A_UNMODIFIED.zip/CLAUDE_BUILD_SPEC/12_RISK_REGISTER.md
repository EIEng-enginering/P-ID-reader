# 12 — Risks, impact, mitigations and first experiments

| ID | Risk | Likelihood / impact (OPINION) | Early experiment and gate | Response |
|---|---|---|---|---|
| R-01 | Outlined CAD text remains unreadable | High / High | S023 20-crop blinded OCR ablation in WP-02 | Region OCR + vector glyph experimental fallback, label gaps |
| R-02 | False pipe connections in dense X crossings | High / Critical | 50 synthetic and 20 real annotated junctions | Plain X always unresolved, typed alternative graphs, human review |
| R-03 | Valve glyph variation defeats templates | High / High | 5 facility styles x 10 real cleared valves | Fill-aware template + optional lawful frozen descriptor, abstain |
| R-04 | Scanned PDFs lose lines and symbols | High / High | 150/200/300dpi scans and 10 cleared real scans | Raster vectorisation, quality refusal |
| R-05 | Public and client PDF rights prohibit training/redistribution | High / High | Rights inventory before annotations exported | Data custodian signs, de-identify/retain locally |
| R-06 | pyDEXPI/Ultralytics AGPL conflicts with proprietary runtime | Verified / High | SBOM and licence scanner | Exclude, use original adapter or approved commercial licence |
| R-07 | ISA's AI-use IP restrictions | Verified / High | Legal review of any proposed symbol source | No ISA IP in AI inputs; independent drawings only |
| R-08 | PySide6 LGPL redistribution obligations | Medium / High | License notice + relinkability review | Legal approval or commercial Qt route |
| R-09 | CPU-only large sheets exceed time/RAM budgets | High / Medium | 50k primitive stress + real 16GB Windows | Tiling, max two workers, fallback, honest limitations |
| R-10 | Revision linking merges unrelated objects | High / High | Two-facility duplicate tag test | Freeze revision and scope; no tag-only merge |
| R-11 | False product claims about completeness | High / Critical | Wording review and test for prohibited phrases | Explicit `PROPOSED_UNVERIFIED`, coverage, audit |
| R-12 | Malformed PDFs exploit native parsers | Medium / High | Fuzz + resource-limit kill tests | Isolated worker, Job Objects, AppContainer feasibility spike |
| R-13 | Dataset shift invalidates synthetic scores | High / High | Compare per-style held-out real subset | Independent ≥120-sheet benchmark with 30 untouched |
| R-14 | DEXPI fields are silently guessed | High / High | Schema+semantic+round-trip validation | Experimental label until pass; sidecar unknowns |
| R-15 | Host Worksheet R1 contract breaks | Medium / Critical | Original R1 tests on every change | Source tree separation + frozen contract checksum |
| R-16 | Project records lost during migration | Medium / Critical | Backup/restore hash chain and fault injection | Transactional migrations, reversible release |
