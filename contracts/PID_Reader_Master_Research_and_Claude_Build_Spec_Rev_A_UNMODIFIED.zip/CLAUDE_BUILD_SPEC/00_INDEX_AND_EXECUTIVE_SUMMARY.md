# Master development specification — executive summary

**Document state:** REV A — researched implementation specification, **not an assertion of completed code or achieved engineering accuracy**. Prepared 7 November 2026 from the user-approved Q1–Q5 Option A, all 45 compatible Claude improvement ideas, the supplied research pack, and verified primary-source documentation. The baseline is the *newer* research-pack `0.11.0-dev0 + WIN-R01`, not the earlier ChatGPT Rev Q checkpoint; reconcile source branches before modifying anything. **No remote repository was edited.**

## One-page recommendation

1. Make source-linked, high-resolution **text-region detection and OCR** the first implementation target; S023 is a strong diagnostic because its drawing-body text is outlined and per-bubble rereading exposed 13 previously missed tags [INTERNAL-EVID-01].
2. Extend vector parsing to **filled polygons, Bézier paths, arcs, clipping and raster image layers**, with original (independently authored) symbol templates [REF-14, REF-24].
3. Eliminate the 4,000-stroke cap using **tile + STRtree + text-outline exclusion**, with explicit complexity limits [REF-10].
4. Develop raster line and symbol candidates, because the synthetic scanned corpus contained 0/64 recovered valves [INTERNAL-EVID-01].
5. Produce **title block, note, table, line number, equipment/valve/instrument registers** early for reviewer value.
6. Build typed ports and edges before asserting useful connectivity; crossing semantics remain alternatives, never silent acceptance.
7. Preserve reviewed objects, uncertainties, and all old data while introducing a new **canonical graph v1** separate from Worksheet R1.
8. Introduce legal/model SBOM gates: PySide6 LGPL/commercial; **pyDEXPI AGPL-3.0**, Ultralytics AGPL/commercial; do not copy ISA graphics or use restricted ISA material in AI [REF-06, REF-09, REF-16, REF-20].
9. Target **DEXPI 2.0.1** via an independently implemented field-mapped adapter and official XML schema; **do not call export conformant until independently checked** [REF-01–05].
10. Start independent annotation early: 20–30-sheet pilot, expanding to ≥120 labelled drawings with ≥30 untouched final-test sheets. Synthetic results are regression evidence only.

### What to build first and why

The proposed order is `WP-01 baseline/benchmark scaffold → WP-02 OCR → WP-03 vector/tiling → WP-04 symbols → WP-05 raster → WP-06 document fields → WP-07 graph → WP-08 cross-sheet and checks → WP-09 UX/exports → WP-10 DEXPI → WP-11 benchmark/assurance → WP-12 Windows hardening`. Engineering register exports can be introduced in WP-06/09 instead of waiting for full graph fidelity. Each WP runs the frozen R1 tests and restores prior acceptance gates.

### Overall architecture

```mermaid
flowchart TD
 A[Untrusted PDF or authorised CAD] --> B[isolated worker + source hash + page transforms]
 B --> C[parallel native text / vector primitives / raster tiles]
 C --> D[region OCR + original symbol catalog + spatial indices]
 D --> E[evidence store: words shapes lines alternatives]
 E --> F[reviewable typed canonical graph]
 F --> G[human approvals + immutable revisions]
 G --> H[registers / annotated overlays / graph views]
 G --> I[DEXPI 2.0.1 adapter after conformance tests]
 E --> J[frozen Worksheet R1 projection: proposals only]
```

### Minimum credible release (not a final accuracy claim)

A release usable as a **review-assisted drawing register extraction tool** must: import and display mixed vector/scanned P&IDs without crashes; show proposed equipment/instrument/valve tags and provenance; allow correction; report omissions/uncertainty; export CSV/JSON with source coordinates; preserve offline operation; verify migrations/backup; pass all frozen R1 tests. It must **not** imply validated connectivity, real-plant truth, full DEXPI conformity or satisfactory industrial accuracy. Independent measurements are required before broader claims.

### What not to build into the default product

Cloud document APIs; automatic HAZOP/LOPA/SIL/IPL decisions; mandatory end-user training; uncontrolled general VLM hallucination; copying ISA/ISO/PIP protected standard graphics; AGPL `pyDEXPI`/Ultralytics in a proprietary build without approved licence; speculative full plant digital twin; direct Gramps/Worksheet-host database writes; automatic graph edge acceptance from unmarked X crossings; silent OCR substitutions. Optional licensed model integrations remain isolated feature flags only.

### Evidence gaps and cheap experiments

- No independently annotated real-sheet corpus yet: label 20–30 representative sheets blind, stratified by source style; count missed and incorrectly inferred engineering objects.
- 608 public sheets are **not** automatically reusable for training or redistribution: per-document rights inventory.
- CPU OCR/model speeds are unmeasured on target laptops: benchmark 4-core 16GB Windows 11; no fabricated time estimates.
- pyDEXPI and models have licence compatibility questions: external legal review; write an original DEXPI adapter in the interim.
- Raster path fidelity is not known: test synthetic scan degradation at 150/200/300/400 DPI and 10 real-cleared scans.
- ISA-derived symbol mapping is not licensed: use generic independently drawn glyph definitions and customer-provided permitted legends only.

### Reading order and package scope

1. `01_RESEARCH_REPORT/` answers **all RQ-01…RQ-60** and includes a source-to-work-package delta map (with explicit uncertainty).
2. `02_ARCHITECTURE_SPEC.md` and `03_CANONICAL_GRAPH_SCHEMA/` define the concrete contract.
3. `04_ALGORITHM_SPECS/`, `05_SYMBOL_LIBRARY_SPEC/`, `06_TAG_AND_LINE_GRAMMARS/` define implementation.
4. `07_EXPORT_SPECS/`, `08_BENCHMARK_AND_EVALUATION_PLAN.md` define outputs and validation.
5. `09_DATASETS_MODELS_LIBRARIES_REGISTER.csv`, `10_REQUIREMENTS.csv`, `11_WORK_PACKAGES/` tie choices to tests.
6. `12_RISK_REGISTER.md`, `13_OPEN_QUESTIONS_FOR_THE_OWNER.md`, `14_GLOSSARY_AND_REFERENCES.md` record assurance.
7. `00_CLAUDE_CODE_MASTER_PROMPT.md` provides the executable master handoff.

**Source status:** this is a research/specification ZIP, **not** a drop-in modification of WIN-R01 code, not an installer, and not evidence that the suggested engineering algorithms currently work. All threshold numbers are **proposed engineering defaults to calibrate**, unless specifically attributed to baseline measurement.
