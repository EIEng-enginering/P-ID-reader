# Worked S023 diagnostic — evidence-to-proposal contract

**Source / state:** [INTERNAL-EVID-01] user-provided 2026-11-07 research pack, `03_EVIDENCE_AND_FAILURE_ANALYSIS.md` and `evidence/OPTIONAL_public_sheet_example/`. These are **visually reported test observations, not independently annotated gold labels**, and the copyrighted image/PDF is **not reproduced** in this ZIP. The user must obtain and use the original authorised source locally. This file is an **OPINION/ASSUMPTION implementation design** until tested against the cleared original sheet.

**Sheet:** S023, Ancaster Compressor Station (Station 209), 0209-01-ML-02-001 revision C, nominal page 1224 × 792 pt with `/Rotate 270`. Native page text has 42 title-block words; body has 3,740 lines, 3,035 curves and 17 rectangles, predominantly outlined letters. The existing recognition experiment found 13 instrument tags only after magnified per-bubble rereading. Do not infer any measured design data not visually present.

## Proposed extraction/reconstruction table

| Region / evidence | Expected **raw evidence and text candidates** | Proposed graph/report record | Important negative/uncertainty assertion | Primary algorithms / WP |
|---|---|---|---|---|
| 13 tagged instrument bubbles | raw stacked lines with optional standalone leading `0` and `ZSC 201`, `ZSO 201`, `FMV 201`, `PSHH 201`, `TSL 100`, `PIT 101`, `PY 102`, `ZT 102`, `PIT 100`, `PIC 102`, `TSL 315`, `FBV 200`, `PCV 102` | 13 `INSTRUMENT` candidates with raw and normalised readings, individual polygon evidence and `PROPOSED_UNVERIFIED` state | Do **not** infer a common loop purely because multiple tags share `201` or `102`. Preserve leading `0` separately; don't silently drop it. | ALG-03/04, WP-02 |
| Five unnumbered circular indicators | `PG` twice, `IF` three times | Five `INSTRUMENT` or unknown-function bubbles with `tag=null`, function marking preserved | No fabricated suffix/loop numbers; report `UNNUMBERED` explicitly. | ALG-04, WP-02 |
| Filled inline valve glyphs | raw filled triangles/arcs and possible actuator stem/semicircle, inline process strokes | generic `VALVE` class candidates, optional independent actuator relation | `PCV 102` proximity is **not sufficient** to label valve body subtype or final connection; conventional X crossing is a hard negative. | ALG-05/07/08, WP-04/07 |
| Main pipe nominal sizes | `NPS 20`, `NPS 30`, `NPS 16`, `NPS 1 1/2`, `NPS 30 x NPS 20` | raw line-size observations; optional ranked associations to scoped pipe segments | Never convert nominal NPS to guaranteed physical bore; `30 x 20` may be reducer dimensions not two pipes. | ALG-03/09/11, WP-02/07 |
| Main line and continuation | `LINE 200-1`, `LINE 200-2`, `LINE 2 DISCHARGE L2-0`; pennant to off-sheet `LINE 200-2` | `PIPE_SEGMENT` with `raw_line_number` where supported, `OFFPAGE_CONNECTOR` with unresolved target | No graph link accepted without paired target and reviewed revision; never join from name alone. | ALG-11/16/17, WP-07/08 |
| Flow arrows and tee/crossings | original arrowhead/line contacts, possible horizontal main flow and branches | typed `JUNCTION` alternatives, `direction=UNKNOWN` until arrow-source evidence | An intersection on drawing is not proof of hydraulic continuity; leapfrog crossing negative. | ALG-08/09/10, WP-07 |
| Heater | `HEATER 36000 BTU` | `EQUIPMENT`/`ANNOTATION` proposed equipment kind heater with `capacity_raw_text` | Do not treat raw BTU label as an automatically validated unit, heat duty or equipment rating. | ALG-06/15, WP-04/06 |
| Manifolds | `PRESSURE REDUCTION MANIFOLD` twice; `SEE DETAIL 1`, `SEE DETAIL 2` | two separate equipment/skid candidate regions and linked note callouts | Two manifold labels are not a single asset and detail references aren't verified inter-sheet links. | ALG-06/15, WP-04/06 |
| Buildings and automation | `3500 x 3000 CONTROL VALVE BUILDING`, `4800 x 3000 CONTROL VALVE BUILDING SKID`, PLC boxes and SCADA diagram | independent enclosure/annotation candidates; proposed `PLC` and `SCADA` indicator labels | Building boxes are not piping connections or physical plant proof; `3500` and `3000` need units/interpretation. | ALG-05/15, WP-04/06 |
| Setpoints | `SP=1.74kPa(g)`, `SP=210kPa(g)`, `SP=550kPa(g)`, `SP=3450kPa(g)` | notes with `raw_value`, `raw_units`, source bbox; separate optionally linked instrument | No automatic safeguard/PSV setpoint or protective-function credit. | ALG-03/15, WP-02/06 |
| Tables | `STATION DATA` design/operating pressure columns, HOLDS list, note list, revisions and reference drawing table | table cells with row/col provenance, title-block number and revision C | An extracted pressure is not an approved design basis; preserve blank/unknown cells and ambiguous row headers. | ALG-15, WP-06 |
| Revision clouds | wavy polygons around changed regions | separate revision-mark evidence; if source rev pair supplied, propose compared regions | A revision cloud does not prove exactly what changed or whether it has been constructed. | ALG-14/15/16, WP-03/06/08 |

## Diagnostic acceptance recipe for Claude Code

1. Obtain the **authorised** S023 source from the owner's local research pack; compute PDF SHA-256 and record page transform for `/Rotate 270`, CropBox and MediaBox. Do not ship/copy drawing into a redistributed package.
2. Run frozen legacy reader, record **actual** outputs and failure types. Confirm whether the existing 13 tags are reproducible; no invented baseline.
3. Apply WP-02 ROI OCR only: keep top-3 alternatives, page-normalised bounding polygons, deskew transform, model binary SHA and coverage mask. Count per-class true/false tags against independently reviewed S023 reference list.
4. Apply WP-03/04 geometry: tiled density map, filled-primitive descriptors, non-symbol exclusion. Report valve and actuator precision, recall and abstention separately; stop classifying all X intersections as valves.
5. Apply WP-06 document segmentation: extract `HEATER`, `MANIFOLD`, `STATION DATA`, `HOLD`, title block and revision as **separate** raw typed observations.
6. Apply WP-07/08 graph: port candidates, line number association, unresolved crossover and off-page hypotheses. No connection claimed verified without specific drawing review.
7. Compare against 20–30 independently labelled pilot sheets, not solely S023; keep 30 untouched final-test sheets until all tuning is frozen.
8. Perform R1 schema/hash tests without adding S023-specific code paths or altering the frozen R1 host interface.

**Release claim permitted today:** None from this document. It is a diagnostic acceptance scenario, not validation results or delivered recognition improvements.
