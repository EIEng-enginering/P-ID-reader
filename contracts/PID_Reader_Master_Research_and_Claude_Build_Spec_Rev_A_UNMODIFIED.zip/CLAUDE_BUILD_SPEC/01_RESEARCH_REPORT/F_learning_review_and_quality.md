# Research group F — Learning, review and quality

**As of 2026-11-07.** Each RQ distinguishes external facts from proposed engineering defaults. Local evidence is from the user-supplied research pack and remains non-independent. Specific model accuracy and CPU timings are UNVERIFIED until benchmarked.

## RQ-37 — **Human-in-the-loop design**: what review UX and data capture (accept/reject/correct with reasons) yield the most improvement per minute of engineer time; how reviewer corrections can feed (a) project libraries, (b) lexicons, (c) optional model fine-tuning, while keeping audit trails and avoiding silent behaviour changes.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Engineer corrections are the highest-value project-specific teaching signal. Relevant reference(s): **REF-19**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Use keyboard-first review with editable proposal, reason and immutable decision event.

**(d) Implementable design — ASSUMPTION pending test.** Save reviewed interpretation + source evidence; update lexicon/template only by explicit reviewer operation. Suggested module owner: `WP-09`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Consent needed before exporting corrected data for external model training. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test undo via superseding event, no silent changes after library update. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-38 — **Active learning** and **uncertainty-driven review queues** (what to ask the human first).

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Review prioritisation should target uncertainty multiplied by downstream impact. Relevant reference(s): **REF-21**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Queue unknown links that affect multiple downstream registers before easy duplicates.

**(d) Implementable design — ASSUMPTION pending test.** Rank by heuristic impact count×uncertainty×review-cost; label rank heuristic, not calibrated probability. Suggested module owner: `WP-09`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Risk that high-frequency easy cases dominate; add class/style quotas. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Measure corrections per reviewer minute on 20 labelled sheets. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-39 — **Evaluation methodology**: define the metrics for P&ID digitisation (object detection at IoU thresholds, tag exact-match, line-number exact-match, **graph edit distance / edge precision-recall**, loop-level accuracy, silent-miss rate, end-to-end "fraction of drawing correctly digitised"), annotation guidelines, inter-annotator agreement, sample size and confidence intervals for a 120-drawing set (30 untouched final), stratification by style/s…

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Independent annotation is needed for unbiased accuracy metrics and confidence intervals. Relevant reference(s): **REF-19 / REF-21**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** ≥120 labelled cleared drawings, ≥30 untouched final, stratified across styles.

**(d) Implementable design — ASSUMPTION pending test.** Compute class precision/recall, exact tag match, false positive/negative, edge PR, silent-miss rate and bootstrap CI grouped by drawing. Suggested module owner: `WP-11`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Do not tune final set or treat synthetic 90 dev /30 reserve as industrial gold. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Check inter-reviewer agreement and blinded held-out regression. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-40 — **Gold-standard creation**: tooling (CVAT, Label Studio, custom overlay editor), annotation schema, pre-annotation by the software to speed labelling without biasing evaluation, **independent reviewer** protocol.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Community CVAT or custom overlay editor can annotate objects, but graph edges need extensions. Relevant reference(s): **REF-19 / REF-26**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Independent initial annotations; preannotations allowed only for training-development subset.

**(d) Implementable design — ASSUMPTION pending test.** Define object box/port/edge schema and adjudicator workflow; export unmodified gold JSON with source hashes. Suggested module owner: `WP-11`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** A reviewer editing AI proposals may inherit AI's silent omissions. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Create blind-label subset and compare to AI-assisted subset, calculate disagreement. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-41 — **Regression and fuzz testing**: malformed/hostile PDFs, pathological density, rotated/mirrored/cropped, mixed raster/vector; fixtures that can be generated lawfully.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** PDFs can contain malformed streams and huge decoded objects. Relevant reference(s): **REF-24**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Generate non-sensitive fuzz fixtures and isolate parsers.

**(d) Implementable design — ASSUMPTION pending test.** Use size/page/decode/recursion limits, sanitised filenames, cancellation and deterministic malformed-input codes. Suggested module owner: `WP-12`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Do not open untrusted PDFs in privileged child process with network access. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Property fuzz 1k bounded inputs, terminate hangs, check no output partial file. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-42 — **Assurance language**: how to describe the tool's claims honestly (what is proposed, what is verified), and what evidence a safety-critical user would expect before relying on it as a *screening aid*.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** This tool must distinguish drawing read-back from verified plant condition. Relevant reference(s): **REF-08**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Use explicit `PROPOSED_UNVERIFIED`/`REVIEWED_DRAWING` assurance language everywhere.

**(d) Implementable design — ASSUMPTION pending test.** All exports carry drawing revision/source hash and omitted-coverage warnings; safety decisions stay manual. Suggested module owner: `WP-09`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** A UI label 'verified' alone can mislead users into treating graph as as-built. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Automated prohibited-claim linter plus end-to-end review logs. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

