# Research group I — Open-ended risk reduction

**As of 2026-11-07.** Each RQ distinguishes external facts from proposed engineering defaults. Local evidence is from the user-supplied research pack and remains non-independent. Specific model accuracy and CPU timings are UNVERIFIED until benchmarked.

## RQ-54 — What are the **five most likely reasons** the proposed approach will still fail on real industrial drawings, and what cheap experiments would reveal them early?

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Top risks: unreadable outlined text, sparse symbol coverage, topology ambiguity, dataset shift, licensing bottleneck. Relevant reference(s): **REF-21**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Run cheap experiments on representative sheets before large model investments.

**(d) Implementable design — ASSUMPTION pending test.** Pilot 5 outlined, 5 scanned, 5 native text, 5 dense, 5 mixed; record bottleneck per style. Suggested module owner: `WP-11`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Synthetic acceptance hides distribution shift; public documents may lack rights. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Ablation tests OCR ROI vs baseline, filled valve vs baseline, tile cap stress. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-55 — What would a **minimum credible independent benchmark** look like given limited access to real drawings (public sources, synthetic, client-cleared)?

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** A 120-sheet independent benchmark can be credible if representative and blinded. Relevant reference(s): **REF-19**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** 30 pilot, 60 development/test, 30 untouched final; dual review for high-risk classes.

**(d) Implementable design — ASSUMPTION pending test.** Sample by drawing style and facility; label objects/lines/junctions/metadata with reviewer+adjudication IDs. Suggested module owner: `WP-11`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Insufficient cleared data may prevent certification, in which case mark BLOCKED. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Pilot agreement; bootstrap CIs with drawings as units not boxes. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-56 — If you had to **cut scope** to ship something engineers will actually use in six weeks, what is the smallest valuable subset and how would it be evaluated?

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Six-week useful scope is source-linked registers, OCR crops, filled valves, title blocks and CSV review. Relevant reference(s): **REF-15**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Build review-assisted extraction MCR first; defer full loop/DEXPI claims.

**(d) Implementable design — ASSUMPTION pending test.** Choose 20 real cleared drawings for internal usability; focus on discoverability and omissions. Suggested module owner: `WP-09`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Do not promise six-week timeline without machine/team capacity. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** MCR tests: fresh Windows import, corrected export, no data loss, R1 unchanged. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-57 — Provenance-aware alternative graph evaluation and contradiction control

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Alternative hypotheses are first-class evidence, not just low scores. Relevant reference(s): **REF-10**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Represent hypothesis sets and mutually exclusive candidates with shared evidence refs.

**(d) Implementable design — ASSUMPTION pending test.** Store `group_id`, `candidate_ids`, `cardinality`, `exclusion_reason`, review selection; graph traversal excludes unresolved. Suggested module owner: `WP-07`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Auto-completing unknown X junctions corrupts connectivity estimates. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test mutually exclusive crossing choices and graph reachability isolation. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-58 — Permission-aware model/dataset registry and true offline operation

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Model and dataset rights must follow each artefact, and all runtime operation must remain offline. Relevant reference(s): **REF-12 / REF-20**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Admit only model-card-approved components and signed local file hashes.

**(d) Implementable design — ASSUMPTION pending test.** Block runtime URL fetch, telemetry, AGPL model weights, unlicensed training datasets, unknown transitive licences. Suggested module owner: `WP-12`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Permissive code licence doesn't imply pretrained weight rights. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Offline VM with disabled network; dependency/weight SBOM audit. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-59 — Independent verification of review audit, schema evolution and handoff

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Reviewed state and migrations must not be silently rewritten by new model results. Relevant reference(s): **REF-24**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Immutable observations + append-only audit + versioned graphs; reversible migrations.

**(d) Implementable design — ASSUMPTION pending test.** Transactionally generate prior backup; pin source SHA and reviewer identity to each decision; verify hash chain. Suggested module owner: `WP-01`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Updated symbol catalogue must not relabel past approved records. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Tamper one audit row and assert verification fails; restore prior schema backup. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-60 — How to manage unsupported technical claims and automatic refusal to infer

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** The safest answer to missing proof is an explicit refusal to classify. Relevant reference(s): **REF-21**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Introduce `UNREADABLE`, `OUT_OF_SCOPE`, `UNKNOWN`, `MULTIPLE_PLAUSIBLE` findings.

**(d) Implementable design — ASSUMPTION pending test.** For each task compare minimum evidence thresholds, measure text/image quality, prefer UNKNOWN over confident guess. Suggested module owner: `WP-11`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Over-refusal can lower useful coverage; assess separate coverage and correctness curves. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test scan below quality threshold and intentionally conflicted tags: no accepted result. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

