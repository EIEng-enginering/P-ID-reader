# Research group G — Architecture, performance and packaging

**As of 2026-11-07.** Each RQ distinguishes external facts from proposed engineering defaults. Local evidence is from the user-supplied research pack and remains non-independent. Specific model accuracy and CPU timings are UNVERIFIED until benchmarked.

## RQ-43 — Recommended **module architecture** for the analysis engine (stages, interfaces, caching, determinism, provenance, versioned schemas), keeping the frozen R1 contract and the Qt-free core; how to add detectors as **plug-ins** with licence/model cards.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Stable modular architecture and reproducible models aid compatibility with Worksheet R1. Relevant reference(s): **REF-13 / REF-24**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Use Qt-free core, plug-in model cards and standalone graph v1.

**(d) Implementable design — ASSUMPTION pending test.** Stage interfaces accept immutable evidence, content hashes, cancellation; enrich through new sidecar only. Suggested module owner: `WP-01`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** New typed nodes must not leak into frozen R1 schema. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Run 16 original R1 checker tests + source-integrity tests for every WP. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-44 — **ONNX Runtime / OpenVINO / DirectML** options for CPU/NPU/GPU acceleration on Windows laptops; quantisation; model-size budgets for an offline installer (< 500 MB?).

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** ONNX CPU works on Windows; WinML is preferred for newer Windows acceleration, DirectML is legacy sustained. Relevant reference(s): **REF-13**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** CPU default; optional WinML/GPU mode gated by hardware benchmark.

**(d) Implementable design — ASSUMPTION pending test.** Pin ONNX model opset, limit intra-op threads, quantise only after accuracy comparison. Suggested module owner: `WP-12`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** NPU availability and model compatibility are machine-specific. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Run 4-core CPU 16GB benchmark and optional GPU; compare accuracy/perf same test set. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-45 — **Python packaging** of heavy dependencies (onnxruntime, opencv, shapely, numpy) with PyInstaller on Windows; wheel availability for 3.12; licence audit (list each dependency's licence and any copyleft risk).

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Frozen Windows executables need native wheels and third-party notice bundling. Relevant reference(s): **REF-15 / REF-16**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Use pyside6-deploy or carefully tested PyInstaller alternative; produce SBOM/NOTICE.

**(d) Implementable design — ASSUMPTION pending test.** Check wheel tags, DLLs, codecs, model hashes and offline installer no-download behaviour. Suggested module owner: `WP-12`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** PySide6 LGPL compliance and packaging redistributables require legal review. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Fresh offline Windows VM install/uninstall and licence scanner fail-gates. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-46 — **Determinism and reproducibility** (ids, hashing, versioned algorithms, seeds) in the presence of ML components and floating point.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** ML libraries and floating-point geometry may be nondeterministic. Relevant reference(s): **REF-13**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Deterministic CPU execution with stable sorting, quantised locations and content hashes.

**(d) Implementable design — ASSUMPTION pending test.** Store algorithm/config/model versions, seed, library/OS and source hash; stable tie-break by IDs. Suggested module owner: `WP-01`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Cross-CPU bitwise exactness may not be possible for every inference backend. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Run same source 10 times same machine; record explained tolerances across machines. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-47 — **Security**: handling hostile PDFs (decompression bombs, recursion), sandboxing options on Windows (Job Objects exist; AppContainer? Windows Sandbox?), supply-chain controls for models/wheels (hash pinning).

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Malicious PDFs can exhaust resources or exploit native parsers. Relevant reference(s): **REF-24**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Isolate worker + Windows Job Objects; investigate AppContainer before claims of sandboxing.

**(d) Implementable design — ASSUMPTION pending test.** Restrict file/network access, decode size, processing time and child tree; verify signed wheel/model hashes. Suggested module owner: `WP-12`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Job Objects constrain resources but do not guarantee containment. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Fuzz crafted PDFs and child-kill recovery, no data exfiltration/network attempt. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-48 — **Multi-sheet projects**: indexing, search (SQLite FTS5), revision diff at graph level (not just tag list), baselines, and performance targets for 500+ sheets.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Project sets of hundreds of sheets need indexes, batch state and versioned graph diffs. Relevant reference(s): **REF-10**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** SQLite FTS5, spatial pages and immutable revision snapshots.

**(d) Implementable design — ASSUMPTION pending test.** Index token/tag/drawing, resolve cross-sheet candidates by revision, perform graph diff with stable entity mapping. Suggested module owner: `WP-08`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Duplicated tags and superseded revisions must not merge automatically. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** 500-sheet synthetic indexed search and migration/backup; wall time reported. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

