# Research group E — Line and network understanding

**As of 2026-11-07.** Each RQ distinguishes external facts from proposed engineering defaults. Local evidence is from the user-supplied research pack and remains non-independent. Specific model accuracy and CPU timings are UNVERIFIED until benchmarked.

## RQ-27 — **Vector primitive normalisation**: from pdf paths (lines, polylines, Béziers, arcs, rectangles, polygons with fill) to a clean planar geometry (snap, merge collinear, split at intersections, remove duplicates/hatches/text outlines). Robust algorithms and libraries (Shapely [BSD], GEOS, networkx, scikit-geometry, custom R-tree) for 10⁴–10⁵ primitives on CPU.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Line/raster complexity 10^4–10^5 primitives needs indexing and robust geometry operations. Relevant reference(s): **REF-10**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** STRtree per overlapped tile with deterministic snapping, splitting and stitching.

**(d) Implementable design — ASSUMPTION pending test.** Quantise PDF user-space coordinates, decompose curves into bounded chord segments, index, compute candidate touches, merge seams. Suggested module owner: `WP-03`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Floating error and n² pair explosions must be controlled by candidate caps. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Stress 50k primitives under explicit time/memory; idempotent seam matching. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-28 — **Separating text-outline strokes from line work** when text is outlined: how to classify tiny closed paths as glyphs and remove them from the pipe network.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Outlined glyphs form small closed paths clustered in text-like baselines. Relevant reference(s): **REF-10**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Tag text-outline regions then mask from *candidate pipe network*, never delete source geometry.

**(d) Implementable design — ASSUMPTION pending test.** Connected-component shape sizes, spacing, repeated glyph signatures; produce per-primitive text probability and preserve ambiguous alternative. Suggested module owner: `WP-03`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Small valve bodies and hatch marks may be mistaken for text. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test 100 outlined glyphs, tiny valve, title block, random hatch, angled note. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-29 — **Pipe vs signal vs utility vs boundary lines**: classification using weight, dash pattern, colour, endpoint context (arrowheads, bubbles), legend ingestion.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Line style must be inferred from dash patterns, width, colour, context and legend. Relevant reference(s): **REF-08**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Classify `PROCESS_CANDIDATE`, `SIGNAL_CANDIDATE`, `UTILITY_CANDIDATE`, `BOUNDARY`, `UNKNOWN`.

**(d) Implementable design — ASSUMPTION pending test.** Compute style feature vector per segment; project legend weights override generic priors. Suggested module owner: `WP-07`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Dash patterns differ between operators and plotters; don't declare instrument type from dash alone. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test solid pipe/dashed signal and boundary/noise with user-custom legend. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-30 — **Junctions and crossings**: T-junction dots, crossings with/without hops (semicircle jumps), "no connection" gaps; decide connect/not-connect with probabilities; propagate ambiguity; cite approaches from literature.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Plain X crossings are not always connections; dots and hops change interpretation. Relevant reference(s): **REF-10**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Typed junction alternatives default UNKNOWN unless explicit dot/hop/end-point evidence.

**(d) Implementable design — ASSUMPTION pending test.** At intersections compute endpoint proximity, dot fill, hop arc, gap, matching stroke style; preserve both graph branches. Suggested module owner: `WP-07`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Collinear overlays and scan speckle can mimic dots. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test dot tee, hop crossing, plain X, skewed corner, scanned noisy tee. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-31 — **Flow arrows and direction**: detect arrowheads, flow-direction annotations, and infer **directed** edges (with uncertainty).

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Directed process flow is not encoded solely by line geometry. Relevant reference(s): **REF-14**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Only orient edges from explicit arrowheads/labels or reviewed directional clues.

**(d) Implementable design — ASSUMPTION pending test.** Match filled arrowhead tip to nearby stroke tangent; record `UNKNOWN` direction otherwise. Suggested module owner: `WP-07`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** A callout arrow may point to a note, not process flow. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test arrow along pipe, leader arrow to label, opposing arrows, no arrow. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-32 — **Line-number association**: tie `size-service-sequence-class` text to pipe segments (proximity, parallel alignment, leaders, breaks at spec changes/reducers), propagate along the network until a break (reducer, valve with spec break, tee), and detect conflicts.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Line numbers are often offset, rotated and partially encoded. Relevant reference(s): **REF-10**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Score text-to-segment association and propagate only through reviewed/explicitly continuous paths.

**(d) Implementable design — ASSUMPTION pending test.** Parse grammar; score offset/alignment/leader, stop at spec break/reducer/ambiguous junction; retain unassigned labels. Suggested module owner: `WP-07`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Branching lines and duplicates can cause wrong line numbers to cascade. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test continuous line, tee with two identifiers, spec break, vertical `NPS 20`, conflict. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-33 — **Graph construction**: from primitives + symbols + text to a typed graph (equipment nodes with nozzle ports, piping segments, valves, instruments, off-page connectors), using symbol *port* geometry; handle in-line components; how to represent "unknown" components. Algorithms (planar graph building, skeletonisation for raster, graph neural networks) with evidence.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Graph nodes need ports and typed components rather than only touching strokes. Relevant reference(s): **REF-04 / REF-23**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Construct evidence graph from primitive topology and symbol-port proposals.

**(d) Implementable design — ASSUMPTION pending test.** Add equipment/nozzle/valve two-port/instrument nodes; split inline pipe at valves; no unknown physical merge. Suggested module owner: `WP-07`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** If port orientation is missing, leave edge proposals not physical adjacency. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test pump→valve→pipe path, unconnected X, partial off-page endpoint. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-34 — **Instrument loops**: assemble loops from tags and signal lines (measurement element → transmitter → controller → final element; interlocks; SIS logic solvers), the tag-prefix heuristics and their failure modes, how to represent loops with uncertainty, and what a HAZOP/LOPA user would want exported (loop sheets) *without* asserting safety function credit.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Loop number grouping is insufficient to prove functional/control-loop causality. Relevant reference(s): **REF-05 / REF-08**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Assemble candidate instrument-loop memberships from tags plus observed signal lines.

**(d) Implementable design — ASSUMPTION pending test.** Parse loop key, group references, add directed possible signal arcs only where supported; show missing controller/final element. Suggested module owner: `WP-08`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Never infer a SIS or IPL from a PSHH or solver symbol. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test PT–PIC–PCV connected, same-number disconnected and shared instrument legends. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-35 — **Raster-only sheets**: line detection (LSD, Hough, morphological skeleton, vectorisation e.g. potrace/autotrace/VTracer licences), symbol detection on raster, and quality prerequisites (dpi, de-skew, denoise, binarise). When is it better to refuse than to guess?

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Scans lack vector paths and require geometry inference under quality constraints. Relevant reference(s): **REF-14**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Deskew/denoise/line enhancement → raster strokes→same planar geometry graph.

**(d) Implementable design — ASSUMPTION pending test.** Use OpenCV lines/skeleton/connected components with DPI-aware thresholds; reconcile to OCR boxes and symbol masks. Suggested module owner: `WP-05`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Low DPI or blur can make crossings undecidable; report `UNREADABLE_REGION` rather than infer. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test scan 150/300 DPI with speckle, blur and torn connection; measure graph edge accuracy. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-36 — **Scale, tiling and complexity**: strategies for sheets with >10⁴ primitives (tiling with overlap, hierarchical spatial indices, early culling of text outlines, streaming), incremental computation and caching, and CPU time budgets per sheet (target: < 2 min typical, < 10 min worst).

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Dense sheets require streaming and tiling to avoid 4000-stroke cap. Relevant reference(s): **REF-10 / REF-13**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Tile overlap and spatial index with bounded memory and deterministic seam stitching.

**(d) Implementable design — ASSUMPTION pending test.** Default 1536 px tiles/128 overlap; pre-cull text outlines, cap candidates per tile; store incremental cache. Suggested module owner: `WP-03`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Complex large PDFs may exceed 16 MB R1 input bound and must fail host mode. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Stress with 50k vectors and 500 page PDF; report time/RSS and bounded fallback. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

