# Current source snapshot audit and concrete delta map

**Source basis:** user-supplied `PID_Reader_ChatGPT_Research_Pack.zip`, `source_snapshot/` and `02_CURRENT_SYSTEM_DETAILED.md`, read 2026-11-07. This is a **static code review**; the live Windows repository was not modified, compiled or tested by this research-specification task. In the extracted research ZIP, `source_snapshot/pid_reader` is a flattened package snapshot; the live repository's `pyproject.toml` uses `where=["src"]`, so Claude must inspect the **actual checked-out** `src/pid_reader` before writing.

| Existing source file | Observed limitation or current capability | Concrete extension owner |
|---|---|---|
| `pid_reader/formats/pdf_source.py` | Native text/stroke extraction; older tag grammar limited for company-specific tags; R1 API frozen | WP-02 standalone OCR+grammar; do **not** add rich fields to R1 JSON |
| `pid_reader/engineering/standalone_read.py` | Stacked instrument OCR, sparse-vector fallback and bubble re-reading are already present | WP-02 generalize to non-bubble regions and preserve N-best alternatives |
| `pid_reader/formats/ocr_source.py` | Local OCR observations/preview | WP-02 independent ROI transforms, engine/model cards and source evidence |
| `pid_reader/engineering/topology.py` | `MAX_SEGMENTS = 4000` and per-contact geometric candidate observations | WP-03 replace cap with tiled source-aware geometry; not silent truncation |
| `pid_reader/engineering/symbols.py` and `symbol_catalog.py` | Supports limited circle/rectangle/basic valve/stem matching; `MAX_TEMPLATES=128` | WP-04 fill-aware vector and original templates; legend review |
| `pid_reader/engineering/connectivity.py` | `MAX_PAIRS=5000`, graph proposals; not verified pipe network | WP-07 typed graph/ports/junction alternatives; bounded spatial indexing |
| `pid_reader/engineering/tag_profiles.py` | Simple validated standalone profile parser | WP-02 extend finite grammar and imperial/metric line identifiers |
| `pid_reader/engineering/signal_links.py`, `signal_paths.py` | Line-style and reviewed signal path proposals | WP-07 optional directed loop assembly with explicit safety abstention |
| `pid_reader/engineering/pipeline.py` | Already orchestrates stages idempotently/cancellably | WP-01 freeze stage signatures, add dependency-keyed new stages |
| `pid_reader/engineering/project.py`, `migrations.py` | SQLite with reviews, migrations and audit state | WP-01/07 add graph v1 and alternatives via additive migrations and tested restore |
| `pid_reader/engineering/findings.py` | Unified source-linked finding review | WP-09 priority queue and review throughput metrics |
| `pid_reader/engineering/reports.py`, `workspace.py` | Reports and registers | WP-06/09 enrich metadata, line lists, notes and source-completeness warnings |
| `pid_reader/engineering/dexpi.py` | Deliberately **disabled** (`STATUS='NOT_IMPLEMENTED'`) | WP-10 proper DEXPI 2.0.1 implementation after graph+validator |
| `pid_reader/engineering/standalone_worker.py` and `worker.py` | Standalone worker and frozen host-worker separation | WP-12 safe Windows process isolation, R1 regression |
| `pid_reader/ui/main_window.py`, `tabs.py`, `viewer.py`, `graphview.py` | Draft/Windows UI available | WP-06/09 source-linked display, review and reports; test on actual Windows |

## Baseline discrepancies that must be resolved

1. The research pack describes `0.11.0-dev0 + WIN-R01`, which is newer than the previous ChatGPT Rev Q source `0.9.x`/older development line. **Do not overwrite it with Rev Q.** Work from the actual live repo and replay tested changes only when missing.
2. The existing `engineering/dexpi.py` is intentionally disabled; do not mistake it for a working DEXPI exporter.
3. Original R1 constraints and `read_pid()` need byte-level regression checks; richer classes stay standalone.
4. The `source_snapshot` contains package code and Windows packaging, but it is a **research snapshot**, not proof that the local live Windows repo has exactly the same content. Compare Git HEAD, file hashes and latest migrations before edits.
5. The research ZIP contains raw evidence reports and an optional public drawing image. Do not redistribute that image or survey filenames in the Claude specification ZIP; only the specification and independently authored examples are delivered.
