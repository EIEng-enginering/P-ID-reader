# Research group D — Symbols and object recognition

**As of 2026-11-07.** Each RQ distinguishes external facts from proposed engineering defaults. Local evidence is from the user-supplied research pack and remains non-independent. Specific model accuracy and CPU timings are UNVERIFIED until benchmarked.

## RQ-19 — **Valve recognition** across styles (gate, globe, ball, plug, butterfly, check, needle, diaphragm, three-way, control valve with actuator types, PSV/PRV/rupture disc, solenoid, hand/locked-open/closed variants, blind flanges, spectacle blinds, strainers, reducers, expanders). Filled-polygon/arc-based glyphs. Candidate methods: parametric templates on vector primitives, contour/shape-context/Hu-moment matching, template matching on rasterised c…

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Real valves include fills, arcs and accessory components beyond six-stroke bowties. Relevant reference(s): **REF-14**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Multi-stage fill-aware geometry + original parametric/raster templates + context.

**(d) Implementable design — ASSUMPTION pending test.** Detect filled triangles and arcs; propose generic valve, then examine stem, actuator, ports and adjacent tag for subclass. Suggested module owner: `WP-04`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Valves and reducers/diamonds may look alike, so subtype stays unknown if features absent. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Synthetic filled/outlined positive/negative; real labelled valve recall with per-class confusion matrix. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-20 — **Pretrained or open detection models and datasets for P&ID/engineering drawings**: list every credible open dataset (e.g. Digitize-PID, PID2Graph, and similar), papers (symbol detection, line detection, graph construction, "PID2Graph", "Digitize-PID", Transformer/GNN based), their **licences** (data and code), sizes, annotation formats and whether they are usable commercially; whether pretrained weights exist and their licences. Include YOLO-…

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Research datasets and detectors exist, but pretrained weights and redistribution rights are often separate. Relevant reference(s): **REF-20 / REF-21**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Evaluate only legally cleared datasets/models; don't make a learned detector compulsory.

**(d) Implementable design — ASSUMPTION pending test.** Dataset intake checklist: source URL, per-file rights, label definitions, split leakage, weights hash, Windows CPU benchmark. Suggested module owner: `WP-11`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Do not assume permissive code licences cover dataset or trained weights; block AGPL default. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Pilot one compliant ONNX model on held-out set, compare per-class precision-recall against templates. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-21 — **Few-shot / template-learning without training**: user marks one example of a symbol → software finds all instances (descriptor matching, vector-primitive signatures, SIFT/ORB/AKAZE, learned embeddings used as fixed feature extractors, nearest-neighbour). Persist as declarative library entries. How to make it robust to scale/rotation/line-weight variation.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Few-shot matching can be done without changing model weights. Relevant reference(s): **REF-14**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Store reviewer-selected vector signature + raster descriptor as project-local template.

**(d) Implementable design — ASSUMPTION pending test.** Normalise scale/orientation; compute contour shape descriptors/ORB matches; retrieve nearest candidates, reviewer validates. Suggested module owner: `WP-04`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** One example may overfit and match lookalike annotations. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test rotated/resized positives and nonmatching dense notes/line crossings. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-22 — **Synthetic data**: generating labelled P&ID images from lawful sources (DEXPI sample files + symbol libraries) to benchmark or optionally fine-tune detectors; domain-randomisation parameters (line weight, fonts, colour, noise, scan artefacts) and the validity risks.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Lawfully generated synthetic diagrams can support regression and model prototyping but overstate field accuracy. Relevant reference(s): **REF-21**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Generate original templates with domain randomisation, never use as sole test standard.

**(d) Implementable design — ASSUMPTION pending test.** Randomise DPI, noise, crop, rotation, font-like original glyphs, dashed lines and distractors; store exact seed + label graph. Suggested module owner: `WP-11`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Synthetic generation may produce simpler connectivity than real plant drawings. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Compare synthetic vs real-stratum performance; hold out generators/layouts from any optional training. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-23 — **Equipment**: vessels (horizontal/vertical, heads, internals), tanks (cone/dome/floating roof), columns/trays, exchangers (shell-and-tube, plate, air-cooled, fired heaters), pumps (centrifugal/PD/vertical), compressors, filters, skids/packages (dashed boundary boxes), buildings. Recognition methods, **nozzle detection** and naming, equipment data blocks (design pressure/temperature, capacity) reading.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Equipment classes can be inferred from composed outlines, ports, text and functional context. Relevant reference(s): **REF-10**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Evidence fusion for vessels, tanks, exchangers, pumps, columns, buildings, skids and labelled blocks.

**(d) Implementable design — ASSUMPTION pending test.** Detect multipart outline, nozzles, internals and labelled area; propose only class supported by ≥2 independent cues. Suggested module owner: `WP-04`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** An enclosure rectangle labelled HEATER does not guarantee equipment class; record as labelled block if unsure. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test heater/manifold and 10 categories; decoy buildings, notes, recycled tag prefixes. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-24 — **Instrument symbols** beyond bubbles: orifice plates, control-valve actuators, PSH/PSL switch symbols, analyzers, sampling points, pressure/temperature/flow elements in-line, local gauges (PG/TG), thermowells, test points, flame arrestors; signal line types (pneumatic, electric, data link, capillary, hydraulic, software link) and their dash conventions.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Instrument and actuator glyphs include non-bubble elements and varying signal dash styles. Relevant reference(s): **REF-08**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Separate measurement point, instrument function, physical actuator and signal annotation nodes.

**(d) Implementable design — ASSUMPTION pending test.** Combine original templates with tag evidence, leader relationships and legend style; infer line type only with sufficient evidence. Suggested module owner: `WP-04`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Tag letters do not independently establish equipment or SIS safety function. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test tapped transmitter, pressure gauge, actuator, orifice symbol, crossed dashed signal and lookalikes. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-25 — **Revision clouds, set-point clouds, hold markers, delta tags, flags/callouts, "SEE DETAIL" boxes**: detect and treat as annotations (not equipment); extract their text and link to nearby objects.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Revision clouds and callouts are common graph distractors. Relevant reference(s): **REF-14**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Recognise as annotation families and attach to nearest drawing region, not inline pipe nodes.

**(d) Implementable design — ASSUMPTION pending test.** Use closed irregular wavy-path repetition, delta triangle, HOLD/SEE DETAIL text; link to revision entry. Suggested module owner: `WP-06`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Clouds may overlap piping; do not erase hidden linework underneath. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test cloud over valve, setpoint cloud, HOLD callout and decorative curves. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-26 — **Misc symbols**: tie-in points, line breaks (ABOVE/BELOW GROUND), insulation/tracing symbols, slope/elevation tags, vents/drains/hose connections, flare/vent stacks, spec breaks, insulation/heat-trace conventions.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Tie-ins, vents, drains, reducers, underground transitions and heat-trace marks have project variants. Relevant reference(s): **REF-08**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Model as generic typed annotation/inline components with configurable library subtypes.

**(d) Implementable design — ASSUMPTION pending test.** Recognise original break/branch templates and nearby text; retain unknown until validated. Suggested module owner: `WP-07`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Spec-break labels may be confused with line number and pipe continuity. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test five small component styles and nonmatching dimension markers. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

