# Research group A — Standards, vocabularies and target formats

**As of 2026-11-07.** Each RQ distinguishes external facts from proposed engineering defaults. Local evidence is from the user-supplied research pack and remains non-independent. Specific model accuracy and CPU timings are UNVERIFIED until benchmarked.

## RQ-01 — **DEXPI**: current versions (1.x Proteus XML, 2.0 / "DEXPI P&ID" model), what is normative, where the XSD/schemas and test cases are published, licences, reference implementations (e.g. pyDEXPI, DEXPI Toolkit, TrainingTestCases) and their licences. Give a **field-by-field mapping** from the product's data (equipment, nozzles, piping network segments, valves, instrumentation functions/loops, signal lines, line numbers, notes, title block) to DE…

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Legacy Proteus XML and DEXPI 2.0.1 XML are distinct serialisations with different models; 2.0.1 is published and pinned. Relevant reference(s): **REF-01 / REF-03 / REF-04 / REF-06**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Implement an original DEXPI 2.0.1 adapter after internal graph stabilises; Proteus import optional later.

**(d) Implementable design — ASSUMPTION pending test.** Make explicit class-map table; supply reviewed plant item only when class and required associations are supported; maintain evidence sidecar keyed by exported IDs. Suggested module owner: `WP-10`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Never fabricate manufacturer data, as-built connectivity, setpoints, SIL or IPL; unknown P&ID type must stay outside export. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Pin XSD, export tiny pump–pipe–valve fixture; roundtrip count IDs/ports and fail if any unreviewed edge becomes accepted. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-02 — **Validation**: how to validate a produced DEXPI file (schema, semantic rules, DEXPI "P&ID validation" tools), and what a minimum **conformant but honest** export would be.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** XSD validation tests syntax, not whether the graph represents actual process engineering. Relevant reference(s): **REF-03 / REF-05**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Use pinned official XSD plus separate semantic and graph round-trip validator.

**(d) Implementable design — ASSUMPTION pending test.** Validate root Model, ID/IDREF, typed ownership, absent vs optional values, graphic/source alignments and property units. Suggested module owner: `WP-10`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Avoid claiming DEXPI conformance from XML well-formedness; rejected constructs get typed diagnostics. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Positive minimal model validated; negatives wrong IDREF, incorrect class, extra element, fabricated critical field. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-03 — Other interchange targets and their fit: ISO 15926, CFIHOS, AutomationML, OPC UA information models, IFC (process plant), GraphML/JSON-LD/RDF (with ontologies), property-graph (Neo4j) models, SVG with semantic metadata, annotated PDF (optional content layers / PDF annotations). What would a process-safety (HAZOP/LOPA) consumer need? Propose a **canonical internal graph schema** (nodes, ports, edges, attributes, provenance, confidence) that can…

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** GraphML/JSON-LD retain graph identity; ISO 15926/CFIHOS/AutomationML/OPC UA/IFC need domain mapping beyond drawn P&ID. Relevant reference(s): **REF-01 / REF-23**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Canonical typed graph first; pragmatic CSV/JSON and SVG first, specialized standards via versioned adapters.

**(d) Implementable design — ASSUMPTION pending test.** Nodes equipment/valve/instrument/annotation/connector; port objects and typed relationships; export only grounded attributes with source refs. Suggested module owner: `WP-09`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Avoid treating topology alone as live plant connectivity or control logic. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Schema check all exports; lossless graph snapshot JSON roundtrip and negative dangling refs. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-04 — **ISA-5.1 / ISO 14617 / ISO 10628 / ISA-5.4 / IEC 62424 / ISO 3511 / PIP / company-style variants**: summarise symbol sets for equipment, valves, actuators, instruments, signal lines, line types and tag grammars, noting copyright/redistribution status of each source. Which symbol families are universal and which are company-specific? How to build a **lawful, original** symbol library that matches them?

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** ISA-5.1-2024 and related ISA/ISO/PIP standards exist but protected graphic/AI-use rights vary. Relevant reference(s): **REF-08 / REF-09 / REF-22**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Original symbol primitives and human-authorised project legend entries; do not supply copied proprietary symbols.

**(d) Implementable design — ASSUMPTION pending test.** Create parametric geometric families from original independently authored drawings with documented designer provenance, reference to general functional names only. Suggested module owner: `WP-04`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Company legends override generic names after approval; never claim ISA-compliant glyph reproduction without permission. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Legal audit of each template, test rotated/scaled variants and nonmatching company glyphs. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-05 — Tag and line-number **grammars** across industries/regions (ISA tag with loop number and suffix, area/unit prefixes, equipment tags, line numbers `size-service-seq-class[-insulation]`, `NPS`/`DN`, imperial/metric, fractions), and a **data-driven profile format** (extend the existing JSON `tag_profile`) that can express them without arbitrary regex.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Plant tag and pipe labels have multiple regional/company formats, including metric and fractional NPS. Relevant reference(s): **REF-08 / REF-22**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Data-driven finite grammar profiles, not arbitrary user-supplied regex.

**(d) Implementable design — ASSUMPTION pending test.** Tokenise prefix/loop/suffix/area; allow formal finite choices for separator, length, alphabet, units, spaces and fractions. Suggested module owner: `WP-02`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** No matching should produce an engineering class without symbol or contextual support; preserve OCR alternatives. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** 50 positive/50 negative per grammar and parser resource-limit fuzzing; accept both NPS 1 1/2 and DN 100. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

