# Research group C — Text reading

**As of 2026-11-07.** Each RQ distinguishes external facts from proposed engineering defaults. Local evidence is from the user-supplied research pack and remains non-independent. Specific model accuracy and CPU timings are UNVERIFIED until benchmarked.

## RQ-13 — **Outlined (vector-path) lettering** — the largest practical blocker. Compare: (a) magnified-region OCR; (b) **glyph-level recognition of vector outlines** (cluster small closed paths into glyphs; match against CAD fonts such as AutoCAD SHX "simplex/romans/isocp", Hershey, ISOCPEUR; shape descriptors; small CNN on rasterised glyphs); (c) reconstruct text from repeated glyph shapes with unsupervised clustering then map clusters to characters us…

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Outlined CAD text contains geometry, not native character streams; OCR at whole-page scale loses small glyphs. Relevant reference(s): **REF-11 / REF-12**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Prioritise region-proposed magnified OCR; vector glyph self-mapping as experimental secondary pipeline.

**(d) Implementable design — ASSUMPTION pending test.** Cluster 3–12 pt glyph-sized closed paths and baseline groups, render at target 30px x-height, N-best OCR; optional vector shape clustering anchored to reviewed words. Suggested module owner: `WP-02`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** SHX font licensing and unanchored glyph mapping can create plausible wrong letters. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Run S023 exact-tag recall diagnostics and negative boilerplate/notes; report recall without inventing percentage. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-14 — **OCR engines** for small technical text on CPU: RapidOCR/PP-OCR (current), PaddleOCR, Tesseract 5 (LSTM; engineering-drawing tuning), EasyOCR (PyTorch), docTR, MMOCR, Surya, Kraken, TrOCR, ONNX-converted models, and engineering-drawing-specific recognisers. Compare accuracy on tiny, rotated, stacked, hyphenated tag text; Windows packaging; licences; model sizes; speed. Recommend a pipeline (detect → crop → upscale → recognise → lexicon-constr…

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Tesseract and PaddleOCR provide offline recognition, but their industrial small-text accuracy is unmeasured here. Relevant reference(s): **REF-11 / REF-12 / REF-13**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Tesseract default; test offline PaddleOCR/ONNX option behind model-card gate.

**(d) Implementable design — ASSUMPTION pending test.** ROI detect→rotate→upscale→engine→N-best lexicon ranking; cache by image and engine version. Suggested module owner: `WP-02`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Avoid parallel engine oversubscription and shipping model weights without checked licences. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Benchmark same 30 cropped tag samples vs CPU wall time; track per-engine word exact-match. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-15 — **Lexicon-constrained recognition**: using tag grammars, project tag lists, equipment lists, and instrument-index data as priors to correct OCR (confusions 0/O, 1/I, 5/S, 8/B, Z/2, hyphen/dash variants). Design a scoring model that keeps alternatives and never silently "fixes".

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Grammar-constrained decoding reduces some OCR confusions but may bias toward expected tags. Relevant reference(s): **REF-08**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Keep raw hypotheses and grammar-ranked alternatives, never silent substitution.

**(d) Implementable design — ASSUMPTION pending test.** Compute weighted candidate score from OCR logit/certainty, edit penalties and project lexicon; emit 3 alternatives with independent evidence. Suggested module owner: `WP-02`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Wrong lexicon or duplicate tag can suppress actual uncommon naming. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Positive 0/O,1/I,Z/2 and negative exotic tag; ensure original candidate remains visible. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-16 — **Stacked / multi-line tags in bubbles** and tags split across symbol and callout (leader lines): robust assembly rules, bubble-type recognition (ISA: discrete/shared, field/panel/auxiliary, DCS/PLC, software), and how to represent "loop digit" prefixes seen in some company styles.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Stacked multiline bubbles need grouping by containment and alignment, not string concatenation alone. Relevant reference(s): **REF-08 / REF-11**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Detect circle and group within its interior, then infer prefix/loop/suffix from line order.

**(d) Implementable design — ASSUMPTION pending test.** Sort OCR tokens by rotated baseline; strip leading 0 only when approved company profile says so; separate PG/IF identifiers. Suggested module owner: `WP-02`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** A visually plausible digit may actually be graphic line or another symbol. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test `PIT` above `101`, leading 0 company loop, PG no number, two bubbles touching. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-17 — **Text-to-object association** (which text belongs to which symbol/line): proximity, containment, leaders, alignment, reading direction; learned vs rule-based; ambiguity representation.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Associating text to symbols requires leaders, containment, orientation, distance and engineering context. Relevant reference(s): **REF-10**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Rank candidates and preserve alternatives rather than selecting closest text by default.

**(d) Implementable design — ASSUMPTION pending test.** Build spatial index of objects; score containment, leader-tip reach, parallel offset and tag class; store evidence feature vector. Suggested module owner: `WP-04`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Dense note text can be closer than actual symbol label. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test symbol with adjacent note, cross leader, ambiguous shared tag, out-of-region labels. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-18 — **Confidence calibration** for OCR/recognition: methods that work without large labelled data; reliability diagrams; how to expose calibrated confidence in the UI and exports.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Raw OCR and classifier scores are generally not calibrated probabilities. Relevant reference(s): **REF-21**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Label scores HEURISTIC until stratified gold set supports isotonic or Platt calibration.

**(d) Implementable design — ASSUMPTION pending test.** Track reliability diagrams, expected calibration error per class/style, coverage curves; save calibrator digest. Suggested module owner: `WP-11`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** 30 final sheets must not be used for threshold tuning. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Use dev-only cross-validation, check ECE and avoid showing percent when uncalibrated. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

