# Research group H — Product and legal decisions

**As of 2026-11-07.** Each RQ distinguishes external facts from proposed engineering defaults. Local evidence is from the user-supplied research pack and remains non-independent. Specific model accuracy and CPU timings are UNVERIFIED until benchmarked.

## RQ-49 — Which **features give the highest value per effort** for process-safety engineers (e.g. instrument index, valve list, line list, loop sheets, node-by-node drawings for HAZOP, cross-checks between P&ID and equipment/instrument lists)? Interview-style requirements from published practice.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Engineers benefit from traceable indexes and omission checks before speculative control-logic inference. Relevant reference(s): **REF-08**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Prioritise register/line list/report with clicked evidence and review queue.

**(d) Implementable design — ASSUMPTION pending test.** Expose source box, confidence kind, document revision, export completeness by class. Suggested module owner: `WP-09`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Excel-based registers can imply completeness unless omissions displayed. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Engineer acceptance exercise: 10 questions on drawing answered from source-linked register. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-50 — **Consistency checks** that catch reading errors without asserting plant truth: duplicate tags, missing loop members, tag-class vs symbol-class mismatch, line-number continuity, valve-tag prefix vs symbol, off-page mismatches, revision deltas.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Cross-checking lists and drawings can expose potential omission without stating plant facts. Relevant reference(s): **REF-23**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Rule-based findings with source and rationale.

**(d) Implementable design — ASSUMPTION pending test.** Flag duplicates, line inconsistency, untagged valves, loops missing members, off-page conflict, holds not addressed. Suggested module owner: `WP-08`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** An intentional nonstandard tag may be a false alert. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Unit tests for each warning incl. allowed exceptions and reviewer suppression. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-51 — **Comparison with commercial tools** (capabilities, not names to copy): which published P&ID digitisation products/services exist and what do they claim; which claims are credible; what can be matched with open components.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Commercial digitisation tools may advertise automation, but advertised claims are not independent benchmarks. Relevant reference(s): **REF-21**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Use published features as backlog inspiration, not competitive accuracy proof.

**(d) Implementable design — ASSUMPTION pending test.** Make feature-by-feature comparison with same drawings, licensing, offline constraints and source provenance. Suggested module owner: `WP-11`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** No access to vendor test protocols means performance claims unverified. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** If trial licensed, evaluate blinded 10 cleared drawings and publish comparative method. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-52 — **Legal/IP**: redistribution of symbol libraries, use of public regulator filings for testing/training, copyright of standards' graphics, EU/Australian/US considerations at a high level (flag for legal review, do not give legal advice).

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Copyright and contract rights control drawings, standard graphics and model weights. Relevant reference(s): **REF-09 / REF-16 / REF-20**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Rights registry + legal approval at intake and export stages.

**(d) Implementable design — ASSUMPTION pending test.** Tag each dataset with `rights_scope`, `commercial_redistribute`, `train`, `share`, `attribution`, jurisdiction; block unsafe operation. Suggested module owner: `WP-01`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Public regulator submission does not imply broad reuse rights. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** License unit tests block missing rights; independently review ISA/IP constraints. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-53 — A **roadmap**: sequenced work packages with dependencies, effort (person-days for an AI coding agent plus human review), risk, and the metric that proves each is done.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Engineering software should be delivered in tested vertical slices with measurable gates. Relevant reference(s): **REF-15**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** 12 sequenced WPs with independent go/no-go and rollback.

**(d) Implementable design — ASSUMPTION pending test.** Every WP implements tests first, current source review, changes, benchmarks, acceptance matrix and work log. Suggested module owner: `WP-01`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Agent person-day estimates cannot substitute executed Windows measurements. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** WP closeout requires tests, revert path, and PASS/FAIL/BLOCKED/NOT_RUN evidence. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

