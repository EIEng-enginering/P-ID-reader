# Research group B — Document and page understanding

**As of 2026-11-07.** Each RQ distinguishes external facts from proposed engineering defaults. Local evidence is from the user-supplied research pack and remains non-independent. Specific model accuracy and CPU timings are UNVERIFIED until benchmarked.

## RQ-06 — **Page structure**: detect drawing frame, grid references, title block, revision table, notes/HOLDS, legends, equipment/line/instrument lists, data tables, and the main drawing area. Methods for vector PDFs (clustering of rules/lines, rectangle grids, text alignment) and for raster. How to read **title-block fields** robustly (drawing number, revision, date, sheet n/m, title, client, units, scale).

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Page grids and title blocks often exist as rule/rectangle clusters with OCR words. Relevant reference(s): **REF-10 / REF-14**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Combine frame-rule detection, region proposals, table segmentation and position-based priors.

**(d) Implementable design — ASSUMPTION pending test.** Find largest frame; infer grid axis; table cells from lines and alignment; choose title field with multiple score components. Suggested module owner: `WP-06`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** A bottom-right assumption fails on rotated or nonstandard drawings. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test bottom/right/left title blocks and crop/rotate/missing revision with exact source boxes. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-07 — **Legend sheets** (symbol legends are included in many sets): can the software **ingest a legend automatically** to build a project symbol catalogue (symbol glyph + description pairs)? Method, data model, risks.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Legend symbol-to-description pairing can adapt to company drawing conventions. Relevant reference(s): **REF-09 / REF-14**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Local legend ingestion as reviewer-confirmed project catalogue, never direct autopublish.

**(d) Implementable design — ASSUMPTION pending test.** Detect table layout; crop icon/description cell pairs; create template candidate and require reviewer identity + effective revision. Suggested module owner: `WP-04`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Standards/IP and incorrect column pairing are major risks. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test legend with two distinct icons and a misleading note; no active entry until reviewed. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-08 — **Tables** on drawings (station data, equipment lists, line lists, valve schedules): detection and parsing from vector and raster; candidate libraries and licences.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Tables on P&IDs may be ruled, borderless, vector or scanned. Relevant reference(s): **REF-11 / REF-12**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Rule-based cell construction + OCR layout; optional locally licensed detector only if measured better.

**(d) Implementable design — ASSUMPTION pending test.** Join grid intersections or align text into columns, preserve row boxes and units; save typed table role guesses. Suggested module owner: `WP-06`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Merged cells, footnotes and rotated tables may scramble rows. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test STATION DATA 4x3, merged header, missing grid, rotated scan, tables with embedded notes. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-09 — **Off-page connectors and cross-sheet links** (arrow pennants with drawing numbers, "FROM/TO", continuation tags): detection, parsing, and building a **project-wide** graph across sheets and revisions with conflict handling.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Off-page pennants need both direction and drawing/line identifiers. Relevant reference(s): **REF-10 / REF-23**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Candidate links from explicit line number + drawing reference + connector ports; always review matching.

**(d) Implementable design — ASSUMPTION pending test.** Parse `FROM/TO DWG`, `LINE 200-2`, consider catalogue revision and terminal direction; cross-sheet matches become alternatives. Suggested module owner: `WP-08`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Same line IDs may recur across facilities; stale revision labels produce false links. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Test exact matched pair, duplicate label, missing target, mismatched revision and two-source conflicts. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-10 — **PDF internals**: use of optional-content layers (OCGs), annotations, colours, line widths, dash arrays, clipping paths, XObjects/forms, fonts, Type 3 fonts, hidden text, tagged PDF, as free signals. What fraction of CAD-plotted P&IDs retain layer information? How to extract it robustly with permissive libraries (pdfminer.six, pypdf, pypdfium2, pikepdf [MPL], PyMuPDF [AGPL — flag], mupdf)? Performance on 10 000–50 000-object pages.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** PDF can retain layer names, stroke dash, colour and form XObjects, but frequency across 608 sheets unmeasured. Relevant reference(s): **REF-17 / REF-24**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Extract metadata cheaply first, use PDF layers as hints not ground truth.

**(d) Implementable design — ASSUMPTION pending test.** Traverse page content and nested XObjects with bounded depth; capture OCG names, operator graphics state, text and fill modes. Suggested module owner: `WP-03`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Hidden layers, clipping and untrusted recursive objects can distort semantics. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Count OCG/XObject prevalence on permitted 47-sheet sample; malformed streams must fail in isolated process. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-11 — **Rotated / mirrored / cropped pages** and text at arbitrary angles (vertical line numbers): robust orientation handling for both vector text and OCR, and coordinate-frame consistency between PDF space, rendering and overlays.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** Page rotation/crop matrix transforms and arbitrarily rotated text must be kept distinct. Relevant reference(s): **REF-24**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** One invertible PDF-to-render transform with tests across media/crop/render and four rotations.

**(d) Implementable design — ASSUMPTION pending test.** Record affine matrix + inverse, apply to every polygon and OCR box; compute deskew angle locally per region. Suggested module owner: `WP-02`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** Detect mirrored page graphics separately and do not apply global OCR reversal to every word. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** Property tests roundtrip 0/90/180/270, mirrored, cropped, arbitrary 13-degree text. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

## RQ-12 — **DWG/DXF/DGN and neutral CAD** inputs: realistic options (ezdxf [MIT], ODA File Converter [licence?], LibreDWG [GPL], Teigha), what P&ID semantics survive (blocks, attributes, layers) and how to map block names to symbols.

**(a) State of the art / evidence.** **VERIFIED or source-qualified:** DXF preserves blocks/attributes/layers better than exported PDF, but proprietary DWG/DGN access is constrained. Relevant reference(s): **REF-18**. This does not establish successful performance on this company's real drawings.

**(b) Options evaluated**

| Option | Benefit | Limitation / trade-off | Choice |
|---|---|---|---|
| A — source-linked deterministic/hybrid method | Runs offline and makes engineering evidence visible; CPU predictable after optimisation | Specialised rules and review needed; incomplete on novel styles | **Preferred** |
| B — generic automated vision/ML-only inference | May recover shapes missed by deterministic rules | No guaranteed industrial accuracy, weights/licensing uncertainty, can hallucinate relationships | Conditional experiment only |
| C — defer until independent examples exist | Avoids unjustified design commitments | Delays the engineering register/graph capability | Use when rights or validation missing |

**(c) Recommendation — OPINION, approved design direction.** Prefer permissive ezdxf; DWG converter only if licence and local installation approved.

**(d) Implementable design — ASSUMPTION pending test.** Read INSERT attributes, LWPOLYLINE, TEXT/MTEXT, layer and handle IDs; map to same observation schema. Suggested module owner: `WP-12`. Each output needs `source_sha256`, `page`, `bbox`, `algorithm_id`, `evidence_ids`, `alternatives`, `review_state`, and `score_kind`; never overwrite the raw reading. Default to `PROPOSED_UNVERIFIED` unless a named reviewer has explicitly resolved the exact hypothesis in the frozen drawing revision. See matching algorithm specification and graph schema.

**(e) Failure and detection.** DWG/DGN vendor data semantics cannot be inferred from conversion alone. Record a typed `UNKNOWN` or `UNREADABLE` and surface a coverage warning instead of choosing a convenient interpretation.

**(f) Tests and proposed acceptance.** DXF fixture two nested blocks/ports/attributes; incompatible binary DWG fails informative, no network. Before a feature is released, require (1) ≥5 positive and ≥5 negative unit fixtures, (2) a provenance and deterministic-hash test, (3) a non-destructive R1 regression, and (4) a documented real-sheet sample if available. The numerical threshold for field precision/recall is **not yet established**; pilot annotations determine the feasibility baseline. These are proposed acceptance gates, not reported test results.

