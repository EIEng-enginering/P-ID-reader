# Stage 5 APPROVED development decisions Q41-Q50 (Option A)

All Stage 1-5 Q1-Q50 Option A decisions are APPROVED by the owner as of 7 November 2026, including the ten Stage 5 decisions in this register. Options B/C are historical alternatives only; **implement A without further owner decision rounds**. Approval is for DEVELOPMENT, not validation of software, drawing accuracy or engineering safety. None changes or supersedes R1's 104 integration requirements.

## Q41 - Repository, development structure and release provenance

**A (APPROVED).** Use one versioned Python 3.12 repository containing the reusable GUI-free `pid_reader` core, standalone PySide6 app, isolated R1 compatibility adapter, pinned dependency and model profiles, source schemas, fixtures, tests and docs. Do not put third-party model binaries and runtime project databases in source history. Every release has Git commit/source hash, semantic version, wheelhouse/model hash manifest, source archive, Changelog, new immutable test-evidence folder and rollback instructions. Use the exact project path and remote in master prompt. Verify existing remote/local repo before initializing; no speculative force push.

**B.** Separate repositories for core, standalone GUI and host integration, with independently published versions and more complex integration testing.

**C.** Single Windows application repository with internal utilities later exported as a library, accepting more coupled development.

**Default A rationale:** the standalone and R1 outputs must share a single deterministic extraction implementation while allowing independent packaging. **Acceptance:** `import pid_reader` has no side effects and no Qt; clean offline Python 3.12 setup works; versioned artifacts and original R1 hashes are traceable.

## Q42 - Core module boundaries and extraction pipeline contract

**A (APPROVED).** Freeze typed interfaces between format intake, page classification, native text/vector geometry, offline OCR, symbol proposals, tag association, line/port topology, engineering graph, uncertainty diagnostics and export. Each stage produces immutable typed evidence with version/model/config hashes and stage-level errors. Pipeline is restartable at safe checkpoints in standalone mode, never silently skips unreadable regions, and gives exactly one complete strict JSON result to R1 host. Keep geometry and ML alternatives rather than forcing a single guessed symbol.

**B.** One synchronous extraction engine with a common result object; fewer integration boundaries, less test isolation.

**C.** A large end-to-end multimodal AI extraction call that returns text and graph data directly; retain only post-validation.

**Default A rationale:** exposes connectivity and OCR errors independently. **Acceptance:** contract tests for each stage including limitations, cancellation, deterministic repeats, and malformed inputs.

## Q43 - Native, scanned, intelligent CAD and DEXPI implementation sequence

**A (APPROVED).** Implement a validated PDF vertical slice first (vector, mixed, scanned if bundled OCR and licence clear), then independent image, DXF and DEXPI 2.0.1 adapters, and only then licensed DWG/DGN/intelligent CAD. Prefer native object intelligence where present; never assume conversion preserves line connectivity or plant metadata. Every adapter has its own parser capability list, per-format truth cases, unsupported-field report, input limits, licensing and clear non-conformance label. No claimed DEXPI conformity without independent schema plus semantic tests.

**B.** PDFs only until all quality targets are met; CAD input deferred into a separate project.

**C.** Native CAD/DEXPI first, OCR/vector PDF later, optimised for intelligent digital drawing ecosystems.

**Default A rationale:** satisfies R1 PDF priority without abandoning Stage 1 multi-format design. **Acceptance:** real supported-format fixture roundtrips with explicit source metadata and evidence; unsupported adapter refuses safely.

## Q44 - Database, immutable evidence, entity identity and migrations

**A (APPROVED).** Use local versioned SQLite with immutable source bytes/hash and observations, separate candidate interpretations and plant-wide persistent entity IDs, typed port/connection hypotheses, append-only review/audit events, explicit supersession and revision impact. Current interpretation is computed from latest permitted events. Preserve exact source verbatim values. Stable R1 observation IDs remain deterministic hash IDs and are NEVER replaced by standalone plant entity IDs. Host `.hzcase` module uses ONLY its seven new append-only tables, migration checksum and reconciliation; never mutate older host tables.

**B.** Simplified object/connection SQLite tables, retaining free-form JSON metadata for remaining evidence.

**C.** Central graph database as primary store, plus SQLite only for Worksheet export.

**Default A rationale:** supports audit, multi-revision and cross-program identities. **Acceptance:** migration / rollback-through-backup, foreign key integrity, tamper detection, duplicate tags, conflicting entity hypotheses and history preservation.

## Q45 - Connectivity engine and graph uncertainty rules

**A (APPROVED).** Represent symbols with typed ports and lines as ordered segments; resolve intersections only through dot/bridge/gap rules and input evidence. A process line, electric signal, pneumatic signal, utility line, instrument-loop proposal and off-page connector use different edge classes. Preserve unconfirmed alternatives and direction UNKNOWN unless an arrow is depicted. Cross-sheet matching uses multiple evidence sources and explicitly unresolved states; same tag does not prove physical identity. Graph queries expose accepted-only and include-proposals modes and return source traces for every traversed edge.

**B.** Automatic connectivity where geometry is unambiguous, manual connections for complicated line intersections or off-page references.

**C.** Allow neural network graph inference to resolve disputed connections if its score exceeds a user-set threshold.

**Default A rationale:** topology errors can propagate to safety reviews. **Acceptance:** crossing, tee, instrument loop, inline valve, branch, signal type, two-path ambiguity and cross-revision graph fixtures; NO false claim that shared-tag means independent IPL.

## Q46 - Windows UI, asynchronous jobs and resource budgets

**A (APPROVED).** Dockable Qt workspace with project tree, tiled drawing viewer, virtualised engineering registers, selected-neighbourhood graph, uncertainty queue, version comparison and handoff preview. All extraction runs in isolated bounded worker processes; Qt models updated on UI thread, cancellation within host's five-second gate, job state durable in standalone, private workdirs, clean restarts and safe retries. Host maintains PDF 16 MiB, 500 pages, 12M pixels, configured 20k object/8MiB result caps and documented 4-core/8GB reference machine limits, subject to actual validation. Standalone has separate user-managed resource profiles and storage off synced folders.

**B.** Simpler fixed tabbed Windows interface and sequential single worker; fewer workspaces, reduced batch capability.

**C.** Browser-style local UI with separate service; require a localhost daemon and a browser instead of PySide6 standalone desktop.

**Default A rationale:** meets approved facilitation and large drawing set needs without loosening host limits. **Acceptance:** GUI offscreen + real Windows 100/125/150 scaling, nonblocking worker, restart/retry and no temporary document leakage.

## Q47 - Public SDK, adapter contracts and consumer isolation

**A (APPROVED).** Publish frozen `pid_reader.api.read_pid()` and `pid_reader.worker` R1 interfaces exactly; maintain a distinct standalone schema/SDK and adapters for Worksheet, HAZOP, LOPA, QRA, engineering registers and optional DEXPI. All requests and exports are versioned and report proposal/accepted-as-reading status, source revision, uncertainty, evidence and dropped fields. All receiving applications control their own record writes and user approval. R1 host patch rehearsal occurs only against hashed COPY and is ADDITIVE by frozen contract verifier.

**B.** Python SDK plus JSON/CSV exports, with other adapters manually implemented in consumer applications.

**C.** Shared SQLite storage accessible directly to consuming programs, reducing adapter work initially.

**Default A rationale:** ensures reusable module without compromising the HAZOP/LOPA host. **Acceptance:** independent consumer tests, strict R1 schema/sha, no side writes, present vs absent source evidence.

## Q48 - Test fixtures, truth labels, metrics and safety negatives

**A (APPROVED).** Provide a deterministic synthetic P&ID drawing generator, truth metadata, and a predeclared 120+ drawing benchmark with >=30 untouched held-out cases. Include rare line crossing, hidden branch, damaged text, rotated PDF/crop, two matching tags, mixed page type, incorrect source hash, encrypted/malformed file, model changes on unchanged source, graph ambiguity, cancellations and audit tamper. Measure class/style precision/recall/F1, tag exact/CER, edge pair precision/recall, loop precision, critical silent-miss. Predeclare clean vector thresholds as approved Stage 1-4 targets; state unsupported other class/style gates separately. Independent tester other than developer runs final benchmark. All failed classes blocked from bulk acceptance.

**B.** Thirty synthetic drawings, with separate independent tests only near delivery.

**C.** Generate small fixture samples on demand and rely primarily on developer-written unit tests.

**Default A rationale:** provides defensible extraction-performance claims rather than demos. **Acceptance:** exact split hash, ground-truth schema validation, deterministic generator, reports with denominator and error breakdown; independent gate may remain NOT_RUN until done.

## Q49 - Incremental implementation, test gates and rollback

**A (APPROVED).** Build work packages WP-000 through WP-011 in dependency order. No more than one untested major capability added per vertical slice; each package includes runnable code, synthetic demonstrator, source+dependency hash, tests, screenshots when relevant, immutable evidence folder, backward-compatibility check, known limitations, issue register and rollback/restore. A blocked licence, OCR model, format reader or independent sign-off must stop claiming that feature complete without blocking delivery of the verified earlier slice. Do not turn a 'plan complete' into 'software complete'.

**B.** One large integrated implementation followed by regression testing and release notes.

**C.** Implement separate major features concurrently and merge with broad acceptance checks at the end.

**Default A rationale:** preserves usable software at every increment and limits errors. **Acceptance:** per-WP exit checklist, test log and diff against previous version; R1 gates always explicit.

## Q50 - Claude execution authority, final deliverables and owner release control

**A (APPROVED).** Claude should code end-to-end, build the standalone Windows distribution and reusable module, maintain tests and source licensing, and produce independent engineering evidence requests without claiming humans have performed them. It must inspect the real repo/host before changes, use the exact directory and URL, preserve original R1, run the 104-entry requirement checklist, and submit signed/hashes source+model+SBOM+tests+gold benchmark+installer or portable package+docs+API examples+host rehearsal patch. No production claims without independent engineering-method/accuracy and real-Windows checks. No Git push, remote transfer, client drawing training or host live changes without appropriate access and authorisation.

**B.** Claude builds code and tests but leaves packaging, engineering benchmarks and integration handoff to a separate team.

**C.** Claude supplies source scaffolds and architecture documentation only; engineering developers implement algorithms.

**Default A rationale:** matches the owner's goal of end-to-end AI-assisted software development while preserving independent gate separation. **Acceptance:** reproducible release, fully referenced traceability, no fabricated passing tests, owner-controlled final integration/production designation.

## Approval recording

**Approval recorded:** See `planning/DECISIONS_APPROVED_STAGE5.md` and `planning/DECISIONS_STATUS.json`. The owner has also delegated routine in-scope technical decisions and iterative execution; see `AUTONOMOUS_DEVELOPMENT_CHARTER.md`. The release remains subject to actual tests and final owner review.
