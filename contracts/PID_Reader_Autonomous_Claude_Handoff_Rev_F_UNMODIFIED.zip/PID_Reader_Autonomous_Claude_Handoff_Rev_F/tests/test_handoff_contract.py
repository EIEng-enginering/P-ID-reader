"""Package integrity tests only; not tests of a built reader or accuracy."""
import csv
import io
import json
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class HandoffTests(unittest.TestCase):
    def test_approved_vs_proposed(self):
        d=json.loads((ROOT/'planning'/'DECISIONS_STATUS.json').read_text())
        for i in range(1,5):
            self.assertEqual(d[f'stage{i}']['status'],'APPROVED')
        self.assertEqual(d['stage5']['status'],'APPROVED')
        self.assertEqual(d['autonomous_development']['status'],'APPROVED_WITH_BOUNDARIES')

    def test_traceability_count_and_states(self):
        with (ROOT/'planning'/'REQUIREMENTS_TRACEABILITY_STARTER.csv').open(newline='',encoding='utf-8') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(len(rows),154)
        self.assertEqual(len([r for r in rows if r['id'].startswith('PR-')]),104)
        for i in range(1,51):
            r=next(x for x in rows if x['id']==f'Q{i}')
            self.assertEqual(r['owner_decision_state'],'APPROVED_A')
        self.assertTrue(all(r['implementation_state']=='NOT_RUN' for r in rows))

    def test_fixture_specs_not_mistaken_for_results(self):
        d=json.loads((ROOT/'fixtures'/'fixture_contracts.json').read_text())
        self.assertEqual(d['status'],'SPECIFICATIONS_NOT_RENDERED_INPUTS')
        self.assertGreaterEqual(len(d['cases']),40)
        self.assertEqual(len({x['id'] for x in d['cases']}),len(d['cases']))
        for x in d['cases']:
            self.assertEqual(x['ground_truth_status'],'SPECIFICATION_ONLY')
            self.assertEqual(x['artifact_paths'],[])
            self.assertTrue(x['negative_assertions'])

    def test_original_r1_present(self):
        p=ROOT/'contracts'/'PID_READER_MODULE_REQUIREMENTS_R1_UNMODIFIED.zip'
        with zipfile.ZipFile(p) as z:
            names=z.namelist()
            self.assertTrue(any(n.endswith('01_REQUIREMENTS.md') for n in names))
            self.assertTrue(any(n.endswith('schemas/pid_extraction.schema.json') for n in names))
            self.assertTrue(any(n.endswith('skeleton/pid_reader/api.py') for n in names))
            self.assertTrue(any(n.endswith('tests/test_check_extraction.py') for n in names))

    def test_prompt_carries_exact_project_location_and_host_rules(self):
        txt=(ROOT/'CLAUDE_MASTER_PROMPT_AUTONOMOUS_REV_F.md').read_text()
        self.assertIn('C:\\Users\\Admin\\OneDrive - Enhance Integration Engineering\\Company\\006 Calculation Methods\\26 P&ID reader',txt)
        self.assertIn('https://github.com/EIEng-enginering/P-ID-reader.git',txt)
        for t in ['16 MiB','500 pages','12,000,000','read_pid(pdf_bytes, params, cancel=None','result_sha256','M17_','NOT_RUN','Q41-Q50']:
            self.assertIn(t,txt)
        self.assertEqual(txt,(ROOT/'CLAUDE_MASTER_PROMPT_AUTONOMOUS_REV_F.txt').read_text())

    def test_autonomy_and_gate_boundaries(self):
        charter=(ROOT/'AUTONOMOUS_DEVELOPMENT_CHARTER.md').read_text()
        for word in ['Q1–Q50','WP-000','owner','licence','NOT_RUN','R1','confidential']:
            self.assertIn(word,charter)
        settings=json.loads((ROOT/'.claude'/'settings.json').read_text())
        self.assertEqual(settings['permissions']['defaultMode'],'auto')
        self.assertNotIn('bypassPermissions',str(settings))
        self.assertIn('NOT_RUN',(ROOT/'README_HANDOFF.md').read_text())
        reg=(ROOT/'planning'/'DECISIONS_APPROVED_STAGE5.md').read_text()
        self.assertIn('Q50',reg)

if __name__=='__main__':
    unittest.main()
