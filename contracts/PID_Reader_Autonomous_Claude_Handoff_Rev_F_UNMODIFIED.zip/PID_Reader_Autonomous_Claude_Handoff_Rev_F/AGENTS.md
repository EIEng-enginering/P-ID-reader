# Coding-agent and read-only reviewer instructions

The canonical agent brief is `CLAUDE.md`. All 50 Stage 1–5 default A decisions are owner-approved. The coding agent has standing authority for in-repo implementation and technical choices; do not request intermediate owner sign-off. Source of truth: `CLAUDE_MASTER_PROMPT_AUTONOMOUS_REV_F.md`, `AUTONOMOUS_DEVELOPMENT_CHARTER.md` and the byte-identical R1 contract ZIP.

Prefer incremental/test-driven changes, `pytest` fixtures and real geometry calculations. The reviewer must check: exact R1 contract, deterministic IDs/hashes, provenance, graph uncertainty, resource bounds, offline/privacy by default, new dependencies/licences, GUI threading, source vs interpretation history, no invented safety claims, no hidden NOT_RUN gates. Write findings with severity and paths; coding agent fixes and reruns tests autonomously. Another AI reviewer is not an independent engineering safety validator.

No push to main or destructive repository action; no live host/database mutation, no confidential uploads. Give final owner a complete evidence-based product review.
