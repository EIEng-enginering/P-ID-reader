# Advanced P&ID Reader — Autonomous Claude Development Handoff, Rev F

**Approved:** All 50 Q1–Q50 Option A decisions. **Owner workflow:** Claude executes in-scope development WP-000–WP-011 without repeated approval requests, then presents the finished product for owner review. This ZIP is a SPECIFICATION/DEVELOPMENT AUTHORITY package, **not implemented software**.

## Read first

1. `START_CLAUDE.md` — one message to Claude Code.
2. `CLAUDE.md` — concise repo-level standing instructions.
3. `AUTONOMOUS_DEVELOPMENT_CHARTER.md` — what is authorised and what still requires real credentials/access/rights.
4. `CLAUDE_MASTER_PROMPT_AUTONOMOUS_REV_F.md` — full implementation contract.
5. `planning/DECISIONS_STATUS.json` / `planning/DECISIONS_APPROVED_STAGE5.md` — all decision states approved.
6. `contracts/PID_READER_MODULE_REQUIREMENTS_R1_UNMODIFIED.zip` — byte-for-byte original and authoritative frozen Worksheet R1 integration contract.
7. `CODING_WITH_AI_GUIDE.md` — best-practice setup and AI developer loop.
8. `.claude/settings.json` — optional Claude Code Auto-mode and limited permitted commands; subject to installed version and managed policies. It cannot override external permissions.
9. `AGENTS.md` — independent coding agent/reviewer instructions.

Additional originals preserved: `planning/STAGE5_DECISIONS_Q41_Q50.md`, 154-row `planning/REQUIREMENTS_TRACEABILITY_STARTER.csv`, 42-case fixture specifications, and original R1 reference checker logs. **All implementation-state fields remain NOT_RUN** until code actually passes tests.

Project: `C:\Users\Admin\OneDrive - Enhance Integration Engineering\Company\006 Calculation Methods\26 P&ID reader`
GitHub: `https://github.com/EIEng-enginering/P-ID-reader.git`

## Verified only in this handoff

Original 16 R1 reference checker tests passed in the previous package, and the handoff integrity tests pass when executed in this revision. The reader skeleton still has `NotImplementedError`; no real P&ID recognition, Windows app, host integration, independent model accuracy or engineering validation has yet been demonstrated by this package. Do not claim otherwise.

## External actions

The owner has pre-approved technical implementation decisions and bounded code development. That is **not** an authenticated GitHub permission, licence grant, tool security bypass, cloud-data disclosure permission, authorisation for new purchases, or independent engineering safety acceptance. Block such actions when rights/access are absent, complete other development tasks and report them in the one final handoff.
