# P&ID Reader — Standing Instructions for Claude Code

Owner-approved: ALL Q1–Q50 Option A. **Build the complete program without asking for intermediate design, architecture, feature or work-package approval.** The finished product is the owner's review checkpoint.

Read first, in order:
1. `AUTONOMOUS_DEVELOPMENT_CHARTER.md` — delegated development decisions and actual limits.
2. `CLAUDE_MASTER_PROMPT_AUTONOMOUS_REV_F.md` — full engineering/software specification.
3. `planning/DECISIONS_STATUS.json` and `planning/DECISIONS_APPROVED_STAGE5.md`.
4. `contracts/PID_READER_MODULE_REQUIREMENTS_R1_UNMODIFIED.zip` — FROZEN host contract and hash/schema checker.

**Do not stop at planning.** Implement WP-000 through WP-011 in runnable increments. Work autonomously: plan internally, write acceptance tests, code, run, fix, self-review, commit recoverable local changes, document important technical choices and continue. If blocked by external licensing/access, isolate the blocked feature and continue everything else. Preserve Python 3.12 core without Qt imports; PySide6 Windows app; offline-first; evidence-linked drawing proposals, typed graph and human-review data; exact R1 worker/schema/IDs/hash. No unverified claims about drawings, plant or engineering safety.

Directory: `C:\Users\Admin\OneDrive - Enhance Integration Engineering\Company\006 Calculation Methods\26 P&ID reader`
Remote: `https://github.com/EIEng-enginering/P-ID-reader.git`
Runtime/caches/databases default to a user-local non-synced path.

**Finish with:** runnable code, source/package hashes, actual test logs, an independently executable synthetic example, license/SBOM, installation steps, release-gate matrix and a final owner-review summary. Unperformed external gates remain NOT_RUN. Never ask Q1–Q50 again.
