# Best practical AI coding workflow for this P&ID Reader

## Recommended environment

Use **Claude Code** in the project checkout on Windows 11 (or supported Windows 10) with Python 3.12, isolated virtual environment and Git. Prefer the strongest coding/reasoning option available in your Claude subscription; exact model labels and Auto-mode access vary by account and installation. Use `CLAUDE.md` for standing decisions and the master prompt for requirements. The included `.claude/settings.json` requests Auto mode and a narrow set of common permitted development commands; it only takes effect if placed in the actual repository and if your installed Claude Code and organisation permit it. View/adjust with `/permissions`. Do not use unrestricted permission bypass.

Project root to open in Claude Code:
`C:\Users\Admin\OneDrive - Enhance Integration Engineering\Company\006 Calculation Methods\26 P&ID reader`

Keep the source under this specified location, but prefer a Git checkout/worktree or temporary working directories outside OneDrive for high-write intermediate work; store persistent working databases, models, OCR caches and source images under a configurable non-synced local directory. Do not overwrite an existing project. Confirm the actual Git remote and permissions.

## Repeatable coding cycle (no owner interaction)

1. Inspect repository, R1 contract, environment and project tests. Write a factual baseline and architecture/acceptance contracts.
2. Implement **one vertical feature slice** at a time (PDF geometry to object to graph to UI to JSON) rather than one immense speculative generation.
3. Write executable tests from synthetic drawing ground truth BEFORE or alongside each feature. Run failure-path tests and regressions, not only happy-path demos.
4. Keep source observation distinct from engineering interpretation, human review and graph relationships. Preserve exact host R1 output and hashing through adapter tests.
5. Use Git commits after passing the slice's actual tests; write ADRs for technical choices and continue without design sign-off.
6. Have a separate read-only AI reviewer audit the diff for wrong assumptions, hallucinated engineering facts, security and missing tests; fix and rerun. This is code review, NOT independent engineering acceptance.
7. Build/test in real Windows when available; package offline model assets only with distribution permission. Maintain four distinct gate states and actual evidence.
8. At completion provide one owner-review dossier and final Windows build if the machine supports it. If independent expert checking cannot be run, leave the gate NOT_RUN and still deliver the tested development product.

## Avoid this workflow

Do not paste a 100-page spec into a normal chat, ask for an entire finished program as prose, copy source snippets manually and hope it works. Do not force Claude to obtain approval after each code change. Do not keep rewriting broad plans instead of running code. Do not rely on self-reported model recognition accuracy or skip integration/host tests.

## Source-based tool guidance

Anthropic's current Claude Code documentation describes `CLAUDE.md`, Auto permission mode, `/permissions`, project `.claude/settings.json`, sandboxing and hooks:
- https://support.claude.com/en/articles/14554922-claude-code-user-faq
- https://support.claude.com/en/articles/14554000-claude-code-power-user-tips
- https://code.claude.com/docs/en/permissions
- https://code.claude.com/docs/en/settings

Anthropic recommends explore/plan/code/commit and test-driven development:
- https://www.anthropic.com/engineering/claude-code-best-practices

An alternative independent coding reviewer is OpenAI Codex; its official advice stresses `AGENTS.md`, sandbox/approval boundaries, testing and diff review:
- https://learn.chatgpt.com/docs/learn/best-practices
