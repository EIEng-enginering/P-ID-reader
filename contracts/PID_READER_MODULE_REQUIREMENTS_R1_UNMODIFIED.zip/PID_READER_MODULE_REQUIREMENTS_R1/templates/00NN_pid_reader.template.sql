-- TEMPLATE ONLY. The host assigns the schema version NN (24 at the time of writing: the host is at v23) and renames this file 00NN_pid_reader.sql at integration.
-- Additive: new tables and triggers only. No earlier table, column or CHECK is touched (requirement PR-F01).
-- Every table is append-only; the current state of an item is its newest pid_decision row (PR-F02).
--
-- Audit design (PR-F04): one event per RUN (M17_PID_RUN) whose 'after' carries the run row, the counts and result_sha256, and one event per decision / link /
-- second check. reconcile_model recomputes result_sha256 from the stored pid_object / pid_connection / pid_loop_proposal rows with the canonical-JSON rule of
-- requirement D (sorted keys, separators (',',':'), ensure_ascii False, no NaN, SHA-256 of the UTF-8 bytes) and compares it with the audited value, so a changed
-- row is detected without writing 20,000 events per run.
-- Event types to add to core._reconcile_audit_state as a 'continue' prefix: M17_ (next free after M16_). m3_history.VISIBLE_TABLES gets all table names below.

CREATE TABLE pid_read_run (
    run_id TEXT PRIMARY KEY,
    document_revision_id TEXT NOT NULL REFERENCES document_revision(revision_id),
    document_sha256 TEXT NOT NULL CHECK(length(document_sha256) = 64),
    page_first INTEGER NOT NULL CHECK(page_first >= 1),
    page_last INTEGER NOT NULL CHECK(page_last >= page_first AND page_last <= 500),
    module_version TEXT NOT NULL CHECK(length(trim(module_version)) BETWEEN 5 AND 40),
    schema_version INTEGER NOT NULL CHECK(schema_version >= 1),
    params_json TEXT NOT NULL,
    params_sha256 TEXT NOT NULL CHECK(length(params_sha256) = 64),
    result_sha256 TEXT NOT NULL CHECK(length(result_sha256) = 64),
    limitations_text TEXT NOT NULL CHECK(length(trim(limitations_text)) BETWEEN 20 AND 4000),
    object_count INTEGER NOT NULL CHECK(object_count BETWEEN 0 AND 20000),
    connection_count INTEGER NOT NULL CHECK(connection_count >= 0),
    models_json TEXT NOT NULL DEFAULT '[]',
    raw_result_gz BLOB,                                   -- optional compressed copy, only under the size cap (PR-F05)
    actor_display_name TEXT NOT NULL CHECK(length(trim(actor_display_name)) BETWEEN 1 AND 120),
    created_utc TEXT NOT NULL
);
CREATE INDEX idx_pid_run_doc ON pid_read_run(document_revision_id);

CREATE TABLE pid_object (
    run_id TEXT NOT NULL REFERENCES pid_read_run(run_id),
    object_id TEXT NOT NULL CHECK(object_id GLOB 'obj-*'),
    class TEXT NOT NULL CHECK(class IN ('VESSEL','TANK','COLUMN','HEAT_EXCHANGER','PUMP','COMPRESSOR','FILTER','VALVE_MANUAL','VALVE_CONTROL','VALVE_ONOFF','VALVE_CHECK',
                                        'PSV','RUPTURE_DISC','INSTRUMENT','LOGIC_SOLVER_NODE','LINE','SIGNAL_LINE','NOZZLE','OFF_PAGE_CONNECTOR','SPEC_BREAK','NOTE','OTHER','UNKNOWN')),
    page INTEGER NOT NULL CHECK(page >= 1),
    x0 REAL NOT NULL CHECK(x0 >= 0 AND x0 < 1), y0 REAL NOT NULL CHECK(y0 >= 0 AND y0 < 1),
    x1 REAL NOT NULL CHECK(x1 > 0 AND x1 <= 1), y1 REAL NOT NULL CHECK(y1 > 0 AND y1 <= 1),
    text TEXT NOT NULL,                                   -- verbatim as printed
    parsed_json TEXT NOT NULL,                            -- advisory tag parse
    confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),   -- reader confidence, not accuracy (PR-A05)
    evidence_json TEXT NOT NULL,
    attributes_json TEXT NOT NULL,                        -- verbatim strings only (PR-D04)
    PRIMARY KEY(run_id, object_id),
    CHECK(x1 > x0 AND y1 > y0)
);

CREATE TABLE pid_connection (
    run_id TEXT NOT NULL REFERENCES pid_read_run(run_id),
    connection_id TEXT NOT NULL CHECK(connection_id GLOB 'con-*'),
    type TEXT NOT NULL CHECK(type IN ('PROCESS_LINE','SIGNAL_ELECTRIC','SIGNAL_PNEUMATIC','SIGNAL_SOFTWARE','SIGNAL_CAPILLARY','MECHANICAL','UNKNOWN')),
    from_object_id TEXT NOT NULL,
    to_object_id TEXT NOT NULL,
    direction TEXT NOT NULL CHECK(direction IN ('FORWARD','BACKWARD','UNKNOWN')),
    polyline_json TEXT NOT NULL,
    confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
    evidence_json TEXT NOT NULL,
    PRIMARY KEY(run_id, connection_id),
    FOREIGN KEY(run_id, from_object_id) REFERENCES pid_object(run_id, object_id),
    FOREIGN KEY(run_id, to_object_id) REFERENCES pid_object(run_id, object_id)
);

CREATE TABLE pid_loop_proposal (
    run_id TEXT NOT NULL REFERENCES pid_read_run(run_id),
    loop_id TEXT NOT NULL CHECK(loop_id GLOB 'loop-*'),
    members_json TEXT NOT NULL,
    basis TEXT NOT NULL CHECK(length(trim(basis)) >= 10),
    confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
    PRIMARY KEY(run_id, loop_id)
);

CREATE TABLE pid_decision (
    decision_id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES pid_read_run(run_id),
    item_kind TEXT NOT NULL CHECK(item_kind IN ('OBJECT','CONNECTION','LOOP','REGION')),
    item_id TEXT NOT NULL,                                -- for REGION: a reviewer-drawn region id local to the run
    state TEXT NOT NULL CHECK(state IN ('ACCEPTED_AS_READING','REJECTED','EDITED_AND_ACCEPTED','IGNORED_REGION')),
    before_json TEXT NOT NULL DEFAULT '{}',
    after_json TEXT NOT NULL DEFAULT '{}',
    reason TEXT NOT NULL DEFAULT '',
    actor_display_name TEXT NOT NULL CHECK(length(trim(actor_display_name)) BETWEEN 1 AND 120),
    occurred_utc TEXT NOT NULL,
    CHECK(state = 'ACCEPTED_AS_READING' OR length(trim(reason)) >= 10),
    CHECK(state != 'EDITED_AND_ACCEPTED' OR (before_json != '{}' AND after_json != '{}'))
);
CREATE INDEX idx_pid_decision_item ON pid_decision(run_id, item_kind, item_id);

-- a PERSON's link from a drawing item to a host record; the module never writes these by itself (PR-G01..G06)
CREATE TABLE pid_asset_link (
    link_id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES pid_read_run(run_id),
    object_id TEXT NOT NULL,
    asset_id TEXT NOT NULL CHECK(length(asset_id) BETWEEN 1 AND 100),
    link_kind TEXT NOT NULL CHECK(link_kind IN ('REGISTERED_FROM_DRAWING','POSSIBLE_ALIAS','SAME_TAG_AS_REGISTER')),
    basis TEXT NOT NULL CHECK(length(trim(basis)) BETWEEN 10 AND 1000),
    actor_display_name TEXT NOT NULL CHECK(length(trim(actor_display_name)) BETWEEN 1 AND 120),
    occurred_utc TEXT NOT NULL,
    FOREIGN KEY(run_id, object_id) REFERENCES pid_object(run_id, object_id)
);

CREATE TABLE pid_second_check (
    check_id TEXT PRIMARY KEY,
    decision_id TEXT NOT NULL REFERENCES pid_decision(decision_id),
    outcome TEXT NOT NULL CHECK(outcome IN ('AGREES','DISAGREES')),
    note TEXT NOT NULL DEFAULT '',
    actor_display_name TEXT NOT NULL CHECK(length(trim(actor_display_name)) BETWEEN 1 AND 120),
    occurred_utc TEXT NOT NULL,
    CHECK(outcome = 'AGREES' OR length(trim(note)) >= 10)
);

CREATE TRIGGER pid_read_run_no_update BEFORE UPDATE ON pid_read_run BEGIN SELECT RAISE(ABORT, 'P&ID reads are immutable'); END;
CREATE TRIGGER pid_read_run_no_delete BEFORE DELETE ON pid_read_run BEGIN SELECT RAISE(ABORT, 'P&ID reads cannot be deleted'); END;
CREATE TRIGGER pid_object_no_update BEFORE UPDATE ON pid_object BEGIN SELECT RAISE(ABORT, 'P&ID objects are immutable'); END;
CREATE TRIGGER pid_object_no_delete BEFORE DELETE ON pid_object BEGIN SELECT RAISE(ABORT, 'P&ID objects cannot be deleted'); END;
CREATE TRIGGER pid_connection_no_update BEFORE UPDATE ON pid_connection BEGIN SELECT RAISE(ABORT, 'P&ID connections are immutable'); END;
CREATE TRIGGER pid_connection_no_delete BEFORE DELETE ON pid_connection BEGIN SELECT RAISE(ABORT, 'P&ID connections cannot be deleted'); END;
CREATE TRIGGER pid_loop_proposal_no_update BEFORE UPDATE ON pid_loop_proposal BEGIN SELECT RAISE(ABORT, 'P&ID loop proposals are immutable'); END;
CREATE TRIGGER pid_loop_proposal_no_delete BEFORE DELETE ON pid_loop_proposal BEGIN SELECT RAISE(ABORT, 'P&ID loop proposals cannot be deleted'); END;
CREATE TRIGGER pid_decision_no_update BEFORE UPDATE ON pid_decision BEGIN SELECT RAISE(ABORT, 'P&ID decisions are immutable'); END;
CREATE TRIGGER pid_decision_no_delete BEFORE DELETE ON pid_decision BEGIN SELECT RAISE(ABORT, 'P&ID decisions cannot be deleted'); END;
CREATE TRIGGER pid_asset_link_no_update BEFORE UPDATE ON pid_asset_link BEGIN SELECT RAISE(ABORT, 'P&ID asset links are immutable'); END;
CREATE TRIGGER pid_asset_link_no_delete BEFORE DELETE ON pid_asset_link BEGIN SELECT RAISE(ABORT, 'P&ID asset links cannot be deleted'); END;
CREATE TRIGGER pid_second_check_no_update BEFORE UPDATE ON pid_second_check BEGIN SELECT RAISE(ABORT, 'second checks are immutable'); END;
CREATE TRIGGER pid_second_check_no_delete BEFORE DELETE ON pid_second_check BEGIN SELECT RAISE(ABORT, 'second checks cannot be deleted'); END;
