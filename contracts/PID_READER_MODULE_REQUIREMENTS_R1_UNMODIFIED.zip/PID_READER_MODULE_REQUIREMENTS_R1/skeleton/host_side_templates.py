"""HOST-SIDE TEMPLATES (not part of the `pid_reader` package). They show the shape the integration will take, in the pattern of `hazop_relations.py` and
`lopa_endpoints.py` of the host. You deliver the finished versions as `pid_reader_host.py` (the module's database layer); the host maintainers wire them in.

Nothing here runs by itself. Names are binding (PR-F07, PR-H01); bodies are yours to write.
"""
from __future__ import annotations

# ---- module attributes the host's core.validate_file hook reads (PR-F07) -----------------------------------------------------------------------------------
from pathlib import Path

MIGRATION = Path(__file__).parent / "contracts" / "migrations" / "00NN_pid_reader.sql"          # NN assigned by the host
TABLES = {"pid_read_run", "pid_object", "pid_connection", "pid_loop_proposal", "pid_decision", "pid_asset_link", "pid_second_check"}
TRIGGERS = {f"{t}_no_{op}" for t in TABLES for op in ("update", "delete")}
EVENT_PREFIX = "M17_"                                                                           # next free after M16_ at the time of writing
EVENTS = {"M17_PID_ENABLED": "schema_migration", "M17_PID_RUN": "pid_read_run", "M17_PID_DECISION": "pid_decision",
          "M17_PID_ASSET_LINK": "pid_asset_link", "M17_PID_SECOND_CHECK": "pid_second_check"}


def enable_model(db, actor: str) -> None:
    """vNN-1 -> vNN. Idempotent; refuses any other starting version; applies MIGRATION in ONE transaction; records script sha256 in schema_migration;
    appends M17_PID_ENABLED with before {'schema_version': NN-1} and after {'schema_version': NN, 'script_sha256': ...}."""
    raise NotImplementedError


def record_run(db, actor: str, extraction: dict, *, store_raw: bool = False) -> dict:
    """Store ONE read in ONE transaction: the run row, every object / connection / loop proposal, and one M17_PID_RUN audit event whose 'after' carries
    result_sha256 and the counts. All rows or none. Refuses beyond the caps (PR-F05) with a limit code."""
    raise NotImplementedError


def decide(db, actor: str, run_id: str, item_kind: str, item_id: str, state: str, *, reason: str = "", after: dict | None = None) -> str:
    """Append one pid_decision row + M17_PID_DECISION event. Never accepts automatically (PR-E06). Edits keep before and after (PR-E05)."""
    raise NotImplementedError


def reconcile_model(db, version: int, events) -> None:
    """On open: tables equal what the audit events imply. For each M17_PID_RUN event recompute result_sha256 from the stored rows (rule: 01_REQUIREMENTS D / api.py)
    and compare. Raise CaseError('CASE_AUDIT_CHAIN_INVALID', ...) on any difference. Below the module's version, any M17_ event is an error."""
    raise NotImplementedError


# ---- service functions to add to `services` (additive; trailing optional parameters only; PR-H01) ---------------------------------------------------------
SERVICE_FUNCTIONS = {
    "enable_pid_reader": "(session)",
    "run_pid_reader": "(session, document_revision_id, pages=None, params=None)  # cancelable, off the GUI thread, one transaction",
    "list_pid_runs": "(session, document_revision_id='')",
    "get_pid_run": "(session, run_id)",
    "list_pid_objects": "(session, run_id, cls='', min_confidence=0.0, state='')",
    "decide_pid_item": "(session, run_id, item_kind, item_id, state, reason='', after=None)",
    "bulk_decide_pid_items": "(session, run_id, cls, state, min_confidence, reason='')  # per-item rows; refuses blocked classes and low confidence",
    "record_pid_second_check": "(session, decision_id, outcome, note='')",
    "link_pid_object_to_asset": "(session, run_id, object_id, asset_id, link_kind, basis)  # a person's act",
    "pid_diff": "(session, run_id_a, run_id_b)",
    "pid_reconciliation_report": "(session, document_revision_ids=None)  # report only",
    "pid_shown_in_region": "(session, region_id)  # checklist of items shown (PR-G05)",
}
