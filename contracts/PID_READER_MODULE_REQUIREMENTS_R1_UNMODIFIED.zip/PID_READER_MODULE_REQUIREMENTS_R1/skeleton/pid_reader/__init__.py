"""P&ID reader module - SKELETON. Importing this package must have no side effects (PR-B03): no file, network or registry access, no threads, no logging setup."""
__version__ = "0.0.0"
SCHEMA_VERSION = 1
