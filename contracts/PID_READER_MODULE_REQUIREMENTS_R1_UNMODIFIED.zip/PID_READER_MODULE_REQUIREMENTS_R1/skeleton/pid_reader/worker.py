"""The worker process (PR-B04..B06, B12): `python -m pid_reader.worker run --input DOC.pdf --params PARAMS.json --output RESULT.json --workdir TMP`.

* The host starts it with a private temporary folder (`--workdir`) and may terminate it at any moment; nothing outside that folder is written and everything inside is
  removed on exit (PR-B06).
* Exit codes: 0 completed, 2 input refused, 3 limit exceeded, 4 internal error, 5 cancelled (PR-B05).
* Standard error carries JSON lines with counts, codes and progress ONLY, never document text, tags or file contents (PR-B05, PR-J02).
* No network access. Skeleton: wire in `read_pid` once it exists.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

from .api import Cancelled, CancelToken, LimitExceeded, ReadParams, RefusedInput, canonical_json, read_pid, sha256_hex

EXIT_OK, EXIT_REFUSED, EXIT_LIMIT, EXIT_INTERNAL, EXIT_CANCELLED = 0, 2, 3, 4, 5


def _progress(**fields: object) -> None:
    sys.stderr.write(json.dumps(fields, sort_keys=True) + "\n")
    sys.stderr.flush()


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="pid_reader.worker")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run")
    for name in ("--input", "--params", "--output", "--workdir"):
        run.add_argument(name, required=True)
    run.add_argument("--document-revision-id", default="")
    run.add_argument("--filename", default="")
    run.add_argument("--expected-sha256", default="")
    args = parser.parse_args(argv)
    workdir = Path(args.workdir)
    try:
        params_raw = json.loads(Path(args.params).read_text(encoding="utf-8"))
        pages = params_raw.pop("pages", None)
        known = {k: params_raw.pop(k) for k in list(params_raw) if k in ReadParams.__dataclass_fields__ and k != "extras"}
        params = ReadParams(pages=tuple(pages) if pages else None, extras=params_raw, **known)     # leftovers become extras and are refused
        data = Path(args.input).read_bytes()
        _progress(event="start", bytes=len(data), sha256=sha256_hex(data))
        result = read_pid(data, params, CancelToken(), document_revision_id=args.document_revision_id, filename=args.filename, expected_sha256=args.expected_sha256)
        Path(args.output).write_text(canonical_json(result), encoding="utf-8")
        _progress(event="done", objects=len(result["objects"]), connections=len(result["connections"]))
        return EXIT_OK
    except LimitExceeded as exc:
        _progress(event="refused", code=exc.code)
        return EXIT_LIMIT
    except RefusedInput as exc:
        _progress(event="refused", code=exc.code)
        return EXIT_REFUSED
    except Cancelled:
        _progress(event="cancelled")
        return EXIT_CANCELLED
    except Exception as exc:                       # no traceback text: it could contain document content
        _progress(event="error", kind=type(exc).__name__)
        return EXIT_INTERNAL
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
