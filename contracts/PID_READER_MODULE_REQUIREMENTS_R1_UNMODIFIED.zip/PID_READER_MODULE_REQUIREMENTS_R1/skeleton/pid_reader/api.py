"""The in-process library API (PR-B10) and the deterministic helpers every implementation must share (PR-B09, PR-D09).

`canonical_json`, `sha256_hex`, `result_sha256`, `object_id` and friends are REFERENCE implementations: they define the rules. The reading itself (`read_pid`) is what you
develop; it is deliberately not implemented here.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field

from . import SCHEMA_VERSION, __version__

# --- limits fixed by the host (PR-C02); a parameter may only lower them ---------------------------------------------------------------------------------
MAX_PDF_BYTES = 16 * 1024 * 1024
MAX_PAGES = 500
MAX_RENDER_PIXELS = 12_000_000
# --- run fields excluded from the determinism hash (PR-B09) ---------------------------------------------------------------------------------------------
RUN_FIELDS = ("run_id", "started_utc", "finished_utc", "result_sha256")


class RefusedInput(Exception):
    """The input is refused; `code` is one of the manifest's error_codes (for example PID_ENCRYPTED, PID_NO_TEXT_LAYER, PID_SHA_MISMATCH)."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code, self.message = code, message


class LimitExceeded(RefusedInput):
    pass


class Cancelled(Exception):
    pass


class CancelToken:
    """Checked by the reader at least every few hundred milliseconds; the worker sets it when the host terminates or asks to cancel."""

    def __init__(self) -> None:
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def check(self) -> None:
        if self._cancelled:
            raise Cancelled()


@dataclass(frozen=True)
class ReadParams:
    """Unknown parameters are refused (PR-B10). Add fields here, never accept free-form dictionaries silently."""
    pages: tuple[int, ...] | None = None          # None = every page
    bulk_accept_min_confidence: float = 0.90      # items below this can never be bulk-accepted (PR-E04); the host enforces it
    max_pdf_bytes: int = MAX_PDF_BYTES
    max_pages: int = MAX_PAGES
    max_render_pixels: int = MAX_RENDER_PIXELS
    extras: dict = field(default_factory=dict)    # must stay empty; non-empty is refused by `validate_params`

    def validate(self) -> None:
        if self.extras:
            raise RefusedInput("PID_UNKNOWN_PARAMETER", "Unknown parameter(s): " + ", ".join(sorted(self.extras)))
        if self.max_pdf_bytes > MAX_PDF_BYTES or self.max_pages > MAX_PAGES or self.max_render_pixels > MAX_RENDER_PIXELS:
            raise RefusedInput("PID_LIMIT_RAISED", "A parameter may lower a host limit but never raise it.")
        if not 0 <= self.bulk_accept_min_confidence <= 1:
            raise RefusedInput("PID_BAD_PARAMETER", "bulk_accept_min_confidence must be between 0 and 1.")

    def as_dict(self) -> dict:
        return {"pages": list(self.pages) if self.pages is not None else None, "bulk_accept_min_confidence": self.bulk_accept_min_confidence,
                "max_pdf_bytes": self.max_pdf_bytes, "max_pages": self.max_pages, "max_render_pixels": self.max_render_pixels}


# --- reference rules ------------------------------------------------------------------------------------------------------------------------------------
def canonical_json(value: object) -> str:
    """The host's rule (core.canonical_json): sorted keys, compact separators, no ASCII escaping, no NaN."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def params_sha256(params: ReadParams) -> str:
    return sha256_hex(canonical_json(params.as_dict()).encode("utf-8"))


def result_sha256(extraction: dict) -> str:
    """SHA-256 of the canonical JSON of the extraction with the run fields removed from `provenance`."""
    body = json.loads(canonical_json(extraction))
    for key in RUN_FIELDS:
        body["provenance"].pop(key, None)
    return sha256_hex(canonical_json(body).encode("utf-8"))


def _round_box(bbox: dict) -> list[int]:
    """Boxes are rounded to 1/1000 of the page before hashing so that float noise cannot change an id."""
    return [round(bbox[k] * 1000) for k in ("x0", "y0", "x1", "y1")]


def stable_id(prefix: str, *parts: object) -> str:
    digest = sha256_hex(canonical_json(list(parts)).encode("utf-8"))[:16]
    return f"{prefix}-{digest}"


def object_id(cls: str, page: int, bbox: dict, text: str) -> str:
    return stable_id("obj", cls, page, _round_box(bbox), text)


def connection_id(kind: str, from_id: str, to_id: str, polyline: list[list[float]]) -> str:
    return stable_id("con", kind, from_id, to_id, [[round(x * 1000), round(y * 1000)] for x, y in polyline])


def loop_id(member_ids: list[str]) -> str:
    return stable_id("loop", sorted(member_ids))


def shared_id(kind: str, object_ids: list[str]) -> str:
    return stable_id("shr", kind, sorted(object_ids))


# --- what you develop -----------------------------------------------------------------------------------------------------------------------------------
def read_pid(pdf_bytes: bytes, params: ReadParams, cancel: CancelToken | None = None, *, document_revision_id: str = "", filename: str = "", expected_sha256: str = "") -> dict:
    """Read one P&ID document and return a `pid_extraction` dictionary (schemas/pid_extraction.schema.json).

    Contract (see 01_REQUIREMENTS.md): verify `expected_sha256` against the bytes first (PR-C01); enforce the limits (PR-C02); treat the bytes as hostile (PR-C03);
    call `cancel.check()` regularly (PR-B04); return everything as UNVERIFIED proposals with verbatim text and evidence (PR-A02, PR-D03); report what could not be read
    (PR-D07); fill `provenance` including `limitations_text`; compute `result_sha256` last with `result_sha256()`; and be deterministic (PR-B09)."""
    params.validate()
    if expected_sha256 and sha256_hex(pdf_bytes) != expected_sha256:
        raise RefusedInput("PID_SHA_MISMATCH", "The document bytes do not match the recorded SHA-256.")
    if len(pdf_bytes) > params.max_pdf_bytes:
        raise LimitExceeded("PID_LIMIT_BYTES", "The PDF is larger than the host limit.")
    raise NotImplementedError("The reader is what you are going to develop.")


def schema_version() -> int:
    return SCHEMA_VERSION


def module_version() -> str:
    return __version__
