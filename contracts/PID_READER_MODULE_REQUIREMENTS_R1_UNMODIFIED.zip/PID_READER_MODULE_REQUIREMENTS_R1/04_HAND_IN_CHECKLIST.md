# Hand-in checklist: what must be in the delivery before integration

Tick each line yourself and keep the evidence beside it. A line the delivery cannot satisfy is written down as an open issue, never left blank and never ticked. "NOT_RUN" is an honest answer.

## 1. The bundle (one folder or ZIP, with a file list and SHA-256 of every file)
- [ ] `pid_reader/` package source (PR-B01) and `module.json` that passes `schemas/module_manifest.schema.json` (PR-B02)
- [ ] `pid_reader_host.py` (database layer: `enable_model`, `record_run`, `decide`, `reconcile_model`, `TABLES`, `TRIGGERS`, `MIGRATION`, the service functions) and the finished `00NN_pid_reader.sql` with the host-side hook text for `core.validate_file` and `m3_history.VISIBLE_TABLES` (PR-F01..F07, PR-H01)
- [ ] `pid_reader/ui/` review window and the list of strings it shows (PR-I01..I07)
- [ ] vendored wheels of every dependency, `DEPENDENCY_REGISTER` rows (package, pinned version, source, licence, review status, use), SBOM with hashes (PR-B07, PR-J05)
- [ ] every model file with SHA-256, licence, training-data provenance and model card; or the statement "no model" (PR-B08)
- [ ] test suite and the report of a run in a NEW evidence folder, no network (PR-M01, PR-M02)
- [ ] the malformed-input corpus and its results (PR-J06)
- [ ] the gold set, its split record, the annotation files, and the generator or clearance record of every drawing (PR-A06, PR-L01)
- [ ] the owner's dated threshold record, written before the benchmark was run (PR-L03)
- [ ] the benchmark report with all metrics of PR-L02, the failure analysis and the calibration table (PR-L05, PR-L06)
- [ ] the independent benchmark run signed by someone other than the developer, or "NOT_RUN" (PR-L04)
- [ ] documentation: README, user-guide section, limitations, data-handling statement, vocabulary table, algorithm description, OI-style open issues (PR-N01..N03)
- [ ] a sample extraction produced by the real reader that passes `tools/check_extraction.py` (PR-D01)

## 2. Statements the delivery must make plainly
- [ ] What the reader cannot read (by class and by drawing style), with examples
- [ ] Which numbers come from the benchmark and which report id each comes from (PR-N02)
- [ ] Which classes are blocked from bulk acceptance (PR-L03)
- [ ] Which resource limits apply and what the module does when they are reached
- [ ] That no person other than the developer has used it, if that is still true
- [ ] Which licences need an owner / legal decision before distribution

## 3. Integration rehearsal (done with the host maintainers on a COPY of the host tree)
- [ ] hashed backup of the host build named in `module.json`
- [ ] the migration applies at the next free schema number; earlier schema fingerprints unchanged
- [ ] host suite and module suite both pass in a NEW `LOCAL_BUILD_Rnn` folder
- [ ] `verify_current_contract.py` compares ADDITIVE; the new manifest is frozen; earlier manifest hashes unchanged
- [ ] `upgrade_worksheet_to` extended; the example case rebuilt at the new schema
- [ ] the packs rebuilt and verified; behaviour changes written as an OI entry for the owner to accept
- [ ] `m3_history.VISIBLE_TABLES`, the JSON export and `core` hooks extended; `reconcile_model` tamper test passes
- [ ] real Windows check of the review window at 100 / 125 / 150 % by a person (gate G6), or NOT_RUN
