# Decisions only the owner can make (before or during development)

The requirements carry placeholders where a number or a choice is the owner's. Record each decision with a date and who made it; the developer must not decide these after seeing results.

| # | Decision | Why it matters | Placeholder in the requirements |
|---|---|---|---|
| 1 | **Which inputs** the first delivery reads: vector PDF only, or also scanned PDF (needs OCR), DEXPI / Proteus XML, DXF / DWG | Scanned drawings need an OCR engine and a model, with their licences and accuracy limits; vector PDFs are far easier | PR-C05, PR-C08 |
| 2 | **Machine-learning models allowed?** Which licences are acceptable? CPU only? | Decides the dependency and licence review (PR-B07, PR-B08) and the size budget | CPU only, shipped inside the delivery |
| 3 | **Acceptance thresholds** per class (object precision / recall, tag exact match, connection precision / recall, loop precision, silent-miss rate) | Without them "good enough" is a feeling. They must be fixed before the benchmark is run | PR-L03: no numbers given on purpose |
| 4 | **The gold set**: how many drawings (placeholder 30), what mix, who annotates, who clears real drawings if any are used, who keeps the held-out test split | The only evidence of accuracy the program will ever have | PR-L01 |
| 5 | **Who runs the independent benchmark** and who signs it | PR-L04 makes this a gate | NOT_RUN until done |
| 6 | **Reference PC** and the time / memory caps | Defines "worst case" for 16 MiB / 500 pages | 8 GB RAM, 4 cores, 30 min, 4 GB |
| 7 | **Size caps**: objects per run (20,000), stored result per run (8 MiB), delivery size (300 MB) | Keeps the case file portable | PR-F05, PR-B13 |
| 8 | **Optional remote or loopback model?** Default is none | Needs the organisation's data-transfer decision (the host already treats any non-loopback host as ONLINE) | PR-J03: OFF by default |
| 9 | **Distribution licence review** of every dependency and model together with the host's Qt / PySide6 terms | The host's own distribution is still an open owner / legal decision | PR-B07 |
| 10 | **Real client drawings** may or may not ever be used for development. If yes, where they live and who may see them | The host's data policy currently allows synthetic data only | PR-A06 |
| 11 | **Drawing standard** assumptions: ISA-5.1 style tags only, or also company / EN / ISO styles; symbol library (own, ISO 10628 / ISA, company standard) and its licence | Tag parsing and symbol recognition depend on it; do not copy standard text into the delivery | PR-D03 |
| 12 | **Review policy**: who may accept readings, whether a second person must check a sample, the sample rate | The module records it; the policy is the organisation's | PR-E08 |
| 13 | **Export**: should accepted readings appear in the Word / Excel reports, and in what words | Extra report sections are optional work in the host | PR-F06 |
