"""Tests of tools/check_extraction.py against the synthetic sample. Run from the pack folder:  python -m unittest discover -s tests -v"""
from __future__ import annotations

import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT / "skeleton"))

import check_extraction as chk  # noqa: E402
from pid_reader import api  # noqa: E402

SAMPLE = json.loads((ROOT / "examples" / "sample_extraction.json").read_text(encoding="utf-8"))


def rehash(doc: dict) -> dict:
    doc["provenance"]["result_sha256"] = chk.recompute_result_hash(doc)
    return doc


def mutate(fn) -> dict:
    doc = copy.deepcopy(SAMPLE)
    fn(doc)
    return rehash(doc)


class SampleTests(unittest.TestCase):
    def test_the_sample_passes_and_both_hash_rules_agree(self) -> None:
        self.assertEqual(chk.check(SAMPLE), [])
        self.assertEqual(api.result_sha256(SAMPLE), SAMPLE["provenance"]["result_sha256"])
        self.assertEqual(chk.recompute_result_hash(SAMPLE), SAMPLE["provenance"]["result_sha256"])

    def test_run_fields_do_not_change_the_result_hash_but_content_does(self) -> None:
        other = copy.deepcopy(SAMPLE)
        other["provenance"].update({"run_id": "another-run", "started_utc": "2030-01-01T00:00:00Z", "finished_utc": "2030-01-01T00:00:09Z"})
        self.assertEqual(chk.recompute_result_hash(other), SAMPLE["provenance"]["result_sha256"])
        other["objects"][0]["text"] += "x"
        self.assertNotEqual(chk.recompute_result_hash(other), SAMPLE["provenance"]["result_sha256"])

    def test_ids_are_deterministic_and_ignore_float_noise(self) -> None:
        box = {"x0": 0.1, "y0": 0.2, "x1": 0.3, "y1": 0.4}
        noisy = {"x0": 0.1000001, "y0": 0.1999999, "x1": 0.3000002, "y1": 0.4}
        self.assertEqual(api.object_id("VESSEL", 1, box, "V-100"), api.object_id("VESSEL", 1, noisy, "V-100"))
        self.assertNotEqual(api.object_id("VESSEL", 1, box, "V-100"), api.object_id("VESSEL", 2, box, "V-100"))
        self.assertEqual(api.loop_id(["b", "a"]), api.loop_id(["a", "b"]))

    def test_a_tampered_result_is_caught_by_its_hash(self) -> None:
        doc = copy.deepcopy(SAMPLE)
        doc["objects"][0]["confidence"] = 0.99
        self.assertTrue(any("result_sha256" in e for e in chk.check(doc)))


class RuleTests(unittest.TestCase):
    def errors(self, fn) -> list[str]:
        return chk.check(mutate(fn))

    def test_an_object_must_stay_unverified(self) -> None:
        self.assertTrue(any("UNVERIFIED" in e for e in self.errors(lambda d: d["objects"][0].update(status="VERIFIED"))))

    def test_a_box_outside_the_page_or_inverted_is_refused(self) -> None:
        self.assertTrue(any("box" in e for e in self.errors(lambda d: d["objects"][0]["bbox"].update(x1=1.2))))
        self.assertTrue(any("box" in e for e in self.errors(lambda d: d["objects"][0]["bbox"].update(x0=0.9, x1=0.2))))

    def test_an_unknown_class_is_refused(self) -> None:
        self.assertTrue(any("controlled list" in e for e in self.errors(lambda d: d["objects"][0].update(**{"class": "ROBOT"}))))

    def test_a_connection_to_nothing_is_refused(self) -> None:
        self.assertTrue(any("does not exist" in e for e in self.errors(lambda d: d["connections"][0]["to"].update(object_id="obj-ffffffffffffffff"))))

    def test_a_number_attribute_must_be_a_verbatim_string(self) -> None:
        self.assertTrue(any("verbatim string" in e for e in self.errors(lambda d: d["objects"][0]["attributes"].update(set_pressure=12.5))))

    def test_the_loop_statement_cannot_be_changed_into_a_claim(self) -> None:
        self.assertTrue(any("independence_statement" in e for e in self.errors(lambda d: d["loop_proposals"][0].update(independence_statement="Independent loops."))))
        self.assertTrue(any("basis" in e for e in self.errors(lambda d: d["loop_proposals"][0].update(basis="The two loops are independent of each other."))))

    def test_the_absence_statement_is_required(self) -> None:
        self.assertTrue(any("absence_statement" in e for e in self.errors(lambda d: d["shared_component_evidence"][0].update(absence_statement=""))))

    def test_module_text_cannot_say_verified_but_may_deny_it(self) -> None:
        self.assertTrue(any("verified" in e for e in self.errors(lambda d: d["provenance"].update(limitations_text="All readings are verified against the plant, which is why they are listed."))))
        self.assertEqual(self.errors(lambda d: d["provenance"].update(limitations_text="Nothing here is verified; the list of items is not complete and scanned pages are refused.")), [])

    def test_text_printed_on_the_drawing_is_exempt(self) -> None:
        def stamp(d):
            d["objects"][1]["text"] = "APPROVED FOR CONSTRUCTION"
            d["objects"][1]["evidence"][0]["text"] = "APPROVED FOR CONSTRUCTION"
        self.assertEqual(self.errors(stamp), [])

    def test_a_refused_page_needs_a_code_and_holds_no_objects(self) -> None:
        def refuse(d):
            d["pages"][0].update(read_status="REFUSED")
        errors = self.errors(refuse)
        self.assertTrue(any("refusal_code" in e for e in errors))
        self.assertTrue(any("REFUSED page" in e for e in errors))

    def test_summary_counts_must_match(self) -> None:
        self.assertTrue(any("summary" in e for e in self.errors(lambda d: d["summary"].update(object_count=99))))

    def test_missing_evidence_is_refused(self) -> None:
        self.assertTrue(any("no evidence" in e for e in self.errors(lambda d: d["objects"][0].update(evidence=[]))))


if __name__ == "__main__":
    unittest.main()
