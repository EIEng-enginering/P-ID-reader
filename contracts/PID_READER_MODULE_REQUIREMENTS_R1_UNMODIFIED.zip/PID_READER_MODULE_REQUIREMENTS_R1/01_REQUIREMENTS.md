# P&ID reader as a module of the Worksheet program: requirements

Pack revision R1, written 2026-11-07 against Worksheet 0.25.0a1 (schema v23, contract R22). **104 requirements** (91 MUST, 12 SHOULD, 1 MAY).

## 1. What this is for
You develop a P&ID reader as a separate program, outside the Worksheet program, in as much detail as you like. When it is finished you hand it in, and it is added to the Worksheet program as a **module**: a new, additive part that reads a P&ID that is already stored in a study (`.hzcase`) and **proposes** the equipment, instruments, tags and connections it finds, for people to review. This document says what the reader and its delivery must look like so that adding it is a controlled, additive step and not a rewrite of either program.

Words: **MUST** = required for hand-in; **SHOULD** = expected unless a reason is written down; **MAY** = allowed. Every requirement has an id (`PR-B04`), a way to check it, and a row in `03_ACCEPTANCE_CHECKLIST.csv` with status NOT_RUN.

## 2. The principle everything else follows from
**The reader proposes. People decide. The record says who.** A P&ID reading is a claim about a drawing; it is not a fact about the plant. The host program already works this way for AI proposals, for safeguards (recorded claims, unverified) and for protection assets (no credit without evidence and a named reviewer). The module follows the same rules: nothing it produces is verified, approved, complete, credited or independent, and the program never lets it say so.

## 3. Out of scope (do not build, do not claim)
* Deciding whether a drawing matches the plant, is current, or is correct. Revision numbers and dates are read as text only.
* Writing HAZOP rows, causes, consequences, safeguards or recommendations; assigning LOPA credit, PFDs, SIL or independence; changing the asset register by itself.
* PFDs, plot plans, isometrics, 3-D models, document control, drawing revision control.
* Training or tuning on real client drawings (unless the owner clears it in writing, decision 10).
* Online services, telemetry, automatic updates.

## 4. How the module sits in the program
```
  Worksheet program (host, Python 3.12 + PySide6 6.12.0)                      pid_reader module (your delivery)
  -----------------------------------------------------                      --------------------------------------------
  document_revision (PDF bytes, SHA-256, ACTIVE)  --bytes+params-->           worker process  python -m pid_reader.worker
  services.run_pid_reader (cancelable, off GUI)   <--one JSON result--        reads, never writes outside its temp folder
        |                                                                      result = pid_extraction.schema.json
        v   one transaction: all rows or none
  pid_read_run / pid_object / pid_connection ...  (append-only, audited, reconciled on open)
        |
        v   a PERSON reviews in the review window: accept / edit / reject, with reason
  pid_decision (append-only)  ---> a PERSON may then, through the EXISTING screens, register an asset, record a POSSIBLE alias,
                                    link evidence (kind DRAWING) to a LOPA layer, or draw and verify a drawing region
```

## 5. Life cycle
1. **Develop outside** (you), against these requirements, the schemas, the SQL template and the skeleton in this pack.
2. **Decide** the open items in `05_OWNER_DECISIONS_NEEDED.md` before the benchmark is run (in particular the thresholds).
3. **Hand in** the bundle listed in `04_HAND_IN_CHECKLIST.md`.
4. **Rehearse** the integration on a copy of the host tree (requirement M04); fix what breaks; nothing touches the live tree until the rehearsal is clean.
5. **Integrate** as an additive migration, additive services and a frozen contract revision; rebuild the example and the packs; record the behaviour changes as an open-issue entry for the owner to accept.
6. **Accept**: the owner accepts the behaviour changes; the independent benchmark run (L04) and the real-Windows UI check stay NOT_RUN until a person does them.

## 6. Words the program uses for statuses (use exactly these)
| Word | Meaning |
|---|---|
| PROPOSED / UNVERIFIED | The reader found it. No person has looked at it. It says nothing about the drawing or the plant. |
| ACCEPTED_AS_READING | A named person accepted it as a reading of THIS drawing revision. Not a verification of the plant or of the drawing. |
| EDITED_AND_ACCEPTED | A named person corrected it and accepted the corrected reading. Original and corrected values are both kept. |
| REJECTED | A named person said the reader got it wrong. Kept in the history, with the reason. |
| IGNORED_REGION | A named person marked a region as 'not a P&ID item', with a reason. |
| STALE_SOURCE | The drawing revision it was read from was withdrawn or replaced. Not offered for new links. |
| reader confidence | The reader's own score for its extraction, 0 to 1. Not accuracy and not a probability, unless calibrated on an independent gold set and reported. |
| NOT_RUN | A check that nobody has performed. Never shown as passed. |

## 7. Two rules defined once, used everywhere
**Canonical JSON** (requirement B09, D01): `json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)`, hashed as SHA-256 of its UTF-8 bytes. This is the host's own `core.canonical_json`.

**`result_sha256`**: take the whole extraction, remove from `provenance` the four run fields `run_id`, `started_utc`, `finished_utc` and `result_sha256`, apply canonical JSON, take the SHA-256. Same input, same parameters and same module version must give the same value. Reference code: `skeleton/pid_reader/api.py`; independent check: `tools/check_extraction.py`.

**Coordinates**: normalised to the page, origin top-left, `0 <= x0 < x1 <= 1`, `0 <= y0 < y1 <= 1`: exactly the host's `drawing_region`. **Ids**: `obj-`, `con-`, `loop-`, `shr-` plus the first 16 hex characters of the SHA-256 of canonical JSON of the identifying parts (class, page, box rounded to 1/1000 of the page, text) so that float noise cannot change an id.

## 8. The requirements

### A. Scope and principles

**PR-A01 (MUST)** The module reads a P&ID document and produces PROPOSALS only: drawing objects, tags and connections. It never creates, edits, accepts or credits a HAZOP, LOPA, protection-asset, SIF or alias record by itself.  
*How checked:* Test: after a run, every host table except the module's own tables is byte-identical.

**PR-A02 (MUST)** Every extracted item is UNVERIFIED when created. Only a named person's recorded decision changes that, and that decision never implies the drawing is correct, complete, current or approved.  
*How checked:* Test + inspection of every status word in UI and exports.

**PR-A03 (MUST)** No module-authored text (UI, report, log, limitations text, warning text, basis text) may say or imply that a P&ID is verified, validated, approved, as-built, certified or complete, or that a SIL, PFD, credit or independence follows from it. Text printed on the drawing is quoted verbatim and is exempt.  
*How checked:* Test: forbidden-word check in `tools/check_extraction.py` plus UI string review.

**PR-A04 (MUST)** Every run record carries a limitations text that says what the reader cannot do (for example: scanned pages without OCR, symbols outside its library, line continuations across sheets, handwritten markups).  
*How checked:* Inspection.

**PR-A05 (MUST)** A confidence value is called 'reader confidence' and is the reader's own score. It is never called accuracy or probability of being correct unless it has been calibrated on an independent held-out gold set (section L) and the calibration is reported.  
*How checked:* Inspection + calibration report.

**PR-A06 (MUST)** The module, its tests, its logs and its delivery contain no real client drawing. Development and testing use synthetic drawings or drawings the owner has cleared in writing.  
*How checked:* Inspection of the delivery and of the data-source manifest.

**PR-A07 (MUST)** The module works fully offline under a standard (non-administrator) Windows 10/11 x64 account.  
*How checked:* Demonstration on a clean account with the network disabled.

**PR-A08 (MUST)** The module makes no network connection at install, import or run, except through the host's consent mechanism for an optional declared provider (J03).  
*How checked:* Test: run under a socket-blocking harness.

### B. Packaging, process and interface

**PR-B01 (MUST)** One importable Python package `pid_reader` (Python 3.12). The core has no Qt import. Any user interface lives in `pid_reader.ui` and uses only PySide6 6.12.0 with the host's pinned Qt packages.  
*How checked:* Inspection + import test with Qt absent.

**PR-B02 (MUST)** A `module.json` manifest that validates against `schemas/module_manifest.schema.json`: name, SemVer version, host contract range, entry points, declared capabilities and object classes, pinned dependencies with licence and SHA-256, models, limits, error codes.  
*How checked:* Test: schema validation.

**PR-B03 (MUST)** Importing the package has no side effects: no file, network or registry access, no threads, no logging configuration, no environment change.  
*How checked:* Test.

**PR-B04 (MUST)** Reading runs in a separate operating-system process (`python -m pid_reader.worker`) that receives the document bytes and parameters, returns one JSON result, and can be terminated by the host at any moment (cancel) without leaving partial state anywhere.  
*How checked:* Test: kill the worker mid-run; nothing remains.

**PR-B05 (MUST)** Worker exit codes: 0 completed, 2 input refused, 3 limit exceeded, 4 internal error, 5 cancelled. Standard error carries counts, codes and progress only, never document content.  
*How checked:* Test.

**PR-B06 (MUST)** The worker writes only inside the temporary folder the host gives it and removes everything on exit. It keeps no cache anywhere else.  
*How checked:* Test: file-system diff before and after.

**PR-B07 (MUST)** Dependencies are pinned, each with its licence, source and SHA-256 recorded in the host's DEPENDENCY_REGISTER format, and delivered as vendored wheels so that integration needs no network. Pure Python or Windows x64 wheels only. Whether each licence allows distribution with the host is an owner / legal decision (gate), not assumed.  
*How checked:* Inspection of the dependency register and the wheel hashes.

**PR-B08 (MUST)** Any machine-learning model is shipped inside the delivery, pinned by SHA-256, with its licence, its training-data provenance and a model card; runs on CPU; is deterministic (fixed seeds, recorded thread count); and is never downloaded at run time. The module also states what it does without the model.  
*How checked:* Inspection + determinism test.

**PR-B09 (MUST)** Determinism: the same input bytes, the same parameters and the same module version give byte-identical canonical JSON, apart from the declared run fields (run id, start and end time). `result_sha256` is the SHA-256 of that canonical JSON (rule in 01_REQUIREMENTS, section D).  
*How checked:* Test: two runs compared.

**PR-B10 (MUST)** An in-process library API mirrors the worker for tests: `read_pid(pdf_bytes, params, cancel=None) -> PidExtraction`. Unknown parameters are refused, not ignored.  
*How checked:* Test.

**PR-B11 (MUST)** The output carries an integer `schema_version`. A change that is not additive raises it; the module declares which versions it reads and writes.  
*How checked:* Inspection.

**PR-B12 (SHOULD)** The worker reports progress (page n of N) as JSON lines on standard error.  
*How checked:* Test.

**PR-B13 (MUST)** The delivery has a stated size budget (owner decision; placeholder 300 MB including models) and a list of every file with its SHA-256.  
*How checked:* Inspection.

### C. Inputs

**PR-C01 (MUST)** The input is the exact bytes of one ACTIVE embedded document revision, passed with its revision id, filename and SHA-256. The module recomputes the SHA-256, refuses on a mismatch, and records it in the run.  
*How checked:* Test.

**PR-C02 (MUST)** The host limits are enforced: PDF at most 16 MiB, at most 500 pages, at most 12,000,000 pixels per rendered page (see `drawing_limits.py`). Beyond a limit the module refuses with a limit code. A limit can only be lowered by parameter, never raised.  
*How checked:* Test.

**PR-C03 (MUST)** The input is treated as hostile. Encrypted or password-protected files are refused (no password is ever tried). JavaScript, launch actions and embedded files are ignored and never executed. External references are never followed. Decompression, recursion and object counts are bounded.  
*How checked:* Test with the malformed corpus (J06).

**PR-C04 (MUST)** All coordinates are normalised to the page, origin top-left, x0 < x1 and y0 < y1, all within 0..1, so a result maps onto a host `drawing_region` without conversion. Page rotation and crop boxes are accounted for.  
*How checked:* Test with rotated and cropped pages.

**PR-C05 (MUST)** Each page is classified VECTOR_TEXT, RASTER_ONLY, MIXED or NOT_PID (title page, legend, data sheet) with a reason. A RASTER_ONLY page is read only if an OCR component is part of the delivery (B07, B08); otherwise it is refused with code NO_TEXT_LAYER. A page is never skipped silently.  
*How checked:* Test.

**PR-C06 (SHOULD)** The title block (drawing number, revision, date, sheet x of y, title, units) is read as proposals with evidence. Revision and date are never used to decide whether a drawing is current.  
*How checked:* Test.

**PR-C07 (SHOULD)** A legend or symbol sheet in the same run may be used to adapt symbol recognition; any mapping taken from it is itself a proposal with evidence.  
*How checked:* Test.

**PR-C08 (MAY)** Later input adapters (DEXPI / Proteus XML, DXF / DWG, high-resolution TIFF / PNG) are separate adapters with their own limits and requirements; they are out of scope for the first delivery unless the owner decides otherwise.  
*How checked:* Inspection.

**PR-C09 (MUST)** For a multi-sheet set, each sheet is a document revision of its own. Off-page connectors are recorded with their printed label. A cross-sheet link is proposed only between sheets supplied in the same run, with the evidence of both ends.  
*How checked:* Test.

### D. Output contract

**PR-D01 (MUST)** The output validates against `schemas/pid_extraction.schema.json` and passes `tools/check_extraction.py`, both run in the module's tests.  
*How checked:* Test.

**PR-D02 (MUST)** Object classes come from a controlled list: VESSEL, TANK, COLUMN, HEAT_EXCHANGER, PUMP, COMPRESSOR, FILTER, VALVE_MANUAL, VALVE_CONTROL, VALVE_ONOFF, VALVE_CHECK, PSV, RUPTURE_DISC, INSTRUMENT, LOGIC_SOLVER_NODE, LINE, SIGNAL_LINE, NOZZLE, OFF_PAGE_CONNECTOR, SPEC_BREAK, NOTE, OTHER, UNKNOWN. A symbol the reader does not recognise is UNKNOWN with its bounding box; it is never guessed.  
*How checked:* Test.

**PR-D03 (MUST)** Each object has a deterministic id, a class, the VERBATIM printed text, an advisory tag parse (measured variable, function letters, loop number, suffix; `parse_status` PARSED, PARTIAL or UNPARSED), page, bounding box, reader confidence, evidence (page, box, text snippet, text-layer span reference when available) and verbatim attributes. The verbatim text is authoritative; the parse is advisory.  
*How checked:* Test.

**PR-D04 (MUST)** Numbers with units printed on the drawing (set pressure, design pressure, size, rating) are kept as verbatim strings with the unit as printed. The module never converts or evaluates them and nothing it outputs feeds a HAZOP or LOPA calculation.  
*How checked:* Test + inspection.

**PR-D05 (MUST)** A connection joins two objects (or an object and an off-page connector) and has a type (PROCESS_LINE, SIGNAL_ELECTRIC, SIGNAL_PNEUMATIC, SIGNAL_SOFTWARE, SIGNAL_CAPILLARY, MECHANICAL, UNKNOWN), a polyline in normalised coordinates, evidence and reader confidence. Flow direction is stated only when an arrow is found; otherwise it is UNKNOWN.  
*How checked:* Test.

**PR-D06 (MUST)** Instrument loops (sensor, logic solver, final element) may be proposed from signal connections and loop numbers as `loop_proposals` with a basis text. A proposal never states independence.  
*How checked:* Test.

**PR-D07 (MUST)** Whatever could not be read or is ambiguous is reported in `unreadable_regions` and `warnings` with a code (for example OVERLAPPING_TEXT, BROKEN_LINE, AMBIGUOUS_SYMBOL, LOW_CONTRAST, MARKUP_PRESENT). Silent omission is a defect.  
*How checked:* Test with the gold set (L02: silent-miss rate).

**PR-D08 (MUST)** A provenance block records the module name and version, schema version, parameters and their SHA-256, input SHA-256, model ids and hashes, UTC start and end, minimal host information, the limitations text and `result_sha256`.  
*How checked:* Test.

**PR-D09 (MUST)** Item ids are deterministic (a hash of class, page, rounded box and text), so a re-run on the same document gives the same ids. A `diff` function compares two runs (added, removed, changed objects and connections) and is used when a new drawing revision is attached.  
*How checked:* Test.

**PR-D10 (MUST)** Revision clouds, red-lines and handwriting are flagged MARKUP_PRESENT where detected. The module never applies the meaning of a markup.  
*How checked:* Test.

**PR-D11 (SHOULD)** The run reports self-checks: counts per class, duplicate tags on a sheet, tags with no object, objects with no tag, dangling connections.  
*How checked:* Test.

### E. Human review and decisions

**PR-E01 (MUST)** Review states are PROPOSED, ACCEPTED_AS_READING, REJECTED, EDITED_AND_ACCEPTED. A decision is append-only, names the person (display name), gives a reason (at least 10 characters for reject and edit) and a UTC time. A later decision supersedes by a newer row; the history stays.  
*How checked:* Test.

**PR-E02 (MUST)** ACCEPTED_AS_READING means 'accepted as a reading of this drawing revision'. Every screen and report that shows it says that it is not verification of the plant or of the drawing.  
*How checked:* Inspection.

**PR-E03 (MUST)** A decision binds to the document revision id, its SHA-256 and the run id. If the revision is withdrawn or replaced, accepted readings show STALE_SOURCE and are not offered for new links.  
*How checked:* Test.

**PR-E04 (MUST)** Bulk acceptance is limited to a class filter with a preview of the count and examples. Each item still gets its own decision row. An item below the confidence threshold given in the run parameters, or in a class the module has flagged 'not offered for bulk acceptance' (L03), cannot be bulk-accepted.  
*How checked:* Test.

**PR-E05 (MUST)** An edit stores the original reading and the edited value.  
*How checked:* Test.

**PR-E06 (MUST)** Nothing is accepted automatically: not by confidence, not by repetition, not by any machine-learning component.  
*How checked:* Test + inspection.

**PR-E07 (SHOULD)** A reviewer can mark a region 'not a P&ID item' with a reason; ignored regions are counted in the run summary.  
*How checked:* Test.

**PR-E08 (SHOULD)** The review window can draw a random sample of accepted items for a second person's check; the second check is a separate append-only record.  
*How checked:* Test.

### F. Persistence in the host case file

**PR-F01 (MUST)** One additive migration `00NN_pid_reader.sql` (the host assigns NN at integration; a template is in `templates/`). It creates only new tables and triggers, alters no earlier table and no earlier CHECK (the earlier contracts are frozen and SQLite cannot alter a CHECK without a table rebuild), is one-way, and its SHA-256 is recorded in `schema_migration` like v2-v23.  
*How checked:* Test: earlier schema fingerprints unchanged.

**PR-F02 (MUST)** Every new table is append-only with no-update and no-delete triggers, and current state is derived from the newest row. A test inserts a row and then tries to update and delete it.  
*How checked:* Test.

**PR-F03 (MUST)** Minimum tables: `pid_read_run`, `pid_object`, `pid_connection`, `pid_loop_proposal`, `pid_decision`, `pid_asset_link`, `pid_second_check`. The template gives the columns; the module may add columns but not remove them.  
*How checked:* Inspection.

**PR-F04 (MUST)** Every write goes through the host's `append_audit` with a new event prefix (the next free one after `M16_`) and a `reconcile_model(db, version, events)` that, on open, requires the tables to equal what the audit events imply. A tampered row is detected (test).  
*How checked:* Test.

**PR-F05 (MUST)** Size caps (owner decision; placeholders): 20,000 objects per run, 8 MiB of stored result per run. Beyond a cap the run is refused with a limit code, never truncated silently. The per-object rows are the record; a compressed copy of the raw result may be stored only under the cap.  
*How checked:* Test.

**PR-F06 (MUST)** The new tables are added to the host's `VISIBLE_TABLES` (field history), to the JSON export and to the exports' DRAFT marking. Word and Excel report sections are listed separately as optional.  
*How checked:* Test.

**PR-F07 (MUST)** The module provides `enable_model(db, actor)` (idempotent, from the previous version only), `reconcile_model`, `TABLES`, `TRIGGERS` and `MIGRATION`, in the same pattern as `hazop_relations.py`, and the text of the `core.validate_file` hook.  
*How checked:* Test.

**PR-F08 (MUST)** The case stays portable: no absolute paths, no reference outside the file, no model weights inside the case.  
*How checked:* Inspection.

**PR-F09 (MUST)** The delivery states, in the user guide text, that older Worksheet versions cannot open a case that has the new schema.  
*How checked:* Inspection.

### G. Mapping to host records

**PR-G01 (MUST)** Protection assets: the reader may PROPOSE an asset (verbatim tag, class, function text, sensors, logic solver, final elements as printed) for a person to register through the existing `create_lopa_asset`. It never writes `lopa_asset_revision`.  
*How checked:* Test: that table is untouched.

**PR-G02 (MUST)** Aliases: the reader may propose a POSSIBLE alias between two tags that the drawing shows on one physical item (for example a transmitter tagged LT-101 and LIT-101) with a basis text. It never proposes CONFIRMED; the host rule stands that CONFIRMED needs a person's basis of at least 10 characters.  
*How checked:* Test.

**PR-G03 (MUST)** Shared components: the reader may output `shared_component_evidence` (two safeguards sharing a transmitter, logic solver, final element, utility or signal path). The host uses it only to raise POSSIBLE dependencies for a reviewer. The output and the UI say that the absence of such evidence is never evidence of independence.  
*How checked:* Inspection.

**PR-G04 (MUST)** Node boundaries: the reader may propose regions (bounding boxes) for equipment groups. A host `drawing_region` is created and linked to a HAZOP node only through the existing workflow, which needs a person's HUMAN_VERIFIED statement.  
*How checked:* Test.

**PR-G05 (SHOULD)** For a node region, the module lists the equipment, lines, instruments, relief devices and trips shown inside it as a checklist 'items shown on the drawing in this region'. It never fills worksheet rows, causes or safeguards; safeguards stay recorded claims.  
*How checked:* Inspection.

**PR-G06 (MUST)** A link from a drawing item to a LOPA layer or SIF is made only by a person through the existing LOPA screens. The module supplies an evidence reference (kind DRAWING: drawing number, revision, sheet, box) for the host's evidence pointer.  
*How checked:* Test.

**PR-G07 (MUST)** Tags are output verbatim and, advisory only, in a normalised form. Matching against the register uses the host's rule (case, punctuation and spacing insensitive matches are POSSIBLE links). The host decides.  
*How checked:* Test.

**PR-G08 (SHOULD)** A reconciliation report lists register assets found on no read drawing, drawing instruments not in the register, and tags that conflict (same tag on different symbols or sheets). It reports; it changes nothing.  
*How checked:* Test.

**PR-G09 (MUST)** When a new revision of a drawing is attached, the module offers the diff (D09) and flags dependent accepted readings and links for review, and supplies the list of changed items so that the host's stale-impact pathway can mark LOPAs that cite them (a host work item at integration).  
*How checked:* Test.

### H. Services and contract

**PR-H01 (MUST)** Only additive functions are added to `services` (the template lists the names), each with trailing optional parameters only. No existing function or signature changes. The host then freezes a new contract revision and the comparison must classify it ADDITIVE.  
*How checked:* Test: `verify_current_contract.py` comparison.

**PR-H02 (MUST)** `run_pid_reader` is cancelable, runs off the GUI thread with progress, and commits in one transaction at the end: all rows or none. The unit of a run is one document revision and a page range.  
*How checked:* Test.

**PR-H03 (MUST)** The module declares `host_contract_min`. A case at an older schema is upgraded only by an explicit user action like every other module (the host extends `upgrade_worksheet_to`).  
*How checked:* Test.

**PR-H04 (MUST)** Errors are the host's `CaseError(code, plain-language message)`; no traceback reaches the user. The codes are listed in the manifest.  
*How checked:* Test.

**PR-H05 (MUST)** The module uses the working copy only through services; it never opens the saved file and keeps no connection of its own.  
*How checked:* Inspection.

### I. User interface

**PR-I01 (MUST)** A review window: the page (using the host's out-of-process, cancelable renderer), an overlay of proposals by class drawn with shape and label as well as colour, a filterable and sortable list, a detail panel (evidence quote, box, reader confidence, parsed fields, linked register asset), accept / reject / edit with reason, keyboard operation, and undo of the last decision by a new decision row.  
*How checked:* Demonstration + UI test.

**PR-I02 (MUST)** A banner is always visible: 'Readings are proposals from software. Nothing here verifies the drawing or the plant.'  
*How checked:* Inspection.

**PR-I03 (MUST)** The window works with the host's light, dark and greyscale themes, at 100 %, 125 % and 150 % scaling, with a narrow minimum width, a projector view, and no information that appears only on hover.  
*How checked:* UI test + screenshots; a person's check at real scaling is a separate gate.

**PR-I04 (MUST)** The window never blocks: a long read runs in the worker and has a Cancel button that works within 5 seconds.  
*How checked:* Test.

**PR-I05 (SHOULD)** From a LOPA or an asset, jump to its place on the drawing; from a drawing item, jump to its register entry.  
*How checked:* Demonstration.

**PR-I06 (SHOULD)** Hand-in screenshots of every screen at 100 % and 150 %.  
*How checked:* Inspection.

**PR-I07 (MUST)** Plain language and one vocabulary for statuses everywhere (the table in 01_REQUIREMENTS).  
*How checked:* Inspection.

### J. Security and privacy

**PR-J01 (MUST)** No telemetry, no phone-home, no crash upload.  
*How checked:* Test + code inspection.

**PR-J02 (MUST)** Logs contain no drawing text, tags or tokens; only counts, ids, codes and hashes.  
*How checked:* Test.

**PR-J03 (MUST)** If a loopback or online model is optionally supported, it goes through the host's consent mechanism (`ai_consent_event`: exact endpoint, document revisions, approval of the exact outbound preview, outbound hash) and records its `transfer_scope`. It is OFF by default and never required for the module to work.  
*How checked:* Test + inspection.

**PR-J04 (MUST)** The worker needs no administrator right, writes no registry key and starts no child process other than those documented.  
*How checked:* Inspection.

**PR-J05 (MUST)** A software bill of materials (CycloneDX or SPDX JSON) with hashes. No unpinned or unreviewed dependency and no binary without source and licence recorded.  
*How checked:* Inspection.

**PR-J06 (MUST)** A malformed-input corpus (truncated, huge, encrypted, recursive, script-carrying, zero-page, rotated, wrong-extension files). Each is refused cleanly or read within the limits, with no crash and no hang.  
*How checked:* Test.

**PR-J07 (MUST)** Temporary files stay in the host-provided folder and are removed; no document content is left after the worker exits.  
*How checked:* Test.

### K. Performance and limits

**PR-K01 (MUST)** The manifest declares peak memory and time per page on a stated reference PC (owner to confirm; placeholder 8 GB RAM, 4 cores). The worst case (16 MiB, 500 pages) completes or is refused within the time cap (placeholder 30 minutes) and never exceeds the memory cap (placeholder 4 GB).  
*How checked:* Test on the reference PC.

**PR-K02 (MUST)** Cancellation takes effect within 5 seconds and leaves nothing behind.  
*How checked:* Test.

**PR-K03 (MUST)** Result and object caps (F05) refuse the run with a code; they never truncate silently.  
*How checked:* Test.

### L. Quality evidence

**PR-L01 (MUST)** A gold set of synthetic or cleared drawings with ground-truth annotation files in the format of `schemas/gold_annotation.schema.json`: at least the number the owner decides (placeholder 30) covering clean vector, dense vector, scanned, multi-sheet, with markups, and different symbol styles. A held-out test split is never used for tuning.  
*How checked:* Inspection of the gold set and the split record.

**PR-L02 (MUST)** Reported per class and overall: object precision, recall and F1 at a stated IoU threshold; tag exact-match rate and character error rate; connection precision and recall (an edge is its endpoint pair); loop-proposal precision; and, separately, the SILENT-MISS rate (truth items that appear neither as an object nor in `unreadable_regions` or `warnings`).  
*How checked:* Benchmark report.

**PR-L03 (MUST)** Acceptance thresholds are an owner decision recorded BEFORE the benchmark is run, not set by the developer after seeing results. A class that fails its threshold is declared 'not offered for bulk acceptance' in the manifest.  
*How checked:* Inspection of the dated threshold record.

**PR-L04 (MUST)** Someone other than the developer runs the benchmark from the hand-in bundle and signs the report. Until then the module may not be described as tested for accuracy; status NOT_RUN.  
*How checked:* Independent report.

**PR-L05 (MUST)** A failure analysis: the typical error types with synthetic examples.  
*How checked:* Inspection.

**PR-L06 (SHOULD)** A confidence calibration table on the held-out set.  
*How checked:* Inspection.

**PR-L07 (MUST)** A regression harness is delivered; a later module version may not drop a metric below its threshold without the owner's written acceptance.  
*How checked:* Test.

### M. Tests and hand-in

**PR-M01 (MUST)** Tests: unit (parsing, geometry, tag parsing, canonicalisation), integration against a temporary host-like SQLite file with the template migration (append-only triggers, audit reconcile, tamper detection), worker protocol (cancel mid-run, limits, malformed input), schema validation, determinism, contract (services additive), and UI tests (offscreen) with screenshots.  
*How checked:* Inspection of the test report.

**PR-M02 (MUST)** Tests run with `python -m unittest discover` in the host style, without network, and write their report to a NEW evidence folder; archived evidence is never overwritten.  
*How checked:* Test.

**PR-M03 (MUST)** The hand-in bundle contains everything in `04_HAND_IN_CHECKLIST.md`.  
*How checked:* Inspection.

**PR-M04 (MUST)** An integration rehearsal on a COPY of the host tree: the host suite and the module suite both pass, the contract comparison is ADDITIVE, the example case is rebuilt, the packs are rebuilt, and the result is recorded in a new LOCAL_BUILD folder.  
*How checked:* Rehearsal record.

**PR-M05 (MUST)** Integration is a patch against a named host build; a hashed backup of that build is kept so that it can be undone.  
*How checked:* Inspection.

### N. Documentation

**PR-N01 (MUST)** A README, a user-guide section in the host's style, the limitations (what the module cannot read), a data-handling statement, the vocabulary table, open-issues entries in the host's OI style, and a description of the algorithms, libraries, models, heuristics and thresholds that is sufficient for an independent reviewer.  
*How checked:* Inspection.

**PR-N02 (MUST)** Every statement about accuracy cites a benchmark report id. A statement without one is removed.  
*How checked:* Inspection.

**PR-N03 (SHOULD)** A worked synthetic example with screenshots.  
*How checked:* Inspection.

## 9. Error codes the module must define (extend as needed; list them in `module.json`)
`PID_SHA_MISMATCH`, `PID_ENCRYPTED`, `PID_NO_TEXT_LAYER`, `PID_LIMIT_BYTES`, `PID_LIMIT_PAGES`, `PID_LIMIT_OBJECTS`, `PID_UNKNOWN_PARAMETER`, `PID_LIMIT_RAISED`, `PID_BAD_PARAMETER`, `PID_MALFORMED`, `PID_CANCELLED`. Host users see plain-language text through `CaseError`; codes are for tests and logs.

## 10. What is in this pack
| File | Use |
|---|---|
| `01_REQUIREMENTS.md` | this document |
| `02_HOST_INTEGRATION_FACTS.md` | what the host program looks like, with file names |
| `03_ACCEPTANCE_CHECKLIST.csv` | one row per requirement: how checked, who, status (all NOT_RUN) |
| `04_HAND_IN_CHECKLIST.md` | what must be in the delivery |
| `05_OWNER_DECISIONS_NEEDED.md` | decisions only the owner can make |
| `schemas/pid_extraction.schema.json` | the output contract |
| `schemas/module_manifest.schema.json` + `examples/module.json` | the manifest |
| `schemas/gold_annotation.schema.json` | the ground-truth format for the benchmark |
| `templates/00NN_pid_reader.template.sql` | the additive migration template (checked: it applies cleanly to a real v23 case file) |
| `skeleton/` | `pid_reader` package skeleton with the deterministic rules as reference code, the worker protocol, and the host-side function names |
| `tools/check_extraction.py`, `tests/` | a mechanical checker for an extraction and its tests (run them: `python -m unittest discover -s tests -v`) |
| `examples/sample_extraction.json` | an INVENTED sample extraction that passes the checker |
| `MANIFEST.sha256` | SHA-256 of every file in the pack |

Limits of this pack: it states requirements; it does not contain a reader. The skeleton raises NotImplementedError where the reading belongs. The SQL template and the checker were run against the current host; nothing else here has been exercised against a real P&ID. Standards (ISA-5.1, ISO 10628, DEXPI and similar) are named only as things the reader may follow; no standard text is reproduced and their licences are yours to check (decision 11).
