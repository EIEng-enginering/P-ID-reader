# What the host program looks like (facts a module must respect)

Written against **Worksheet 0.25.0a1: schema v23, contract R22** (2026-11-07). Re-check the numbers against the build you integrate with; the *rules* below are what stay.
File names refer to the host tree (`worksheet\src\worksheet_app\...`). Nothing here is a promise about a future build.

## 1. Platform
* Windows desktop, Python 3.12, PySide6 **6.12.0** (Essentials, Addons, Pdf, WebEngine and shiboken6 pinned in `requirements-lock.txt`). Standard SQLite from Python. Offline by default; nothing is sent anywhere without a recorded consent (`docs/DATA_HANDLING_POLICY.md`).
* Unit and integration tests run with `python -m unittest discover`; evidence goes to a NEW `TEST_RESULTS/LOCAL_BUILD_Rnn` folder per run (archived folders are never overwritten). Tests use synthetic data only.
* The host tree is **not a Git repository**. Integration is a patch against a named build with a hashed backup.

## 2. The case file (`.hzcase`)
* One portable SQLite file per study. A working copy is edited; the saved file changes only on Save. Older program versions refuse a newer file.
* Schema changes are **numbered, one-way, additive** migrations in `contracts/migrations/00NN_*.sql`. Each is applied by an explicit upgrade (`enable_*` service), recorded in `schema_migration` with the script's SHA-256, and re-checked on open (`core.validate_file`). Earlier migrations and their hashes never change. v1 to v23 exist; the next free number is **24**.
* **Append-only tables:** `BEFORE UPDATE` / `BEFORE DELETE` triggers abort; current state is derived from the newest row. Nothing is deleted; things are withdrawn.
* **Audit chain:** every write calls `append_audit(db, case_id, actor, event_type, entity_type, entity_id, before, after)`. Events form a hash chain. On open each module's `reconcile_model(db, version, events)` proves that its tables equal what the events say; a changed row makes the file refuse to open. Event prefixes in use: `HAZOP_`, `WORKSHOP_`, `METHOD_PACK_`, `M2_`, `M3_ACTION_`, `M3_APPROVAL_`, `M4_`, `M5_WS_`, `M6_TPL_`, `M7_LOPA_`..`M11_LOPA_`, `M12_`, `M13_LOPA_`, `M14_LOPA_`, `M15_`, `M16_`. **Next free: `M17_`.**
* Canonical JSON (`core.canonical_json`): `json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)`; digests are SHA-256 of its UTF-8 bytes.
* Reference modules to copy the pattern from: `hazop_relations.py` + `0023_hazop_relations.sql` (smallest), `lopa_endpoints.py`, `lopa_assets.py`, `hazop_profiles.py`.

## 3. The contract
* `tools/verify_current_contract.py` freezes a manifest of every migration hash, schema (tables, triggers) and service signature per revision (`contracts/CURRENT_CONTRACT_MANIFEST_Rnn.json`). A change is **ADDITIVE** (new tables, new functions, new optional trailing parameters), **BREAKING** (anything removed or changed) or UNCHANGED. The module must be ADDITIVE; the host then freezes the next revision. Earlier manifests stay byte-identical (their hashes are recorded in `tests/integration/test_contract_inventory.py`).
* SQLite cannot alter a CHECK constraint without rebuilding the table, and rebuilding is breaking. So a module **cannot add a value to an existing CHECK list** (for example a new `ai_proposal.kind`); it keeps its own tables.

## 4. Documents and drawings already in the host
* `document_revision` holds embedded document bytes (`content_bytes`, `content_sha256`, `status` ACTIVE / WITHDRAWN). PDF drawings are opened through `get_drawing_pdf_bytes`; limits in `drawing_limits.py`: **16 MiB**, **500 pages**, **12,000,000 render pixels**. Rendering is done **out of process** (`render_worker.py`, `render_async.py`, `pdf_render.py`) so it can be cancelled by terminating the process.
* `drawing_region`: `document_revision_id`, `document_sha256`, `page_number`, **normalised box** `x0 < x1`, `y0 < y1` in 0..1 (origin top-left), `label`, `verification_state` UNVERIFIED / HUMAN_VERIFIED (HUMAN_VERIFIED needs a named person and a statement). Linked to HAZOP nodes (`hazop_node_drawing_region`) and HAZID areas. The module's coordinates use exactly this convention.
* Document text index: `doc_index_run` (immutable, one per revision and extractor, with a limits text) and `doc_text_span` (page, character range, kind, text, SHA-256). A reader's evidence may point at a span id.

## 5. The AI proposal pattern (the closest existing precedent)
* `lopa_ai` / `m4_ai`: a provider (rules offline, loopback, online) returns PROPOSALS; a person accepts, edits or rejects each; accepting is atomic; nothing is credited by software. Transfers need a recorded **consent** (exact endpoint, document revisions, approved outbound preview, outbound hash) and record `transfer_scope` OFFLINE / LOCAL_LOOPBACK / ONLINE. The module must follow the same honesty rules (requirements A, E, J).

## 6. Records the module's output may feed (always through a person)
* **Protection assets** `lopa_asset_revision`: tag, class, function, sensors, logic solver, final elements, utilities, bypass state, owner. Versioned; created by `create_lopa_asset`.
* **Aliases** `lopa_asset_alias`: CONFIRMED or POSSIBLE, status, **basis of 10 to 1000 characters**, actor. A POSSIBLE alias or a tag that differs only in punctuation / spacing / case is a *possible dependency*: none of the layers is credited until a named reviewer records a single credit or "judged independent" with a reason. A CONFIRMED alias cannot be judged away.
* **Standing conditions** (partial failure, inhibit, proof-test override, degraded reliability), **SIF requirements**, **evidence references** on LOPA layers (kinds DOCUMENT, **DRAWING**, TEST_RECORD, CALCULATION, OTHER; a pointer, no file is stored).
* **HAZOP**: nodes, deviations, causes, consequences, safeguards (recorded **claims**, unverified), recommendations (formal actions). A deviation can move between nodes keeping ids (v23).
* **Staleness:** a LOPA records what it was written against (including the node name and the asset register revisions of its credited layers) and shows OUT OF DATE when those change. The Impact window lists them.

## 7. Language rules of the host (carry them into the module)
* Never "verified", "validated", "approved", "certified SIL", "ALARP" or "compliant" for anything software produced. Statuses are words, not only colours. A calculated number that has blocking findings is not an accepted result. Training / example data is labelled.
* The owner approves each stage; unperformed human, independent, expert or legal checks are shown as NOT_RUN, never as passed. Gates G4 to G7 of the host are NOT_RUN at the time of writing.

## 8. UI conventions
* Light, dark and greyscale themes; text size A- / A+ and a projector view; the LOPA window works at 150 % text with a narrow minimum width; every list says how many items are hidden by a filter; modal dialogs are tested offscreen with the question boxes patched; screenshots of every screen are saved by the test suite into the evidence folder. No person has yet checked real 125 / 150 % Windows scaling or a projector (gate G6 NOT_RUN).
