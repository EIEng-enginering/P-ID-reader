# P&ID reader module: requirements pack (R1, 2026-11-07)

Start with `01_REQUIREMENTS.md`. It says what a separately developed P&ID reader must be and do so that it can be added to the Worksheet program as a module, with the rules that keep its output honest (it proposes, people decide, nothing is verified or credited by software).

Read in this order:
1. `01_REQUIREMENTS.md` - purpose, principle, life cycle, vocabulary, the requirements (PR-A01 to PR-N03)
2. `05_OWNER_DECISIONS_NEEDED.md` - settle these before the benchmark is run (above all the accuracy thresholds)
3. `02_HOST_INTEGRATION_FACTS.md` - what the host program looks like
4. `schemas/`, `templates/`, `skeleton/`, `examples/` - the contracts and starting code
5. `03_ACCEPTANCE_CHECKLIST.csv` and `04_HAND_IN_CHECKLIST.md` - what you tick off at hand-in

Try the tools (Python 3.12, standard library only):

```
python -m unittest discover -s tests -v
python tools/check_extraction.py examples/sample_extraction.json
```

This pack contains requirements, contracts and a skeleton. It does not contain a reader. All data in it is invented. Check `MANIFEST.sha256` before relying on any file.
